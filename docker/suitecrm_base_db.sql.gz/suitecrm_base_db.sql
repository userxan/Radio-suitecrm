/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.19-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: suitecrm_db
-- ------------------------------------------------------
-- Server version	10.11.19-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `id` char(36) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `account_type` varchar(50) DEFAULT NULL,
  `industry` varchar(50) DEFAULT NULL,
  `annual_revenue` varchar(100) DEFAULT NULL,
  `phone_fax` varchar(100) DEFAULT NULL,
  `billing_address_street` varchar(150) DEFAULT NULL,
  `billing_address_city` varchar(100) DEFAULT NULL,
  `billing_address_state` varchar(100) DEFAULT NULL,
  `billing_address_postalcode` varchar(20) DEFAULT NULL,
  `billing_address_country` varchar(255) DEFAULT NULL,
  `rating` varchar(100) DEFAULT NULL,
  `phone_office` varchar(100) DEFAULT NULL,
  `phone_alternate` varchar(100) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `ownership` varchar(100) DEFAULT NULL,
  `employees` varchar(10) DEFAULT NULL,
  `ticker_symbol` varchar(10) DEFAULT NULL,
  `shipping_address_street` varchar(150) DEFAULT NULL,
  `shipping_address_city` varchar(100) DEFAULT NULL,
  `shipping_address_state` varchar(100) DEFAULT NULL,
  `shipping_address_postalcode` varchar(20) DEFAULT NULL,
  `shipping_address_country` varchar(255) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `sic_code` varchar(10) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accnt_id_del` (`id`,`deleted`),
  KEY `idx_accnt_name_del` (`name`,`deleted`),
  KEY `idx_accnt_assigned_del` (`deleted`,`assigned_user_id`),
  KEY `idx_accnt_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_audit`
--

DROP TABLE IF EXISTS `accounts_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accounts_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_audit`
--

LOCK TABLES `accounts_audit` WRITE;
/*!40000 ALTER TABLE `accounts_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_bugs`
--

DROP TABLE IF EXISTS `accounts_bugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_bugs` (
  `id` varchar(36) NOT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `bug_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_acc_bug_acc` (`account_id`),
  KEY `idx_acc_bug_bug` (`bug_id`),
  KEY `idx_account_bug` (`account_id`,`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_bugs`
--

LOCK TABLES `accounts_bugs` WRITE;
/*!40000 ALTER TABLE `accounts_bugs` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts_bugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_cases`
--

DROP TABLE IF EXISTS `accounts_cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_cases` (
  `id` varchar(36) NOT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `case_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_acc_case_acc` (`account_id`),
  KEY `idx_acc_acc_case` (`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_cases`
--

LOCK TABLES `accounts_cases` WRITE;
/*!40000 ALTER TABLE `accounts_cases` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts_cases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_contacts`
--

DROP TABLE IF EXISTS `accounts_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_contacts` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_account_contact` (`account_id`,`contact_id`),
  KEY `idx_contid_del_accid` (`contact_id`,`deleted`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_contacts`
--

LOCK TABLES `accounts_contacts` WRITE;
/*!40000 ALTER TABLE `accounts_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_cstm`
--

DROP TABLE IF EXISTS `accounts_cstm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT 0.00000000,
  `jjwg_maps_lat_c` float(10,8) DEFAULT 0.00000000,
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  `industry_category_c` varchar(100) DEFAULT 'other',
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_cstm`
--

LOCK TABLES `accounts_cstm` WRITE;
/*!40000 ALTER TABLE `accounts_cstm` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts_cstm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_opportunities`
--

DROP TABLE IF EXISTS `accounts_opportunities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_opportunities` (
  `id` varchar(36) NOT NULL,
  `opportunity_id` varchar(36) DEFAULT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_account_opportunity` (`account_id`,`opportunity_id`),
  KEY `idx_oppid_del_accid` (`opportunity_id`,`deleted`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_opportunities`
--

LOCK TABLES `accounts_opportunities` WRITE;
/*!40000 ALTER TABLE `accounts_opportunities` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts_opportunities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acl_actions`
--

DROP TABLE IF EXISTS `acl_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `acl_actions` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `acltype` varchar(100) DEFAULT NULL,
  `aclaccess` int(3) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aclaction_id_del` (`id`,`deleted`),
  KEY `idx_category_name` (`category`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acl_actions`
--

LOCK TABLES `acl_actions` WRITE;
/*!40000 ALTER TABLE `acl_actions` DISABLE KEYS */;
INSERT INTO `acl_actions` VALUES
('00e88db2-3a19-40f7-a13a-6857533caffc','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Accounts','module',90,0),
('01a44620-1210-4c4b-8aec-f159daf64b61','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AM_ProjectTemplates','module',90,0),
('01a980df-63dc-496e-bbff-f75d1894d73a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AOS_Product_Categories','module',90,0),
('0251c0c4-3c93-4b84-adb8-fa4cfbde1be0','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AOK_Knowledge_Base_Categories','module',89,0),
('029923fd-c9af-4591-8835-0bb928fca60d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','CalendarAccount','module',90,0),
('02ffc40a-698d-4db9-84fd-2ef9071aa51c','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AOK_KnowledgeBase','module',90,0),
('03aa6049-d4e6-4665-89c0-811458e8f035','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Opportunities','module',90,0),
('05c5e025-3d66-4471-8d4c-2113b17d9477','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','EmailTemplates','module',90,0),
('05fbdea5-6ed0-4214-ba6f-e5f8a4f301ce','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','EmailTemplates','module',90,0),
('0601c991-d68c-46b6-9c40-24ed35b733cc','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','jjwg_Areas','module',90,0),
('065d7d4e-8a28-424e-a524-9d511a25a439','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Calls_Reschedule','module',90,0),
('078e1d79-88bd-404f-b380-c5fabb056f4c','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Surveys','module',90,0),
('07b762af-d4df-4393-b65e-f4c860a015be','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AOS_Product_Categories','module',90,0),
('081bec33-60f4-458e-b325-5bd1ba452cd2','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AOS_Quotes','module',90,0),
('083ea62b-90c5-4015-9821-0a52561e41b3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AOS_Contracts','module',90,0),
('0863be3e-67a8-49cb-94ad-dd3674f355cf','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Surveys','module',90,0),
('09decc73-ab5d-4063-90fc-a7fdb6a6fbfa','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','SecurityGroups','module',90,0),
('0a6b8e1b-37d8-4c99-840f-6a4dcac9a762','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AOK_Knowledge_Base_Categories','module',90,0),
('0aa101dd-1932-4a6d-9817-6681c982ddfc','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','SurveyResponses','module',90,0),
('0ac8ccca-99fc-4acd-868f-b4c538d7884f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','ManualMigrationTasks','module',90,0),
('0b264a3e-23ee-4a2a-9c66-bda5c4e3b99b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','MediaObjects','module',90,0),
('0b7f7c73-cb19-4e8b-82cb-60764c4b2e43','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AOR_Scheduled_Reports','module',90,0),
('0b8c2eb9-392d-44ee-914d-c0f15fc2c3ca','2026-10-16 11:49:31','2026-10-16 11:49:31','1','1','view','RT_RadioCampaigns','module',90,0),
('0c003584-17cd-4dd3-83d3-93afec3ac155','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','MediaObjects','module',89,0),
('0d23373e-402c-47f5-bd9d-c91530149114','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Accounts','module',90,0),
('0d2fca13-3ab0-4b5f-8c35-23479cbac5bd','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','jjwg_Maps','module',90,0),
('0d50851b-7bf7-4126-9bef-9cff964f2929','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AOS_Quotes','module',90,0),
('0db05a8a-9be6-4767-a6df-89947c935ff0','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AOS_Invoices','module',90,0),
('0dcc5d39-4fdf-47ff-9af9-97ad637c9808','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','ProspectLists','module',89,0),
('0efadd9d-999d-43bf-97d5-1562eeb544ea','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AOW_WorkFlow','module',90,0),
('0f074136-e97b-4d80-8171-677b08240b08','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AOS_Product_Categories','module',89,0),
('0ff36ff4-80b4-42f0-88d2-8b6f8df21c31','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Leads','module',90,0),
('1024f450-b381-49d3-ad16-cc980952018f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Emails','module',89,0),
('1053c16c-bbf8-42e6-ba2e-8dcc142b74b2','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AOS_Product_Categories','module',90,0),
('1086a607-2db4-46ec-b19b-ea8a4700ca66','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AOR_Scheduled_Reports','module',90,0),
('108eb436-fde0-4b2b-a7d0-173188a87c41','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AOW_WorkFlow','module',90,0),
('114d0dd2-dff8-4b1e-ad0c-1739404e7045','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','SurveyQuestionResponses','module',89,0),
('116b17e1-122f-4481-a397-d729979eaef5','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','ExternalOAuthConnection','module',90,0),
('12138bb5-7f68-40a3-a8cf-138f0699df6f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Users','module',90,0),
('12ea74d8-4107-427e-8de0-454b5a260c47','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AsyncTaskItems','module',90,0),
('1305763c-b271-49e8-98d3-b2542dda02b8','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AOS_Products','module',90,0),
('1326df53-6c20-4437-957f-57b6f5b22c03','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AOP_Case_Events','module',90,0),
('13660d05-36f0-4a0f-90fc-5fad7ff99bc6','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Processes','module',90,0),
('137f1fa1-557f-4177-9546-90e02a9f1965','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AOR_Reports','module',90,0),
('13fc4b32-51ba-4428-9894-5a2c965c0b4c','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','SurveyQuestionOptions','module',90,0),
('14624122-62a2-4304-840c-5512a50a7982','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AOR_Scheduled_Reports','module',90,0),
('14da974e-6451-402f-99be-326ae434bf32','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Alerts','module',90,0),
('157fb4b4-ad9f-491b-a443-5f6a0fa6d6d9','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','ProjectTask','module',89,0),
('15ba4eb8-7cc7-4948-95b6-71ca4814e9d8','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','CalendarAccount','module',90,0),
('15d81017-556f-478e-ac08-1f2ed4ca45ce','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AOS_PDF_Templates','module',90,0),
('16fd4a34-bdaf-4b79-8c99-d6c9e1a3bdfc','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Bugs','module',90,0),
('170bb000-67c8-4756-9082-c55bca5f487f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Contacts','module',90,0),
('17e72ffc-3f7a-4faf-a5e2-edea0ee26726','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Bugs','module',90,0),
('1806297e-0ed9-4634-9700-98dd830cdae3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AOW_WorkFlow','module',90,0),
('19c7e87d-0327-4b52-b960-330ada454665','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Project','module',90,0),
('19df4937-5fc3-45f8-ac4b-8302aabe0a47','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AOW_WorkFlow','module',90,0),
('1b0673c8-7700-4549-8678-d3954c2460fd','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Notes','module',90,0),
('1b1ec69c-df71-4f85-b8da-e4aeb11bf08d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','SecurityGroups','module',90,0),
('1bb4c0bb-88ff-4c57-ba4b-3dccb31acbfc','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Notes','module',90,0),
('1bd4d9a1-76a1-4472-80e2-c183af1caa18','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Cases','module',90,0),
('1c66d277-0510-4166-8403-6d7f3aba13c1','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Calls','module',90,0),
('1cfb4ab9-b21e-473a-9b8c-7bc0afa56f9a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Alerts','module',90,0),
('1e5e6f7b-4d85-421e-94e7-37818205a0aa','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','FP_Event_Locations','module',90,0),
('1eab3390-f721-4792-a4de-13b48cbbb2b3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AOR_Scheduled_Reports','module',90,0),
('1f329af2-34d1-40d6-81ae-067677f7565d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AOS_Contracts','module',90,0),
('20185ff5-bb72-4c7e-999b-2f0c01887900','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Meetings','module',90,0),
('201bbae0-1868-435b-b006-ec7b24e43a60','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Project','module',90,0),
('20af756b-e101-4567-b34d-ae519e8facbc','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AOS_Contracts','module',90,0),
('213d3e98-5cba-438b-a87a-76a4a3f794e7','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','jjwg_Markers','module',90,0),
('2179288e-8774-4476-83ec-102cbd47f908','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AOP_Case_Updates','module',90,0),
('21a950c4-2852-4832-9e19-3dbd725530bb','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AOS_Quotes','module',90,0),
('22eee7dc-709d-4fa5-84a7-981762b66dda','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Meetings','module',89,0),
('23337cae-741b-4cdd-adb9-01a53cef9ff4','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','ExternalOAuthConnection','module',90,0),
('238f2b35-6bd0-4259-adc6-15b78848ce92','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AOS_Invoices','module',90,0),
('24aa2b17-3ad6-44ac-b912-0951f8980a75','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Emails','module',90,0),
('24b84399-48ec-4231-adec-c16aaffe9916','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AOS_Products','module',90,0),
('255a6395-653a-40b8-9cb7-22023c23d00d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AOS_PDF_Templates','module',90,0),
('25c4294b-dd37-4b38-8217-1e3becaea527','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Documents','module',90,0),
('260700e8-232e-494b-b308-6348c616559c','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','FP_Event_Locations','module',90,0),
('26be2327-a4b7-41de-943d-cd894b453a46','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','SurveyQuestions','module',90,0),
('26e7e88c-aa05-468b-9a12-6c268cff31b3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','SurveyQuestionResponses','module',90,0),
('272495aa-9661-47dc-9357-d1cb2b7d19d4','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Processes','module',90,0),
('28709de2-1725-41b8-83d9-fca69e2f4bef','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AM_TaskTemplates','module',90,0),
('28a6c730-10d0-4d0e-8560-88129945af2d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AOP_Case_Events','module',90,0),
('292ab5a6-2508-4fa5-804a-5e261b21d042','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AOR_Reports','module',90,0),
('298c1b8a-da8f-458f-9ec9-61999145e74f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','MediaObjects','module',90,0),
('29d984f9-1986-4ca9-961c-79c39fe095af','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Project','module',90,0),
('2aece5de-f072-4f7d-8d7e-914bb5f23c28','2026-10-16 11:49:31','2026-10-16 11:49:31','1','1','edit','RT_RadioCampaigns','module',90,0),
('2b5fd017-5629-450c-af1f-48d09cc7361e','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Accounts','module',90,0),
('2b7d13f1-e71b-4740-b935-de15e5ba312e','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AOK_KnowledgeBase','module',90,0),
('2beb3760-ea04-4b22-880c-e86276c92c1a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AOR_Scheduled_Reports','module',90,0),
('2c70d3ff-7bd1-434a-a881-8ee00d4f2ec2','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AOS_Products','module',90,0),
('2d86eb5a-de2b-4272-85d7-6eeef730e742','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Contacts','module',90,0),
('2e3ce67d-90ee-4669-b976-0643a0dbfdb2','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Meetings','module',90,0),
('2e590a2b-0b2c-4afd-84bb-1092fb1b6175','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','MediaObjects','module',90,0),
('2e8a2210-9990-4eef-bac4-2ae9bb0cc8fd','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','OutboundEmailAccounts','module',90,0),
('30495bb7-f2d1-4f1f-88fe-b39452ff11ef','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AOS_Quotes','module',90,0),
('316aa711-506b-44f0-9a47-c8957770fc87','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Cases','module',90,0),
('3306c169-de4a-44c3-8f2f-018265cd23f9','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Project','module',90,0),
('3327fcc5-ef5e-40dd-86bd-f1ba080dcf65','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','jjwg_Markers','module',89,0),
('33c5e1d1-dc0d-416b-8bc1-f108d360a50a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Prospects','module',90,0),
('3407c939-7df1-403b-88ee-770491b2bcee','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AOS_Quotes','module',90,0),
('3434c057-79de-4bf2-861f-89b4a60286de','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','CalendarAccount','module',90,0),
('34a8270d-132c-4845-8473-28e2645dba24','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AOP_Case_Events','module',90,0),
('34d9bc41-a2ef-4296-858b-1be2a83b7d17','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AOR_Reports','module',90,0),
('3543b2e0-3237-43ee-b004-43d1d3108d68','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','SurveyQuestions','module',89,0),
('36614a7c-fb2b-49c5-85c9-95446a8a9611','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','jjwg_Maps','module',90,0),
('37d28242-e8b3-419e-9757-842ab2728be6','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Alerts','module',89,0),
('3afc90f9-e807-4bf4-8fdd-ef5b42fe5b65','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Notes','module',90,0),
('3b650f12-b4ad-4e9f-9c4d-5eee9f784f7a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','FP_Event_Locations','module',90,0),
('3c333c71-f992-4d76-8a90-5f5970008c0d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Cases','module',89,0),
('3d0964c0-d4a0-4bbd-97fc-f9bf84785d21','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','jjwg_Markers','module',90,0),
('3d4bd02e-56b7-4684-8b48-b3a88349424f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AM_TaskTemplates','module',90,0),
('3d6a6f4d-46bf-46ad-8544-c4980ce08303','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Users','module',90,0),
('3e2c757a-c6f1-4aff-901a-9e93a130ebac','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','ExternalOAuthConnection','module',89,0),
('3e894d04-541d-4bf2-ba7c-587bbbdee842','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','ExternalOAuthProvider','module',90,0),
('3f3632ef-247b-4f2a-8bb6-3ea0b67fe617','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AOK_KnowledgeBase','module',90,0),
('3fd2ac93-ca89-44b0-b990-e6eb50aab613','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','FP_Event_Locations','module',90,0),
('3fe0662b-e83d-48ed-a555-efb597377da4','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','jjwg_Markers','module',90,0),
('40512cb8-d062-478c-bead-e9291f554cc7','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','ExternalOAuthConnection','module',90,0),
('416b8df5-f69d-4d41-81c6-99a4449f918f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AOS_Invoices','module',89,0),
('41759aed-013a-4012-badc-5499b5083bba','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Users','module',90,0),
('45515b92-5bbe-4732-aa1f-75803d1c8e11','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','ProspectLists','module',90,0),
('4634f5e8-31f6-4792-91fe-65686b7e7d6f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','ProspectLists','module',90,0),
('46f5f62a-0247-4b46-9255-e5a7939bf346','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','OutboundEmailAccounts','module',90,0),
('4759a400-c6dc-4695-9400-af37d4d380f1','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Cases','module',90,0),
('47b68107-6139-4851-97a9-0a5950d6ac2d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AsyncTaskItems','module',90,0),
('47baec3f-f918-4e44-9872-9aead1d83643','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','jjwg_Areas','module',90,0),
('48eb3bb8-55e8-4a35-b3d3-5cbf48fd7f69','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','ProspectLists','module',90,0),
('490d4a64-34b1-4cec-90b5-6c4b98b2370e','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Bugs','module',90,0),
('4a0fd93a-f3ad-410a-ab11-f45b1caf098a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Tasks','module',89,0),
('4a6dd24e-6bba-4031-a836-3d4bf4e41145','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','jjwg_Areas','module',89,0),
('4ae44ec3-40da-475b-9113-34ae09081b97','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','ManualMigrationTasks','module',90,0),
('4bd45136-dcf3-4c90-86df-7f9ee0252227','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Leads','module',90,0),
('4c7de8af-515c-44b5-8dcc-3d10ececdc3b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','ManualMigrationTasks','module',90,0),
('4ddee6e4-477e-4bc0-9a5a-6e560326d68b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Users','module',90,0),
('4e29fdcb-b1b5-48da-958c-df96fcfc46c2','2026-10-16 11:49:31','2026-10-16 11:49:31','1','1','import','RT_RadioCampaigns','module',90,0),
('50567fe4-1dc3-4828-b13f-865416a32366','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','SurveyQuestionOptions','module',90,0),
('50590dbf-cf58-4a7d-9954-174988829012','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Alerts','module',90,0),
('520d25c4-c1f2-43a4-ab78-048a9a3c9757','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Accounts','module',90,0),
('52112f47-a271-44e9-8b2f-4359f5a80532','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','EmailMarketing','module',90,0),
('524ebc92-9a51-4fec-9a2a-6712ccdaa285','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Surveys','module',90,0),
('52738be5-441a-4c2c-8023-72fd6bd708a5','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','jjwg_Areas','module',90,0),
('52d29ac7-4865-4a36-9360-8c2156477aa3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AOK_KnowledgeBase','module',89,0),
('543470f8-7431-4d15-a797-281038876e1f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Accounts','module',90,0),
('5466cebc-ce72-4e72-8f1c-f9fe581c10f1','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','OutboundEmailAccounts','module',90,0),
('55d48a25-d014-4602-9cde-ffc64aef740e','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AM_ProjectTemplates','module',89,0),
('565f8114-630c-455e-b66c-4bd1e084fbd8','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','CalendarAccount','module',90,0),
('56d72898-990e-4c69-a643-49c4c919e4e1','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AOK_KnowledgeBase','module',90,0),
('56d74674-4075-442c-91a2-83986982f285','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Cases','module',90,0),
('58a5a72e-467a-432e-a6e7-bfc4ccd597e3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AOW_Processed','module',90,0),
('593f68ed-805d-478d-a946-8e6f93ec7b63','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','OutboundEmailAccounts','module',90,0),
('5950b6f8-288c-4063-aca8-57d0e0c70f6b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','SurveyQuestionOptions','module',90,0),
('597244e7-53b9-4ad8-997d-7a08a44aa7d1','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Tasks','module',90,0),
('5a0fe088-2bfc-4ca9-a668-a4e78e8197cd','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','SecurityGroups','module',89,0),
('5a22ea42-8452-4d68-812d-5cbc8b8b1635','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AOP_Case_Events','module',90,0),
('5a3b55b3-7f4e-4d12-b21d-a726c57c7969','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','InboundEmail','module',90,0),
('5a4702a2-e793-496c-9ea7-a125aa9346c3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','MediaObjects','module',90,0),
('5a7207f2-4a84-464f-a543-d9d8bddb1e41','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','ExternalOAuthProvider','module',90,0),
('5a8326b5-8bb9-4b84-a514-858395390237','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AOR_Reports','module',90,0),
('5c6d87fe-8785-41f5-9669-d50d26c7c336','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','jjwg_Address_Cache','module',90,0),
('5d0bbadf-7ba4-4d6a-bedb-fe02a6ca6c2c','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Leads','module',90,0),
('5e7b71b8-3b58-41a7-af07-8d1639baad98','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AOK_KnowledgeBase','module',90,0),
('5f50a3bb-4899-4785-91f8-9990f71b57bf','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','CalendarAccount','module',90,0),
('5f9a004f-a8a2-4652-848c-88b69d13c117','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','SurveyResponses','module',90,0),
('5facaca3-9625-4775-b95c-e70cb1e354a5','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','ProjectTask','module',90,0),
('600e5e22-9bb3-4552-b2a7-0500fe164471','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AsyncTaskItems','module',90,0),
('601edd86-1668-402d-b48c-b771428f2142','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AOP_Case_Events','module',90,0),
('609770f3-f155-4142-9394-8432c11ffb42','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Accounts','module',89,0),
('619e10d8-c2bc-4025-8a45-53129ca55ae8','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AM_TaskTemplates','module',90,0),
('6319a191-e7b4-4d0f-a4c1-7fa8ee1977a3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','FP_events','module',90,0),
('6326c018-004f-480f-9ced-d0ff30420ec6','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Surveys','module',90,0),
('6341b9c6-960e-4d9c-b009-4fd36a969ef6','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Notes','module',90,0),
('63cf24d1-c04f-4d71-a9a2-b9beb24a761e','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AOW_WorkFlow','module',90,0),
('64bd06a9-b4bf-4a40-a70e-b4571c9ff21c','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','ProspectLists','module',90,0),
('64d7d93d-2c83-419b-b649-32a1c3b9eee4','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AOS_PDF_Templates','module',90,0),
('664405ca-c089-4aee-b792-c75facf6733e','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AOS_PDF_Templates','module',90,0),
('671b2791-c6f3-4dbe-a063-ee5280471d1d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Emails','module',90,0),
('67907c4a-91e0-42ba-90a5-8af1fb65a602','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Campaigns','module',90,0),
('67c7ff26-ecc3-49ff-90b3-4cfb50c3391b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Documents','module',90,0),
('68642511-6d4a-4214-b60f-77dd53fb7604','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','SurveyResponses','module',90,0),
('686a1ab0-e263-4802-aebb-ba9ac5c075f0','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','SecurityGroups','module',90,0),
('68806f34-22ac-4a81-a64c-f8857fa3ce2e','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','jjwg_Markers','module',90,0),
('68de2e80-a3a1-4c2e-b676-9e33ae1ecf98','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','jjwg_Address_Cache','module',89,0),
('690088dd-16c5-4bd8-84dd-76e45e2bb4c2','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AOW_Processed','module',90,0),
('6973ffb5-8fa3-4b28-9c6b-876c4e96978a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Alerts','module',90,0),
('6a050fc0-45b0-4b9c-b695-1793a5f7d5e9','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','EmailTemplates','module',90,0),
('6a3a1889-797b-4db5-bfd2-82ac8107f81f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Campaigns','module',89,0),
('6a46aa05-8bda-437f-9101-b91629bf34bd','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','InboundEmail','module',90,0),
('6a627acc-f6c5-4417-93b3-ba06f0279b17','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Prospects','module',90,0),
('6aa877f3-2ddb-44d2-8ec3-8e1bbe5d4e76','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','ExternalOAuthProvider','module',90,0),
('6b91d8c6-25de-46ae-a110-3d1f15cbd95c','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AOP_Case_Events','module',90,0),
('6be6297c-b7d4-47f2-ad8a-78533d49e2b2','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','jjwg_Markers','module',90,0),
('6c842912-1053-49c4-82f5-55fa0229ab05','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','jjwg_Areas','module',90,0),
('6cacae5f-accb-4dc4-b77b-bcd593402bf0','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','EAPM','module',90,0),
('6cce30b7-a660-4d66-b13a-f4cced614534','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','SurveyQuestions','module',90,0),
('6dca0545-fd7a-42eb-a7c6-4c35a36a6c6e','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Alerts','module',90,0),
('6ded7592-4419-4d17-b4ea-6de34eb6e515','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Calls_Reschedule','module',90,0),
('6ea75d30-119c-4805-b316-df6d7e4ce55d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AOS_Contracts','module',89,0),
('6f1db0dd-af52-4de9-ae13-b7fb4e8a0fa8','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','FP_Event_Locations','module',90,0),
('6f3feb85-efb5-4775-a7d3-7d48528d8c6a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','SecurityGroups','module',90,0),
('6f5bf0bb-a7f1-4c47-9c53-8e088e5b2642','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','jjwg_Maps','module',90,0),
('6f9d7e10-0f6c-4939-8e8a-e7c02db374f5','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Meetings','module',90,0),
('6fde7110-38fa-4896-a793-cb037f442767','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','jjwg_Markers','module',90,0),
('711fb470-1e05-43b9-88e3-508eaf9f6495','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AsyncTaskItems','module',90,0),
('712fe535-90c1-49c2-83cd-0101d92fc2d8','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AOS_Products','module',90,0),
('7157627e-3a31-4c40-9bf8-509b57e89cc6','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Documents','module',89,0),
('71a796f9-2ed5-4033-8e13-672d4ca911f1','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','ManualMigrationTasks','module',89,0),
('71a88c4d-17a7-4b2f-ba97-09236835d183','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','SurveyQuestionOptions','module',90,0),
('720fd1a6-38b1-4c5d-82da-998f402f2377','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Tasks','module',90,0),
('72753533-f074-46ed-9060-95791d9e3d26','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AOW_Processed','module',89,0),
('729529bd-139b-4310-b991-79912c1087dd','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Leads','module',90,0),
('72a134e6-46f2-4800-9c5d-bc077e162628','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','jjwg_Address_Cache','module',90,0),
('73b5a7e3-ec41-4ef4-9b54-9bd7810ff67b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Prospects','module',90,0),
('7420f4b9-1f93-41f2-ade2-0f8686031ce3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','InboundEmail','module',90,0),
('7512ebc7-0816-4348-b9a7-6791dfd9e977','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AOS_Product_Categories','module',90,0),
('77506d95-7230-486e-8677-efb8025de524','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Cases','module',90,0),
('78f9254d-aed4-441d-b499-5e2ccbec9184','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Project','module',90,0),
('792eb6e2-f8cf-4708-a6b1-6be7ab35946b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Opportunities','module',90,0),
('79a13227-fd3c-4e1d-96ec-c688200560b1','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','SurveyQuestionOptions','module',90,0),
('7a30f513-5350-42a6-a87d-74a9e23a0526','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','FP_events','module',90,0),
('7ad5929d-75b1-4650-a308-57f8eff69547','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Bugs','module',90,0),
('7b44f2c4-fd50-436b-ab0e-06cf3b8a3f72','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AM_ProjectTemplates','module',90,0),
('7b4aef47-41db-400b-bbaf-40954b9e00e7','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','jjwg_Areas','module',90,0),
('7b82dbca-1b07-4e11-86bf-5d06348bc254','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Calls_Reschedule','module',89,0),
('7b84d46d-bece-46d7-b904-3d2413ccc44f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AOS_PDF_Templates','module',90,0),
('7d4036b0-2552-4174-b1d9-14732d393751','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','FP_events','module',90,0),
('7d9d8c27-0676-4b1f-9375-8d0f715e1522','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AOK_Knowledge_Base_Categories','module',90,0),
('7e319e5a-1bf9-42a5-b4df-6b5f69d97233','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AM_ProjectTemplates','module',90,0),
('7e4640cf-cc3b-41d0-8fb1-554c50841ec5','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Meetings','module',90,0),
('7f7c9638-2be5-489e-9699-27929a5bfaf7','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','EAPM','module',90,0),
('804b62f6-629c-4100-a636-60948cef32ab','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Calls_Reschedule','module',90,0),
('810a4733-bec6-4bd5-869a-2eb86312c54e','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Cases','module',90,0),
('8301d63a-2e2c-4367-a6cc-dac7653270c3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','ManualMigrationTasks','module',90,0),
('8304a092-aec5-4ec7-a75c-119307aade29','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','EmailTemplates','module',89,0),
('836df51f-53e7-4330-8c2e-8c51866175e2','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Tasks','module',90,0),
('83e027de-c008-47e2-951b-5dfb2924433a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','CalendarAccount','module',89,0),
('84e4c32d-cd8e-4d8f-92fe-d42685f024f0','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Campaigns','module',90,0),
('8571fef7-bf4b-4884-9737-19d9c7516bb6','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Documents','module',90,0),
('85734c8e-40b8-4be7-8622-7c2a1b7468c0','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AOS_Invoices','module',90,0),
('85ac66a6-0c53-406e-9bbe-2ef70415a330','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AOS_Quotes','module',90,0),
('85bde668-0e2f-42e3-9a2a-c74568dff032','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AOR_Scheduled_Reports','module',90,0),
('870f1821-ce82-4f3e-a69d-b8ba958a8789','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Notes','module',89,0),
('8717ad4c-38bf-4128-9c9f-31f996dfc854','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','TemplateSectionLine','module',90,0),
('87a571ba-6d56-4dce-a509-0c9eee1c61d8','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AOW_WorkFlow','module',90,0),
('88007414-0949-4289-956f-28cb151d0702','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AM_TaskTemplates','module',90,0),
('880273e2-b1f9-4720-9b44-6c05460d32f0','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','CalendarAccount','module',90,0),
('88843b29-78a1-46cc-b0d0-88fb4dd73f06','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','FP_events','module',90,0),
('88a91e40-2f46-47ba-b400-2720b47d54a0','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AM_ProjectTemplates','module',90,0),
('89696faa-7e02-4c0f-9995-7426e44ad598','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Contacts','module',90,0),
('89d9418c-19f9-4dad-876a-3c828a5978f1','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','ProjectTask','module',90,0),
('8a7ea971-2978-4440-97e4-d764272fd4bd','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Calls_Reschedule','module',90,0),
('8af1d9af-c353-4477-8cea-c4206ffca41e','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','ExternalOAuthConnection','module',90,0),
('8b019511-5bb5-4f1e-9803-69c664b4ea99','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','SurveyResponses','module',90,0),
('8b2b1a72-4685-4b60-b6b3-dc2bcf817cbd','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','SurveyQuestions','module',90,0),
('8b93dfea-a07b-4fd7-be7a-3d1f53682f5c','2026-10-16 11:49:31','2026-10-16 11:49:31','1','1','export','RT_RadioCampaigns','module',90,0),
('8ba4c70c-4782-4f5b-9d7f-5222906053fc','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','SecurityGroups','module',90,0),
('8c59fc42-7e07-477a-8658-8fadfb8d244b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','jjwg_Maps','module',89,0),
('8c8b1df5-a30f-4fd7-ab5e-46ab14cd9f79','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Bugs','module',90,0),
('8dea9626-b794-461f-ad7d-d5c453e70863','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AOS_Invoices','module',90,0),
('8e06ab2e-697c-4566-b0d1-9d731c5a2ab4','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Bugs','module',90,0),
('8e310a27-a97c-44f7-8eaa-d0c6bd5ffe5d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Prospects','module',90,0),
('8e8a692f-7fba-4836-be60-b0a0f3fb514e','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Opportunities','module',90,0),
('8e978772-26fa-4f78-8ccd-783f60e0e7d0','2026-10-16 11:49:31','2026-10-16 11:49:31','1','1','access','RT_RadioCampaigns','module',89,0),
('8e9ad2c1-5294-4054-9c7e-8f284e0161dc','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','CalendarAccount','module',90,0),
('8f5f7fe5-9466-467b-bc37-83700ed67ce8','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Surveys','module',89,0),
('8f767733-b2a3-4737-9d30-f77f7ede677b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','FP_Event_Locations','module',89,0),
('8fa53b08-8f27-439b-aab4-3104a95f9bd1','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Leads','module',89,0),
('903ab0ca-77aa-4ab1-8a0c-c7e169a70f16','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AOS_PDF_Templates','module',90,0),
('908749d7-ba70-49ef-8a8f-8878b77e8779','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Calls_Reschedule','module',90,0),
('90ed0efb-abdc-4d5c-b02d-d9b83ee2056c','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','SurveyQuestionResponses','module',90,0),
('90ef9ef1-4a76-4624-a4bd-87cc46d6e89d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AOS_Invoices','module',90,0),
('917601b2-d3bb-49a7-a14e-a209fa965172','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','EAPM','module',89,0),
('9220d1a4-2232-4ce2-a25e-7c05656b2f41','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','MediaObjects','module',90,0),
('922a03a4-acd7-4819-9da1-b29bc862eea8','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','MediaObjects','module',90,0),
('92da7858-ed1f-40f2-8f71-a3232dae33e7','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Users','module',90,0),
('93104075-b6bb-4745-8ccb-276666e30487','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AOS_Products','module',90,0),
('9337ce7a-23b9-4fd4-a5a6-21e29a7274dc','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Users','module',90,0),
('94585beb-deeb-40a2-b93a-c3e701c4b50a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Accounts','module',90,0),
('94b36d4f-3f57-4f38-a450-694f8305c2be','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AOS_Contracts','module',90,0),
('9538aaf1-6821-4394-83ef-b42a12a978cb','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Documents','module',90,0),
('958113cd-95a1-41a1-a3a6-00895ca5abec','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Calls','module',90,0),
('95a27b25-6d95-4397-b640-41bb549f8cb6','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Tasks','module',90,0),
('95d8d321-8eba-4af1-a9dd-05e70a458da3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Leads','module',90,0),
('965a560d-8d28-4f9c-8f19-1bfd5de8797b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Leads','module',90,0),
('96ca8857-aa43-49ff-b6c0-08f6d50232cd','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','EAPM','module',90,0),
('96f67325-a9bb-49e9-9981-cd6889fab1f3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','ExternalOAuthConnection','module',90,0),
('9795e68e-beef-4578-9e53-436b13d653d7','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','SurveyQuestions','module',90,0),
('983ac4ca-855d-456e-ada0-19ab05785578','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','ManualMigrationTasks','module',90,0),
('98ba783d-147b-42a1-8044-fd97f90b387d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Processes','module',90,0),
('98bc75e1-7d39-40ef-975a-bf380b80d493','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','ProspectLists','module',90,0),
('98e9ef43-106c-45ce-afcd-25367294a5a2','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','SurveyResponses','module',90,0),
('99d83ec2-2af1-4247-9024-b9f5cbd93a95','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Tasks','module',90,0),
('9afb8f91-ae52-4c6e-aec2-d8d30f567dc9','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','InboundEmail','module',90,0),
('9b1aadcb-9e35-4e00-af88-90e3e13ccc6b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AOS_Contracts','module',90,0),
('9b5f03bf-fdf2-4904-b71e-204691d7ae09','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','SurveyQuestionResponses','module',90,0),
('9bd75382-3ce0-4b9d-8a03-2d59d42e1646','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Prospects','module',89,0),
('9dbb8d10-55f5-4fd1-b8f3-0cf17b9e4065','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Emails','module',90,0),
('9e43d7a0-7818-4909-ace3-764d8d85bd56','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Documents','module',90,0),
('9e98020c-e906-47cd-b078-d8aa93873001','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Campaigns','module',90,0),
('9ecb5b79-e999-4b42-b863-2f5a88a83a54','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','EAPM','module',90,0),
('9ed5acf4-42a5-4f1f-b39c-bc6b15219a85','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Campaigns','module',90,0),
('9fb1a616-a798-4fdb-a809-18ae8a14236f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','ProjectTask','module',90,0),
('a0ac0245-506f-44ac-a0af-be529ac97564','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','EmailMarketing','module',90,0),
('a1054154-7736-4dd0-bee7-a090f8532673','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','SurveyResponses','module',89,0),
('a11bb205-15cf-4c1d-808c-a08a9778be17','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AOP_Case_Updates','module',90,0),
('a14cb93b-cc9a-4ba2-aa0a-5970a19ccc23','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AsyncTaskItems','module',90,0),
('a231da6d-40d1-478c-b735-e7f82ad92d5c','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AOP_Case_Updates','module',90,0),
('a4addc10-729a-4cf4-b3d6-1297b9c61ee8','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','ExternalOAuthProvider','module',89,0),
('a5978ff0-ea5b-4cb4-b3ad-bb46aba700e7','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AOW_Processed','module',90,0),
('a5a09756-f26a-48b6-9080-f774407cac44','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','jjwg_Maps','module',90,0),
('a61733b9-f501-4736-a53b-eda8b91e3364','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','jjwg_Maps','module',90,0),
('a62ef44c-6f85-4c1c-b6a4-cc6a9a4ffafc','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Prospects','module',90,0),
('a63a2ce0-d5ca-4de8-8b11-cad5b7f86e20','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AOR_Reports','module',89,0),
('a63e2c2f-ed56-46e3-8ec6-39be3fe41849','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AOP_Case_Updates','module',89,0),
('a6e669f6-7b48-4d95-b618-b1b347cfb60d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AOW_Processed','module',90,0),
('a78eb305-180b-4180-b811-4aef0f4bb0ea','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Calls','module',90,0),
('a7f23498-9d7a-4784-9fa4-26e4a16fc73a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','SurveyQuestionOptions','module',90,0),
('a82ad375-cf51-44d6-b045-6dc0a4afb36b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','OutboundEmailAccounts','module',90,0),
('a8490374-e852-405a-ae06-1b2e54235588','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Alerts','module',90,0),
('a8638474-91de-4294-a2d6-30541ea22d45','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AOR_Scheduled_Reports','module',89,0),
('a88e9026-59f8-4720-8b0f-98d1e156038f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AOR_Reports','module',90,0),
('a8ea18eb-6228-4888-87ba-88634c82cb21','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','SurveyQuestionOptions','module',89,0),
('a937be02-7081-426f-8c5e-44991a1034f1','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','ProjectTask','module',90,0),
('aa5670ad-f629-453b-ab32-bf08cfcba89c','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Emails','module',90,0),
('aab909b2-c52d-41ce-8f54-e70b586b1c0b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AOR_Scheduled_Reports','module',90,0),
('aba5a4ac-ad4c-49ff-a855-6f4dc969245d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Project','module',90,0),
('abdcf628-499b-4c3f-988a-0a0455a15243','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','EmailMarketing','module',90,0),
('ac2c7c47-8dc3-453d-b80b-99b77eede2df','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','jjwg_Areas','module',90,0),
('adaf1bd9-b230-4d9c-b490-b3e261297097','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AOS_Quotes','module',90,0),
('adb41cf2-33ac-462c-af1a-b35aec026ce0','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Project','module',90,0),
('ae5bced1-a34d-4a7a-903d-8f59a1f82e7f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Bugs','module',90,0),
('ae7fc9d1-85ed-4b29-8529-107cef3c31fe','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','TemplateSectionLine','module',90,0),
('af1073f2-d1cd-45ba-abfc-ebcfe94c2aa5','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','FP_events','module',90,0),
('af1faf44-6f15-44c5-8d18-85998c76e45c','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Surveys','module',90,0),
('af2116ae-43bb-4690-ace1-db4503a26c05','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Calls_Reschedule','module',90,0),
('af60bcb1-95bd-45b7-b739-f647c021c31d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','jjwg_Markers','module',90,0),
('af7aeda3-61f6-40f7-a871-3529ed3d8329','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','SurveyQuestions','module',90,0),
('b0dd2c94-d42e-421e-ad86-b56376bf87c3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Calls_Reschedule','module',90,0),
('b28a4426-1389-45d7-a05c-8c5ed980ec32','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','SurveyQuestionResponses','module',90,0),
('b415ccec-6e70-45fc-b68e-ebc221758583','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','SurveyQuestionResponses','module',90,0),
('b48ac98e-4b83-42f4-8f0f-43e847d47ad6','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Emails','module',90,0),
('b4fed506-fe89-4012-aaee-7b6ec65d407b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','OutboundEmailAccounts','module',90,0),
('b5e17917-367e-4e2f-9590-3e40d2883569','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AOP_Case_Updates','module',90,0),
('b617a1b8-a4ba-4f71-8359-07976bad977f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','TemplateSectionLine','module',90,0),
('b67ccef9-0c88-48ef-aaee-884b89f884f2','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','ProjectTask','module',90,0),
('b7d4611f-cc0e-4be1-abec-241ba995d0ce','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','FP_events','module',89,0),
('b7f36d9f-ca69-4166-9ece-207e3a146ad5','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','EmailTemplates','module',90,0),
('b811cfcd-aebd-44de-83e9-7f26782b57ee','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','TemplateSectionLine','module',89,0),
('b82be649-b1e5-44fa-9468-015870826e57','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','EAPM','module',90,0),
('b8ab6e4c-5cba-47a4-9ef0-51797c747c35','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AOW_WorkFlow','module',90,0),
('b9169402-4a1b-4b39-87e1-c8ebbbcb8d3b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Processes','module',90,0),
('b9ba36a4-f7a2-43b2-8865-5a4b0ac62c55','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','FP_Event_Locations','module',90,0),
('b9cd330a-6635-4f50-aff8-8e443c889c8c','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Contacts','module',90,0),
('ba57258d-f03d-4cfb-bacc-c03fc200265d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AOR_Reports','module',90,0),
('bb0562b9-3fc1-4a41-b1f0-908c5bdc474f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Surveys','module',90,0),
('bb5fa044-71c9-45de-987a-b65cc3ec2011','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','SurveyQuestionResponses','module',90,0),
('bbb4e62f-478f-4253-a46e-c1dcf70b1955','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AsyncTaskItems','module',90,0),
('bc9981eb-bb42-45d4-b244-fb252792e62d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','OutboundEmailAccounts','module',90,0),
('bc9df49a-9a3c-40fc-805f-94aed3d149eb','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','ExternalOAuthProvider','module',90,0),
('be035172-abba-47eb-a6a9-7eb726b809a8','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','TemplateSectionLine','module',90,0),
('be993f73-1d13-412a-aefe-73b7c98dee50','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AsyncTaskItems','module',90,0),
('bf8b0b27-4ef9-4532-ac52-d7f30e8ea616','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','FP_events','module',90,0),
('bfe4c4a8-fb01-4b57-bc4c-63f0f039b2ad','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','EmailMarketing','module',90,0),
('c035fdb1-ae31-4263-8a26-3569dfd6c9b4','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','jjwg_Maps','module',90,0),
('c08f9d9a-8f0d-4e65-8b29-20a03a11cbac','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','TemplateSectionLine','module',90,0),
('c0f2ce9d-6c3b-44ee-96c9-f1bf087dc524','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Leads','module',90,0),
('c11975e5-4dab-42d1-b050-34ba5b6fd4e2','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Calls','module',90,0),
('c1636fdd-c368-4c18-b197-25ed7d4bb494','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','ExternalOAuthConnection','module',90,0),
('c2e0e57a-a402-4a08-860e-330ba6b9f058','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AOS_Products','module',89,0),
('c2ea3e72-f103-4285-a7d5-29cf3846e15b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','SurveyQuestionResponses','module',90,0),
('c33dfe73-395c-49f7-8688-5ffa6bc7c5bf','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','TemplateSectionLine','module',90,0),
('c3ce4595-e633-4bff-b995-c4f556f8ee59','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AsyncTaskItems','module',89,0),
('c3f44352-0375-4e9f-9a31-34c79b80bf56','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','ExternalOAuthProvider','module',90,0),
('c43445f1-0a04-445c-8e99-1c1f345328ef','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AOS_Products','module',90,0),
('c43c4c6f-ae2a-4b04-b357-17869e2c7cd2','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','jjwg_Address_Cache','module',90,0),
('c4aecc2a-50d2-4c87-8b62-2a76b2ee9ef4','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Processes','module',89,0),
('c4b8e770-bbc0-4c4a-aba7-14c8a62f72b3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','ProjectTask','module',90,0),
('c4bb1aca-2108-466e-b42c-7e1ecc77159a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Opportunities','module',90,0),
('c4d400aa-81b6-435c-b9e1-2c612dcd57a0','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Accounts','module',90,0),
('c541f7d9-6f48-45cf-836d-80eaa9c88f05','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Alerts','module',90,0),
('c57ce969-9b3a-45b7-b572-8d7f89eacb34','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Emails','module',90,0),
('c66d441d-5cbf-405c-bca1-12abbf8de91b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Opportunities','module',89,0),
('c6be33b3-2452-4636-9eec-698db9d53a1a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AOP_Case_Events','module',90,0),
('c76f803a-1f2b-4e1b-a07c-49ecafb6694e','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Campaigns','module',90,0),
('c866685f-d706-4d5e-9065-c62116c58c62','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','ProspectLists','module',90,0),
('c96afbc8-d828-4d4c-a187-f387d4bd8e84','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','SecurityGroups','module',90,0),
('ca63797b-bba0-48a3-bb42-36b60caeb9eb','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AOP_Case_Events','module',89,0),
('ca8a893d-85d0-4aaa-a775-d986541cf598','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','ManualMigrationTasks','module',90,0),
('caadfc43-347c-49d0-bffa-a8fd594a52eb','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Tasks','module',90,0),
('cb4d2a46-c1b3-4ac7-8e7e-1caebf9967ec','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AM_ProjectTemplates','module',90,0),
('cba5e5c4-15c2-4cf2-ba19-6df881329185','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','jjwg_Address_Cache','module',90,0),
('cc875c26-d798-47ac-8d7c-91c4bc7849d3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AOW_Processed','module',90,0),
('cd4abe18-2911-458d-ab07-710147967e73','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AOP_Case_Updates','module',90,0),
('cdb71c7e-acd3-47e3-aeda-17d930192b3e','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AOW_Processed','module',90,0),
('ce54c68a-0ea8-4601-a7bf-32b78fbd8639','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AOK_Knowledge_Base_Categories','module',90,0),
('ce9f79a5-4a1d-4051-9c6b-a84951448430','2026-10-16 11:49:31','2026-10-16 11:49:31','1','1','list','RT_RadioCampaigns','module',90,0),
('cee7af19-9efe-4938-9cfe-f71a48d15310','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AOS_Invoices','module',90,0),
('cfc6f22b-9cb8-4d93-87c1-21d32f6dc86f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AM_ProjectTemplates','module',90,0),
('cfd98652-0569-47ae-99be-92843977b814','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Calls','module',90,0),
('d27365a3-1c41-471a-8843-ce51ed8df420','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','SurveyQuestions','module',90,0),
('d330d65b-24c0-4ea2-85b5-087b7c8b701f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Campaigns','module',90,0),
('d409f39a-35db-4ff1-b108-9faa856f0c3b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','FP_Event_Locations','module',90,0),
('d46c2494-9be7-466c-90d0-6896f248f5c7','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Meetings','module',90,0),
('d4c64a29-e49d-4c4b-b008-2eb051c334ae','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','jjwg_Address_Cache','module',90,0),
('d4ea7e37-bfda-4cc9-8471-3cf587091761','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Meetings','module',90,0),
('d562f7fd-8a25-43ee-8679-4913543037ad','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Processes','module',90,0),
('d5e0102a-9cca-4720-8735-750c7a5bf390','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AOW_WorkFlow','module',89,0),
('d5fcc46d-ca13-474c-9dfd-c4059378db7d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AOS_Products','module',90,0),
('d6406cc6-7cf4-4975-8c42-4aa3e34d8780','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AOS_PDF_Templates','module',89,0),
('d69603d6-fbde-4182-8b5d-e21415d08b29','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Emails','module',90,0),
('d69c194e-e1e1-4e22-b12a-2fac628ef7f4','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AOR_Reports','module',90,0),
('d6ccc45e-73cb-4ef0-b0b6-21825910b1e9','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Cases','module',90,0),
('d6efc840-25c4-4cea-92a7-056b568e61c3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','jjwg_Areas','module',90,0),
('d7458338-4353-462d-b7bc-91a2aa7320d1','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','EmailTemplates','module',90,0),
('d85d7619-21f3-45fa-88a3-2a51bd447141','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Opportunities','module',90,0),
('d8daa12f-be2c-4cc7-8b1a-207843e69d6a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','MediaObjects','module',90,0),
('d9300b7b-1b96-498f-b98a-e48b95a5ee87','2026-10-16 11:49:31','2026-10-16 11:49:31','1','1','massupdate','RT_RadioCampaigns','module',90,0),
('d98b1af3-c540-45ef-998e-e6d724109feb','2026-10-16 11:49:31','2026-10-16 11:49:31','1','1','delete','RT_RadioCampaigns','module',90,0),
('da3a3630-1bc0-426f-a0db-da25f111f2ed','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AOP_Case_Updates','module',90,0),
('db0fc72f-ceaa-4072-ae9e-ae83e962abc4','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AOS_PDF_Templates','module',90,0),
('db310955-b2b9-42b4-8748-27602c643653','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AOS_Product_Categories','module',90,0),
('dc228af5-969f-49c9-8976-5c99285ce58e','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Contacts','module',90,0),
('dc6f5388-ad8a-4536-a1ad-a7290e536c10','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','EmailTemplates','module',90,0),
('dd25cbc1-55b8-4ebc-9649-fd7ce75c2b57','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','EmailMarketing','module',89,0),
('dd650024-d68f-4b6e-bb7c-e8c19a90ffff','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AM_TaskTemplates','module',90,0),
('ddcdd362-4333-42d6-8b64-e549608bb3fe','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Opportunities','module',90,0),
('de714474-e33b-413b-adb9-da510b791d23','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Tasks','module',90,0),
('de881e46-c190-430b-8743-cfe7e6f7a2f6','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Prospects','module',90,0),
('df280d55-42b3-443e-bfe9-577395d3d2aa','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AOS_Contracts','module',90,0),
('df3e642f-4276-4b62-8fb1-597413ac3203','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','ExternalOAuthConnection','module',90,0),
('e03665bb-ebe1-430c-bd96-bfc89a52fdc4','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','AOS_Contracts','module',90,0),
('e0e89aed-abd8-4fa9-8dd2-c7089918f43a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Surveys','module',90,0),
('e1f21495-b667-414c-8127-24f40f84ad8a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Calls','module',90,0),
('e21eb625-9630-487d-ac59-3651cbd2ea5a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','EmailTemplates','module',90,0),
('e2a0d926-83ae-4983-a7fc-9ecf47137a3f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AOS_Product_Categories','module',90,0),
('e2f65517-4cc0-4276-92df-fb7f61468909','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','ManualMigrationTasks','module',90,0),
('e3ac1a47-16c8-4a24-879d-d16136ef9a3a','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AOS_Product_Categories','module',90,0),
('e3fdce36-410d-44df-a30d-ff1628a7801d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Campaigns','module',90,0),
('e4567cf1-0e1c-4808-99a3-83dd9f0b68b5','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AOK_Knowledge_Base_Categories','module',90,0),
('e48538e1-4d5f-4553-96fb-cb6bd438ca98','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AOK_KnowledgeBase','module',90,0),
('e53ae3e2-ccfc-46ae-8185-f51929f0ff88','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Contacts','module',89,0),
('e58f5c61-3bcf-484d-8cd2-b369f536e0f7','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AOK_Knowledge_Base_Categories','module',90,0),
('e598a2ca-7ba3-40dd-a976-cab5d15328e1','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','ExternalOAuthProvider','module',90,0),
('e62cf872-0757-4f37-9deb-2a45765bfd01','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Documents','module',90,0),
('e6ec87b2-0dae-470d-bc6b-9566cbe37b8d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AM_TaskTemplates','module',90,0),
('e75ce51a-295f-4b2e-9c1c-7c747518b35c','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','AM_ProjectTemplates','module',90,0),
('e772fc04-aee6-429a-80f9-13229b45c70d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','EmailMarketing','module',90,0),
('e78d583b-98d7-4090-adda-ea211332e94e','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','jjwg_Maps','module',90,0),
('e85e76d4-5e64-4dd3-9c67-0d6b38290d7d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AOP_Case_Updates','module',90,0),
('e9bf8387-ae09-4beb-bbfd-6b58b54bf984','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Documents','module',90,0),
('e9ca2de9-1974-4e5c-b933-499af92be779','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','EmailMarketing','module',90,0),
('e9e9368b-0d15-42f7-8cb3-dc76636d0cf8','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','EAPM','module',90,0),
('ea5d4b7c-329a-4c7f-9119-8d59e7662f62','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','AM_TaskTemplates','module',90,0),
('eaa321e5-1e57-4025-82ab-8dc6c4dd24db','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','AOK_KnowledgeBase','module',90,0),
('eb282ea6-d50c-4de7-9bb9-68b01b92ce05','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','InboundEmail','module',89,0),
('ecf01741-8e24-4a28-82c2-dcbdd6951355','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','InboundEmail','module',90,0),
('ed172a35-3ac7-4061-9a08-86af88f103ed','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','Notes','module',90,0),
('ed973540-619c-4cf8-8589-d80ce3fa8cf7','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','SurveyResponses','module',90,0),
('ef7a2781-ad8f-470b-806b-3386beb5e7b8','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Processes','module',90,0),
('efaf1c64-e8b8-4b33-8821-81379d1d7146','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','EAPM','module',90,0),
('f051983e-890e-446a-820c-2d464b7a92e9','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','Contacts','module',90,0),
('f0be5ab8-ce91-4a10-85e4-a2e23163397c','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','ProspectLists','module',90,0),
('f0c2b28a-02d6-424d-906b-5a11ff6d9bef','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Contacts','module',90,0),
('f2bbfc09-fded-4e19-8ddd-9ef65f02d6a3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Bugs','module',89,0),
('f3101bb1-187c-4fb1-b829-036d9a7e22ef','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','Opportunities','module',90,0),
('f355c192-404f-40fd-8343-87b4e4070491','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','Calls','module',90,0),
('f3aed842-ddef-452b-bde7-169293997a63','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','jjwg_Address_Cache','module',90,0),
('f3d07d8d-7264-4446-b07d-dd34c0e48903','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','InboundEmail','module',90,0),
('f4125970-5bf3-44f3-85d9-30264624335e','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','SurveyQuestions','module',90,0),
('f4c0bdd8-6710-4a6b-9a87-1555495d8ee0','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Processes','module',90,0),
('f54693cf-0006-4f7e-a741-5be382dd965d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Meetings','module',90,0),
('f5ed56c4-a31c-4bfa-b14f-b1695efd13c5','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AOS_Quotes','module',89,0),
('f60fe332-bc55-40c2-90d9-b1b68bd67472','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AOK_Knowledge_Base_Categories','module',90,0),
('f64ff17f-ece6-4585-8e65-537fd4096d56','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','ExternalOAuthProvider','module',90,0),
('f669b96b-d778-4787-9d99-55fb5465fb1d','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','AOW_Processed','module',90,0),
('f7b49c1a-4de1-4e49-9d06-4a8fea4de032','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','SecurityGroups','module',90,0),
('f97572bf-6072-4e6e-ab88-f5a89a2f0ab3','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','AOK_Knowledge_Base_Categories','module',90,0),
('f99b1970-3408-4c68-b5b7-3317948fc733','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Calls','module',89,0),
('f9c51c31-e2c4-4b97-80c8-654660de9b5f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','EmailMarketing','module',90,0),
('fa4b044d-3374-46b2-9c55-8e2b198db4cd','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','SurveyQuestionOptions','module',90,0),
('faacb554-d0ea-4494-9f5b-c5f11734da56','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Users','module',90,0),
('fadaee80-ea62-4787-82e5-eab5d1ceae40','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','AM_TaskTemplates','module',89,0),
('fba02be3-2b5f-4a3e-aaed-6d7b38d55634','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','delete','AOS_Invoices','module',90,0),
('fc0d97b9-0640-4035-aae6-461bb5ad0e57','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','InboundEmail','module',90,0),
('fc2c539b-baf1-4f14-b806-b7c630b456c6','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','list','Prospects','module',90,0),
('fc40bd6d-eb5e-4e45-ad95-8ca2d14f633b','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','jjwg_Address_Cache','module',90,0),
('fc52562c-79c2-481d-a5c4-cd45fbf5b508','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','SurveyResponses','module',90,0),
('fc7717ba-1621-41a2-8212-ad61107dd891','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','OutboundEmailAccounts','module',89,0),
('fcd7ec7e-e472-4592-bfc5-b0df59f34d48','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','edit','FP_events','module',90,0),
('fd4d258c-b54b-42bc-9071-20f3d3bddd09','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','import','Notes','module',90,0),
('fd71ac46-7575-4f9e-ab8c-8b4595109809','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','view','TemplateSectionLine','module',90,0),
('ff1c5524-e3b2-4eda-82b3-e8cb2e8baf34','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Project','module',89,0),
('ff9e8bae-cba6-49ff-9d24-a59b0def22df','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','access','Users','module',89,0),
('ffb55cc8-2955-4589-8e29-6fbd5e484510','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','export','ProjectTask','module',90,0),
('ffea7149-e725-4dd5-8cf2-5fd111e4b371','2026-10-16 10:57:58','2026-10-16 10:57:58','1','','massupdate','Notes','module',90,0);
/*!40000 ALTER TABLE `acl_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acl_roles`
--

DROP TABLE IF EXISTS `acl_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `acl_roles` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aclrole_id_del` (`id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acl_roles`
--

LOCK TABLES `acl_roles` WRITE;
/*!40000 ALTER TABLE `acl_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `acl_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acl_roles_actions`
--

DROP TABLE IF EXISTS `acl_roles_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `acl_roles_actions` (
  `id` varchar(36) NOT NULL,
  `role_id` varchar(36) DEFAULT NULL,
  `action_id` varchar(36) DEFAULT NULL,
  `access_override` int(3) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_acl_role_id` (`role_id`),
  KEY `idx_acl_action_id` (`action_id`),
  KEY `idx_aclrole_action` (`role_id`,`action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acl_roles_actions`
--

LOCK TABLES `acl_roles_actions` WRITE;
/*!40000 ALTER TABLE `acl_roles_actions` DISABLE KEYS */;
INSERT INTO `acl_roles_actions` VALUES
('20ce3365-539a-4e92-8b2d-6539f1326077','85435230-7b89-4b8d-ab26-6fa809a78e8f','8e978772-26fa-4f78-8ccd-783f60e0e7d0',89,'2026-10-16 11:49:35',0),
('3ae3057d-fcee-4af6-abc5-f2076b7c8f83','85435230-7b89-4b8d-ab26-6fa809a78e8f','2aece5de-f072-4f7d-8d7e-914bb5f23c28',75,'2026-10-16 11:49:35',0),
('490d0057-c3ea-4340-bba1-4543f6516807','85435230-7b89-4b8d-ab26-6fa809a78e8f','8b93dfea-a07b-4fd7-be7a-3d1f53682f5c',75,'2026-10-16 11:49:35',0),
('f2cc1cad-06fe-4899-916e-e2b34dc02024','85435230-7b89-4b8d-ab26-6fa809a78e8f','0b8c2eb9-392d-44ee-914d-c0f15fc2c3ca',75,'2026-10-16 11:49:35',0);
/*!40000 ALTER TABLE `acl_roles_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acl_roles_users`
--

DROP TABLE IF EXISTS `acl_roles_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `acl_roles_users` (
  `id` varchar(36) NOT NULL,
  `role_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_aclrole_id` (`role_id`),
  KEY `idx_acluser_id` (`user_id`),
  KEY `idx_aclrole_user` (`role_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acl_roles_users`
--

LOCK TABLES `acl_roles_users` WRITE;
/*!40000 ALTER TABLE `acl_roles_users` DISABLE KEYS */;
INSERT INTO `acl_roles_users` VALUES
('31a220db-a316-4597-a046-7791cdc89e4a','c96fe65b-6f50-4ed7-b861-0b960556f203','2a018328-e84c-48db-b26c-167d7bee0dbe','2026-10-16 11:47:04',0),
('56a96d7f-e0f2-4b95-94e2-81ad92f40dfe','85435230-7b89-4b8d-ab26-6fa809a78e8f','fb67dd97-b99c-47c8-9585-e82aa8827fd6','2026-10-16 11:49:35',0);
/*!40000 ALTER TABLE `acl_roles_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `address_book`
--

DROP TABLE IF EXISTS `address_book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `address_book` (
  `assigned_user_id` char(36) NOT NULL,
  `bean` varchar(50) DEFAULT NULL,
  `bean_id` char(36) NOT NULL,
  KEY `ab_user_bean_idx` (`assigned_user_id`,`bean`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address_book`
--

LOCK TABLES `address_book` WRITE;
/*!40000 ALTER TABLE `address_book` DISABLE KEYS */;
/*!40000 ALTER TABLE `address_book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alerts`
--

DROP TABLE IF EXISTS `alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `alerts` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `target_module` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `url_redirect` varchar(255) DEFAULT NULL,
  `reminder_id` char(36) DEFAULT NULL,
  `snooze` datetime DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alerts`
--

LOCK TABLES `alerts` WRITE;
/*!40000 ALTER TABLE `alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_projecttemplates`
--

DROP TABLE IF EXISTS `am_projecttemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `am_projecttemplates` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Draft',
  `priority` varchar(100) DEFAULT 'High',
  `override_business_hours` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_projecttemplates`
--

LOCK TABLES `am_projecttemplates` WRITE;
/*!40000 ALTER TABLE `am_projecttemplates` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_projecttemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_projecttemplates_audit`
--

DROP TABLE IF EXISTS `am_projecttemplates_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `am_projecttemplates_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_am_projecttemplates_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_projecttemplates_audit`
--

LOCK TABLES `am_projecttemplates_audit` WRITE;
/*!40000 ALTER TABLE `am_projecttemplates_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_projecttemplates_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_projecttemplates_contacts_1_c`
--

DROP TABLE IF EXISTS `am_projecttemplates_contacts_1_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `am_projecttemplates_contacts_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `am_projecttemplates_ida` varchar(36) DEFAULT NULL,
  `contacts_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `am_projecttemplates_contacts_1_alt` (`am_projecttemplates_ida`,`contacts_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_projecttemplates_contacts_1_c`
--

LOCK TABLES `am_projecttemplates_contacts_1_c` WRITE;
/*!40000 ALTER TABLE `am_projecttemplates_contacts_1_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_projecttemplates_contacts_1_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_projecttemplates_project_1_c`
--

DROP TABLE IF EXISTS `am_projecttemplates_project_1_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `am_projecttemplates_project_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `am_projecttemplates_project_1am_projecttemplates_ida` varchar(36) DEFAULT NULL,
  `am_projecttemplates_project_1project_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `am_projecttemplates_project_1_ida1` (`am_projecttemplates_project_1am_projecttemplates_ida`),
  KEY `am_projecttemplates_project_1_alt` (`am_projecttemplates_project_1project_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_projecttemplates_project_1_c`
--

LOCK TABLES `am_projecttemplates_project_1_c` WRITE;
/*!40000 ALTER TABLE `am_projecttemplates_project_1_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_projecttemplates_project_1_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_projecttemplates_users_1_c`
--

DROP TABLE IF EXISTS `am_projecttemplates_users_1_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `am_projecttemplates_users_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `am_projecttemplates_ida` varchar(36) DEFAULT NULL,
  `users_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `am_projecttemplates_users_1_alt` (`am_projecttemplates_ida`,`users_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_projecttemplates_users_1_c`
--

LOCK TABLES `am_projecttemplates_users_1_c` WRITE;
/*!40000 ALTER TABLE `am_projecttemplates_users_1_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_projecttemplates_users_1_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_tasktemplates`
--

DROP TABLE IF EXISTS `am_tasktemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `am_tasktemplates` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Not Started',
  `priority` varchar(100) DEFAULT 'High',
  `percent_complete` int(255) DEFAULT 0,
  `predecessors` int(255) DEFAULT NULL,
  `milestone_flag` tinyint(1) DEFAULT 0,
  `relationship_type` varchar(100) DEFAULT 'FS',
  `task_number` int(255) DEFAULT NULL,
  `order_number` int(255) DEFAULT NULL,
  `estimated_effort` int(255) DEFAULT NULL,
  `utilization` varchar(100) DEFAULT '0',
  `duration` int(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_tasktemplates`
--

LOCK TABLES `am_tasktemplates` WRITE;
/*!40000 ALTER TABLE `am_tasktemplates` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_tasktemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_tasktemplates_am_projecttemplates_c`
--

DROP TABLE IF EXISTS `am_tasktemplates_am_projecttemplates_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `am_tasktemplates_am_projecttemplates_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `am_tasktemplates_am_projecttemplatesam_projecttemplates_ida` varchar(36) DEFAULT NULL,
  `am_tasktemplates_am_projecttemplatesam_tasktemplates_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `am_tasktemplates_am_projecttemplates_ida1` (`am_tasktemplates_am_projecttemplatesam_projecttemplates_ida`),
  KEY `am_tasktemplates_am_projecttemplates_alt` (`am_tasktemplates_am_projecttemplatesam_tasktemplates_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_tasktemplates_am_projecttemplates_c`
--

LOCK TABLES `am_tasktemplates_am_projecttemplates_c` WRITE;
/*!40000 ALTER TABLE `am_tasktemplates_am_projecttemplates_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_tasktemplates_am_projecttemplates_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_tasktemplates_audit`
--

DROP TABLE IF EXISTS `am_tasktemplates_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `am_tasktemplates_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_am_tasktemplates_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_tasktemplates_audit`
--

LOCK TABLES `am_tasktemplates_audit` WRITE;
/*!40000 ALTER TABLE `am_tasktemplates_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_tasktemplates_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aobh_businesshours`
--

DROP TABLE IF EXISTS `aobh_businesshours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aobh_businesshours` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `opening_hours` varchar(100) DEFAULT '1',
  `closing_hours` varchar(100) DEFAULT '1',
  `open_status` tinyint(1) DEFAULT NULL,
  `day` varchar(100) DEFAULT 'monday',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aobh_businesshours`
--

LOCK TABLES `aobh_businesshours` WRITE;
/*!40000 ALTER TABLE `aobh_businesshours` DISABLE KEYS */;
/*!40000 ALTER TABLE `aobh_businesshours` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aok_knowledge_base_categories`
--

DROP TABLE IF EXISTS `aok_knowledge_base_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aok_knowledge_base_categories` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aok_knowledge_base_categories`
--

LOCK TABLES `aok_knowledge_base_categories` WRITE;
/*!40000 ALTER TABLE `aok_knowledge_base_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `aok_knowledge_base_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aok_knowledge_base_categories_audit`
--

DROP TABLE IF EXISTS `aok_knowledge_base_categories_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aok_knowledge_base_categories_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aok_knowledge_base_categories_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aok_knowledge_base_categories_audit`
--

LOCK TABLES `aok_knowledge_base_categories_audit` WRITE;
/*!40000 ALTER TABLE `aok_knowledge_base_categories_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aok_knowledge_base_categories_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aok_knowledgebase`
--

DROP TABLE IF EXISTS `aok_knowledgebase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aok_knowledgebase` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Draft',
  `revision` varchar(255) DEFAULT NULL,
  `additional_info` text DEFAULT NULL,
  `user_id_c` char(36) DEFAULT NULL,
  `user_id1_c` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aok_knowledgebase`
--

LOCK TABLES `aok_knowledgebase` WRITE;
/*!40000 ALTER TABLE `aok_knowledgebase` DISABLE KEYS */;
/*!40000 ALTER TABLE `aok_knowledgebase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aok_knowledgebase_audit`
--

DROP TABLE IF EXISTS `aok_knowledgebase_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aok_knowledgebase_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aok_knowledgebase_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aok_knowledgebase_audit`
--

LOCK TABLES `aok_knowledgebase_audit` WRITE;
/*!40000 ALTER TABLE `aok_knowledgebase_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aok_knowledgebase_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aok_knowledgebase_categories`
--

DROP TABLE IF EXISTS `aok_knowledgebase_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aok_knowledgebase_categories` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `aok_knowledgebase_id` varchar(36) DEFAULT NULL,
  `aok_knowledge_base_categories_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aok_knowledgebase_categories_alt` (`aok_knowledgebase_id`,`aok_knowledge_base_categories_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aok_knowledgebase_categories`
--

LOCK TABLES `aok_knowledgebase_categories` WRITE;
/*!40000 ALTER TABLE `aok_knowledgebase_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `aok_knowledgebase_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aop_case_events`
--

DROP TABLE IF EXISTS `aop_case_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aop_case_events` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `case_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aop_case_events`
--

LOCK TABLES `aop_case_events` WRITE;
/*!40000 ALTER TABLE `aop_case_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `aop_case_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aop_case_events_audit`
--

DROP TABLE IF EXISTS `aop_case_events_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aop_case_events_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aop_case_events_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aop_case_events_audit`
--

LOCK TABLES `aop_case_events_audit` WRITE;
/*!40000 ALTER TABLE `aop_case_events_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aop_case_events_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aop_case_updates`
--

DROP TABLE IF EXISTS `aop_case_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aop_case_updates` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `case_id` char(36) DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `internal` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aop_case_updates`
--

LOCK TABLES `aop_case_updates` WRITE;
/*!40000 ALTER TABLE `aop_case_updates` DISABLE KEYS */;
/*!40000 ALTER TABLE `aop_case_updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aop_case_updates_audit`
--

DROP TABLE IF EXISTS `aop_case_updates_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aop_case_updates_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aop_case_updates_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aop_case_updates_audit`
--

LOCK TABLES `aop_case_updates_audit` WRITE;
/*!40000 ALTER TABLE `aop_case_updates_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aop_case_updates_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aor_charts`
--

DROP TABLE IF EXISTS `aor_charts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aor_charts` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `aor_report_id` char(36) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `x_field` int(11) DEFAULT NULL,
  `y_field` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aor_charts`
--

LOCK TABLES `aor_charts` WRITE;
/*!40000 ALTER TABLE `aor_charts` DISABLE KEYS */;
/*!40000 ALTER TABLE `aor_charts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aor_conditions`
--

DROP TABLE IF EXISTS `aor_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aor_conditions` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `aor_report_id` char(36) DEFAULT NULL,
  `condition_order` int(255) DEFAULT NULL,
  `logic_op` varchar(255) DEFAULT NULL,
  `parenthesis` varchar(255) DEFAULT NULL,
  `module_path` longtext DEFAULT NULL,
  `field` varchar(100) DEFAULT NULL,
  `operator` varchar(100) DEFAULT NULL,
  `value_type` varchar(100) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `parameter` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aor_conditions_index_report_id` (`aor_report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aor_conditions`
--

LOCK TABLES `aor_conditions` WRITE;
/*!40000 ALTER TABLE `aor_conditions` DISABLE KEYS */;
/*!40000 ALTER TABLE `aor_conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aor_fields`
--

DROP TABLE IF EXISTS `aor_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aor_fields` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `aor_report_id` char(36) DEFAULT NULL,
  `field_order` int(255) DEFAULT NULL,
  `module_path` longtext DEFAULT NULL,
  `field` varchar(100) DEFAULT NULL,
  `display` tinyint(1) DEFAULT NULL,
  `link` tinyint(1) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `field_function` varchar(100) DEFAULT NULL,
  `sort_by` varchar(100) DEFAULT NULL,
  `format` varchar(100) DEFAULT NULL,
  `total` varchar(100) DEFAULT NULL,
  `sort_order` varchar(100) DEFAULT NULL,
  `group_by` tinyint(1) DEFAULT NULL,
  `group_order` varchar(100) DEFAULT NULL,
  `group_display` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aor_fields_index_report_id` (`aor_report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aor_fields`
--

LOCK TABLES `aor_fields` WRITE;
/*!40000 ALTER TABLE `aor_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `aor_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aor_reports`
--

DROP TABLE IF EXISTS `aor_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aor_reports` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `report_module` varchar(100) DEFAULT NULL,
  `graphs_per_row` int(11) DEFAULT 2,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aor_reports`
--

LOCK TABLES `aor_reports` WRITE;
/*!40000 ALTER TABLE `aor_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `aor_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aor_reports_audit`
--

DROP TABLE IF EXISTS `aor_reports_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aor_reports_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aor_reports_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aor_reports_audit`
--

LOCK TABLES `aor_reports_audit` WRITE;
/*!40000 ALTER TABLE `aor_reports_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aor_reports_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aor_scheduled_reports`
--

DROP TABLE IF EXISTS `aor_scheduled_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aor_scheduled_reports` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `schedule` varchar(100) DEFAULT NULL,
  `last_run` datetime DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `email_recipients` longtext DEFAULT NULL,
  `aor_report_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aor_scheduled_reports`
--

LOCK TABLES `aor_scheduled_reports` WRITE;
/*!40000 ALTER TABLE `aor_scheduled_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `aor_scheduled_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_contracts`
--

DROP TABLE IF EXISTS `aos_contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_contracts` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `reference_code` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `total_contract_value` decimal(26,6) DEFAULT NULL,
  `total_contract_value_usdollar` decimal(26,6) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Not Started',
  `customer_signed_date` date DEFAULT NULL,
  `company_signed_date` date DEFAULT NULL,
  `renewal_reminder_date` datetime DEFAULT NULL,
  `contract_type` varchar(100) DEFAULT 'Type',
  `contract_account_id` char(36) DEFAULT NULL,
  `opportunity_id` char(36) DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `call_id` char(36) DEFAULT NULL,
  `total_amt` decimal(26,6) DEFAULT NULL,
  `total_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `subtotal_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `discount_amount` decimal(26,6) DEFAULT NULL,
  `discount_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `tax_amount` decimal(26,6) DEFAULT NULL,
  `tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_amount` decimal(26,6) DEFAULT NULL,
  `shipping_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_tax` varchar(100) DEFAULT NULL,
  `shipping_tax_amt` decimal(26,6) DEFAULT NULL,
  `shipping_tax_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `total_amount` decimal(26,6) DEFAULT NULL,
  `total_amount_usdollar` decimal(26,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_contracts`
--

LOCK TABLES `aos_contracts` WRITE;
/*!40000 ALTER TABLE `aos_contracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_contracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_contracts_audit`
--

DROP TABLE IF EXISTS `aos_contracts_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_contracts_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aos_contracts_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_contracts_audit`
--

LOCK TABLES `aos_contracts_audit` WRITE;
/*!40000 ALTER TABLE `aos_contracts_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_contracts_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_contracts_documents`
--

DROP TABLE IF EXISTS `aos_contracts_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_contracts_documents` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `aos_contracts_id` varchar(36) DEFAULT NULL,
  `documents_id` varchar(36) DEFAULT NULL,
  `document_revision_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aos_contracts_documents_alt` (`aos_contracts_id`,`documents_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_contracts_documents`
--

LOCK TABLES `aos_contracts_documents` WRITE;
/*!40000 ALTER TABLE `aos_contracts_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_contracts_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_invoices`
--

DROP TABLE IF EXISTS `aos_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_invoices` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `billing_account_id` char(36) DEFAULT NULL,
  `billing_contact_id` char(36) DEFAULT NULL,
  `billing_address_street` varchar(150) DEFAULT NULL,
  `billing_address_city` varchar(100) DEFAULT NULL,
  `billing_address_state` varchar(100) DEFAULT NULL,
  `billing_address_postalcode` varchar(20) DEFAULT NULL,
  `billing_address_country` varchar(255) DEFAULT NULL,
  `shipping_address_street` varchar(150) DEFAULT NULL,
  `shipping_address_city` varchar(100) DEFAULT NULL,
  `shipping_address_state` varchar(100) DEFAULT NULL,
  `shipping_address_postalcode` varchar(20) DEFAULT NULL,
  `shipping_address_country` varchar(255) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `total_amt` decimal(26,6) DEFAULT NULL,
  `total_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `subtotal_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `discount_amount` decimal(26,6) DEFAULT NULL,
  `discount_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `tax_amount` decimal(26,6) DEFAULT NULL,
  `tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_amount` decimal(26,6) DEFAULT NULL,
  `shipping_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_tax` varchar(100) DEFAULT NULL,
  `shipping_tax_amt` decimal(26,6) DEFAULT NULL,
  `shipping_tax_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `total_amount` decimal(26,6) DEFAULT NULL,
  `total_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `quote_number` int(11) DEFAULT NULL,
  `quote_date` date DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `template_ddown_c` text DEFAULT NULL,
  `subtotal_tax_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_invoices`
--

LOCK TABLES `aos_invoices` WRITE;
/*!40000 ALTER TABLE `aos_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_invoices_audit`
--

DROP TABLE IF EXISTS `aos_invoices_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_invoices_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aos_invoices_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_invoices_audit`
--

LOCK TABLES `aos_invoices_audit` WRITE;
/*!40000 ALTER TABLE `aos_invoices_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_invoices_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_line_item_groups`
--

DROP TABLE IF EXISTS `aos_line_item_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_line_item_groups` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `total_amt` decimal(26,6) DEFAULT NULL,
  `total_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `discount_amount` decimal(26,6) DEFAULT NULL,
  `discount_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `subtotal_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `tax_amount` decimal(26,6) DEFAULT NULL,
  `tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `subtotal_tax_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `total_amount` decimal(26,6) DEFAULT NULL,
  `total_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_line_item_groups`
--

LOCK TABLES `aos_line_item_groups` WRITE;
/*!40000 ALTER TABLE `aos_line_item_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_line_item_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_line_item_groups_audit`
--

DROP TABLE IF EXISTS `aos_line_item_groups_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_line_item_groups_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aos_line_item_groups_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_line_item_groups_audit`
--

LOCK TABLES `aos_line_item_groups_audit` WRITE;
/*!40000 ALTER TABLE `aos_line_item_groups_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_line_item_groups_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_pdf_templates`
--

DROP TABLE IF EXISTS `aos_pdf_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_pdf_templates` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `active` tinyint(1) DEFAULT 1,
  `type` varchar(100) DEFAULT NULL,
  `pdfheader` longtext DEFAULT NULL,
  `pdffooter` longtext DEFAULT NULL,
  `margin_left` int(255) DEFAULT 15,
  `margin_right` int(255) DEFAULT 15,
  `margin_top` int(255) DEFAULT 16,
  `margin_bottom` int(255) DEFAULT 16,
  `margin_header` int(255) DEFAULT 9,
  `margin_footer` int(255) DEFAULT 9,
  `page_size` varchar(100) DEFAULT NULL,
  `orientation` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_pdf_templates`
--

LOCK TABLES `aos_pdf_templates` WRITE;
/*!40000 ALTER TABLE `aos_pdf_templates` DISABLE KEYS */;
INSERT INTO `aos_pdf_templates` VALUES
('f4b47a53-2fc1-469c-a5c2-fae4dba3cf55','Standard Radio Quote PDF','2026-10-16 11:21:46','2026-10-20 21:01:40','1','1','<table width=\"100%\" cellpadding=\"6\" cellspacing=\"0\"><tr><td width=\"48%\" bgcolor=\"#F3EEF7\"><font size=\"10\" color=\"#6B2C91\"><b>PREPARED FOR</b></font><br /><font size=\"9\"><b>$aos_quotes_billing_account</b><br />Attn: $aos_quotes_billing_contact</font></td><td width=\"4%\"></td><td width=\"48%\" bgcolor=\"#F3EEF7\"><font size=\"10\" color=\"#6B2C91\"><b>QUOTE DETAILS</b></font><br /><font size=\"9\"><b>Quote No:</b> #$aos_quotes_number<br /><b>Reference:</b> $aos_quotes_name<br /><b>Campaign Start:</b> $aos_quotes_campaign_start_date_c<br /><b>Campaign End:</b> $aos_quotes_campaign_end_date_c</font></td></tr></table><br /><table width=\"100%\" cellpadding=\"5\" cellspacing=\"0\" border=\"0\"><tr bgcolor=\"#6B2C91\"><td width=\"8%\" align=\"center\"><font size=\"9\" color=\"#FFFFFF\"><b>Qty</b></font></td><td width=\"26%\"><font size=\"9\" color=\"#FFFFFF\"><b>Product</b></font></td><td width=\"30%\"><font size=\"9\" color=\"#FFFFFF\"><b>Description</b></font></td><td width=\"12%\" align=\"right\"><font size=\"9\" color=\"#FFFFFF\"><b>Unit Price</b></font></td><td width=\"12%\" align=\"right\"><font size=\"9\" color=\"#FFFFFF\"><b>VAT</b></font></td><td width=\"12%\" align=\"right\"><font size=\"9\" color=\"#FFFFFF\"><b>Total</b></font></td></tr><tr><td width=\"8%\" align=\"center\" style=\"border-bottom: 1px solid #DDDDDD;\"><font size=\"9\">$aos_products_quotes_product_qty</font></td><td width=\"26%\" style=\"border-bottom: 1px solid #DDDDDD;\"><font size=\"9\"><b>$aos_products_quotes_name</b></font><br /><font size=\"7\" color=\"#5F6B78\">$aos_products_quotes_part_number</font></td><td width=\"30%\" style=\"border-bottom: 1px solid #DDDDDD;\"><font size=\"8\">$aos_products_quotes_item_description</font></td><td width=\"12%\" align=\"right\" style=\"border-bottom: 1px solid #DDDDDD;\"><font size=\"9\">$aos_products_quotes_product_unit_price</font></td><td width=\"12%\" align=\"right\" style=\"border-bottom: 1px solid #DDDDDD;\"><font size=\"9\">$aos_products_quotes_vat_amt</font></td><td width=\"12%\" align=\"right\" style=\"border-bottom: 1px solid #DDDDDD;\"><font size=\"9\"><b>$aos_products_quotes_product_total_price</b></font></td></tr></table><br /><table width=\"100%\" cellpadding=\"5\" cellspacing=\"0\"><tr><td width=\"56%\"></td><td width=\"24%\"><font size=\"10\" color=\"#5F6B78\">Subtotal (Net)</font></td><td width=\"20%\" align=\"right\"><font size=\"10\">$aos_quotes_subtotal_amount</font></td></tr><tr><td width=\"56%\"></td><td width=\"24%\"><font size=\"10\" color=\"#5F6B78\">VAT (15%)</font></td><td width=\"20%\" align=\"right\"><font size=\"10\">$aos_quotes_tax_amount</font></td></tr><tr><td width=\"56%\"></td><td width=\"24%\" bgcolor=\"#1A8CA3\"><font size=\"10\" color=\"#FFFFFF\"><b>TOTAL (Incl. VAT)</b></font></td><td width=\"20%\" bgcolor=\"#1A8CA3\" align=\"right\"><font size=\"10\" color=\"#FFFFFF\"><b>$aos_quotes_total_amount</b></font></td></tr></table><br /><br /><font size=\"8\" color=\"#5F6B78\">All amounts are in South African Rand (ZAR). This quotation is subject to standard radio advertising terms and conditions.</font>',0,'1',1,'AOS_Quotes','<table width=\"100%\" cellpadding=\"2\" cellspacing=\"0\">\n<tr>\n<td width=\"16%\"><img src=\"http://84.8.141.105/legacy/custom/include/RadioCRM/pukfm_logo_round.jpeg\" width=\"62\" height=\"62\" /></td>\n<td width=\"50%\"><font size=\"15\" color=\"#6B2C91\"><b>PUKfm 93.6</b></font><br /><font size=\"8\" color=\"#5F6B78\">Hear the beat of campus</font></td>\n<td width=\"34%\" align=\"right\"><font size=\"20\" color=\"#1A8CA3\"><b>QUOTATION</b></font></td>\n</tr>\n</table>\n<hr />','<hr /><table width=\"100%\" cellpadding=\"2\" cellspacing=\"0\"><tr><td width=\"75%\"><font size=\"8\" color=\"#5F6B78\">PUKfm 93.6 | Hear the beat of campus</font></td><td width=\"25%\" align=\"right\"><font size=\"8\" color=\"#5F6B78\">Page {PAGENO}</font></td></tr></table>',15,15,38,20,8,8,'A4','Portrait');
/*!40000 ALTER TABLE `aos_pdf_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_pdf_templates_audit`
--

DROP TABLE IF EXISTS `aos_pdf_templates_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_pdf_templates_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aos_pdf_templates_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_pdf_templates_audit`
--

LOCK TABLES `aos_pdf_templates_audit` WRITE;
/*!40000 ALTER TABLE `aos_pdf_templates_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_pdf_templates_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_product_categories`
--

DROP TABLE IF EXISTS `aos_product_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_product_categories` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `is_parent` tinyint(1) DEFAULT 0,
  `parent_category_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_product_categories`
--

LOCK TABLES `aos_product_categories` WRITE;
/*!40000 ALTER TABLE `aos_product_categories` DISABLE KEYS */;
INSERT INTO `aos_product_categories` VALUES
('0dddc97f-f1d4-4011-886d-91d482665412','Live Reads (30 Seconds)','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Radio Advertising Rates: Live Reads (30 Seconds) (Monday-Friday & Saturday-Sunday). Prices exclude VAT.',0,'1',0,NULL),
('1580dc4d-116e-4aa4-ab84-4e7703f5d028','Recorded Ads (30 Seconds)','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Radio Advertising Rates: Recorded Ads (30 Seconds) (Monday-Friday & Saturday-Sunday). Prices exclude VAT.',0,'1',0,NULL),
('37df3010-4e9b-47f0-8c0c-5dad0ffe4629','Misc. Rates','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Miscellaneous Rates (Interviews, Powerspots, Sponsored Content Segments, Outside Broadcasts, Simulcasts). Prices exclude VAT.',0,'1',0,NULL),
('68b79f0b-dbd2-426c-906e-57ba0e88a0f2','Advertising Packages','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Weekly and Monthly Prime Time Advertising Packages (Options 1 to 4). Prices exclude VAT.',0,'1',0,NULL),
('99f8d224-f85b-463e-98b6-4764d29c1792','Social Media Advertising','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Social Media Advertising Rates (@stationhandle on Facebook, TikTok, Instagram, Twitter/X). Prices exclude VAT.',0,'1',0,NULL),
('caf0c6c8-dcce-46cc-b6a4-6dc94177018d','Radio Programme Schedule','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio station weekly programme schedule slots for automated quote schedule calculation.',0,'1',0,NULL);
/*!40000 ALTER TABLE `aos_product_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_product_categories_audit`
--

DROP TABLE IF EXISTS `aos_product_categories_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_product_categories_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aos_product_categories_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_product_categories_audit`
--

LOCK TABLES `aos_product_categories_audit` WRITE;
/*!40000 ALTER TABLE `aos_product_categories_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_product_categories_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_products`
--

DROP TABLE IF EXISTS `aos_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_products` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `maincode` varchar(100) DEFAULT 'XXXX',
  `part_number` varchar(25) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT 'Good',
  `cost` decimal(26,6) DEFAULT NULL,
  `cost_usdollar` decimal(26,6) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `price` decimal(26,6) DEFAULT NULL,
  `price_usdollar` decimal(26,6) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `product_image` varchar(255) DEFAULT NULL,
  `aos_product_category_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_products`
--

LOCK TABLES `aos_products` WRITE;
/*!40000 ALTER TABLE `aos_products` DISABLE KEYS */;
INSERT INTO `aos_products` VALUES
('026f85c4-b2ba-4f31-a3c4-f5c636ce928b','Radio Advert: Specialty Show 1 (Evening) (18:00 - 21:00)','2026-10-16 11:21:46','2026-10-20 21:01:40','1','1','One 30 second prerecorded advertisement played between 18:00 and 21:00.',0,'1','XXXX','SPECIALTY-SHOW-1',NULL,'Good',300.000000,0.000000,'-99',300.000000,300.000000,NULL,NULL,NULL,'caf0c6c8-dcce-46cc-b6a4-6dc94177018d'),
('07124e99-fa26-444e-9d81-e687d15f2b6f','Live Read (30s) - Mon-Fri 21:00 - 00:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Live Reads (30 Seconds), Monday to Friday, 21:00 - 00:00. Price excludes VAT.',0,'1','XXXX','LIVE-30S-MF-2100-0000',NULL,'Good',0.000000,0.000000,'-99',250.000000,250.000000,NULL,NULL,NULL,'0dddc97f-f1d4-4011-886d-91d482665412'),
('0a310d7e-3997-4bd3-95c7-af0758565c36','TikTok - Story/Post Combo','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Social Media Advertising (TikTok @stationhandle): Story/Post Combo. Price excludes VAT.',0,'1','XXXX','SOC-TT-STORY-POST-CMB',NULL,'Good',0.000000,0.000000,'-99',800.000000,800.000000,NULL,NULL,NULL,'99f8d224-f85b-463e-98b6-4764d29c1792'),
('107b5dca-ec40-48f8-a0e3-1650e3a14ed1','3 Hour Simulcast','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Misc. Rates: 3 Hour Simulcast (with free spots worth R12,000). Price excludes VAT.',0,'1','XXXX','MISC-SIMULCAST-3HR',NULL,'Good',0.000000,0.000000,'-99',12000.000000,12000.000000,NULL,NULL,NULL,'37df3010-4e9b-47f0-8c0c-5dad0ffe4629'),
('130c79d6-c130-4873-b268-6f20aef25f02','Radio Advert: Weekend Top 30 Chart Show (10:00 - 14:00)','2026-10-19 17:53:19','2026-10-20 21:01:40',NULL,NULL,'Flagship Saturday music countdown.',0,NULL,'XXXX','WKND-CHART',NULL,'Good',380.000000,NULL,'-99',380.000000,NULL,NULL,NULL,NULL,NULL),
('1a8c752a-caee-4d65-8b56-00bbaa2a7c17','Sponsored Content Segment (Prime time shows)','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Misc. Rates: Sponsored Content Segment (Prime time shows). Price excludes VAT.',0,'1','XXXX','MISC-SPONS-SEGMENT',NULL,'Good',0.000000,0.000000,'-99',2500.000000,2500.000000,NULL,NULL,NULL,'37df3010-4e9b-47f0-8c0c-5dad0ffe4629'),
('1d9064ef-07d6-46a0-b849-86bdd4167f49','Live Read (30s) - Mon-Fri 09:00 - 12:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Live Reads (30 Seconds), Monday to Friday, 09:00 - 12:00. Price excludes VAT.',0,'1','XXXX','LIVE-30S-MF-0900-1200',NULL,'Good',0.000000,0.000000,'-99',350.000000,350.000000,NULL,NULL,NULL,'0dddc97f-f1d4-4011-886d-91d482665412'),
('1eab0d8a-a535-484d-b263-c4982e0332be','Radio Advert: Cruise Control (Afternoon Drive) (15:00 - 18:00)','2026-10-16 11:21:46','2026-10-20 21:01:40','1','1','One 30 second prerecorded advertisement played between 15:00 and 18:00.',0,'1','XXXX','CRUISE-CONTROL',NULL,'Good',350.000000,0.000000,'-99',350.000000,350.000000,NULL,NULL,NULL,'caf0c6c8-dcce-46cc-b6a4-6dc94177018d'),
('24ac3e55-79a0-4858-b54c-e40b752576bc','10 Minute Interview (In-person/Telephonic)','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Misc. Rates: 10 Minute Interview (In-person/Telephonic). Price excludes VAT.',0,'1','XXXX','MISC-INT-10MIN',NULL,'Good',0.000000,0.000000,'-99',2000.000000,2000.000000,NULL,NULL,NULL,'37df3010-4e9b-47f0-8c0c-5dad0ffe4629'),
('264b564d-7c1e-4e9d-9390-63a1cb9436e7','Weekly Package - Option 2: 50 Prime Time Live Reads','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Weekly Package (Option 2): 50 Prime Time Live Reads. Price excludes VAT.',0,'1','XXXX','PKG-WK-OPT2-50-LIVE',NULL,'Good',0.000000,0.000000,'-99',6999.000000,6999.000000,NULL,NULL,NULL,'68b79f0b-dbd2-426c-906e-57ba0e88a0f2'),
('2add4edf-f6bc-4f54-a19e-eb05e640fb27','Radio Advert: Music Unlimited (Overnight) (00:00 - 05:00)','2026-10-16 11:21:46','2026-10-20 21:01:40','1','1','One 30 second prerecorded advertisement played between 00:00 and 05:00.',0,'1','XXXX','MUSIC-UNLIMITED',NULL,'Good',120.000000,0.000000,'-99',120.000000,120.000000,NULL,NULL,NULL,'caf0c6c8-dcce-46cc-b6a4-6dc94177018d'),
('2b425395-05a5-43fe-8777-585b12973f33','Recorded Ad (30s) - Mon-Fri 21:00 - 00:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Recorded Ads (30 Seconds), Monday to Friday, 21:00 - 00:00. Price excludes VAT.',0,'1','XXXX','REC-30S-MF-2100-0000',NULL,'Good',0.000000,0.000000,'-99',220.000000,220.000000,NULL,NULL,NULL,'1580dc4d-116e-4aa4-ab84-4e7703f5d028'),
('2e8e4ca6-5c09-46f9-a1e2-1444730e27ae','TikTok - Sponsored Post','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Social Media Advertising (TikTok @stationhandle): Sponsored Post. Price excludes VAT.',0,'1','XXXX','SOC-TT-SPONS-POST',NULL,'Good',0.000000,0.000000,'-99',400.000000,400.000000,NULL,NULL,NULL,'99f8d224-f85b-463e-98b6-4764d29c1792'),
('36ff8de8-0e8b-431e-a9f6-d1c8b8b4338e','3 Hour Outside Broadcast (Local Broadcast Area)','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Misc. Rates: 3 Hour Outside Broadcast (Local Broadcast Area) (with free spots worth R15,000). Price excludes VAT.',0,'1','XXXX','MISC-OB-3HR-POTCH',NULL,'Good',0.000000,0.000000,'-99',15000.000000,15000.000000,NULL,NULL,NULL,'37df3010-4e9b-47f0-8c0c-5dad0ffe4629'),
('3813fb40-bbfc-46da-8395-7bd14174f491','Live Read (30s) - Mon-Fri 06:00 - 09:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Live Reads (30 Seconds), Monday to Friday, 06:00 - 09:00. Price excludes VAT.',0,'1','XXXX','LIVE-30S-MF-0600-0900',NULL,'Good',0.000000,0.000000,'-99',380.000000,380.000000,NULL,NULL,NULL,'0dddc97f-f1d4-4011-886d-91d482665412'),
('3ce9c6c6-2734-43af-92f0-73b7492f760a','Live Read (30s) - Sat-Sun 14:00 - 18:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Live Reads (30 Seconds), Saturday and Sunday, 14:00 - 18:00. Price excludes VAT.',0,'1','XXXX','LIVE-30S-SS-1400-1800',NULL,'Good',0.000000,0.000000,'-99',380.000000,380.000000,NULL,NULL,NULL,'0dddc97f-f1d4-4011-886d-91d482665412'),
('41c90f60-e1b9-4b8d-aa9d-3ca2e04a0b7e','Live Read (30s) - Mon-Fri 12:00 - 15:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Live Reads (30 Seconds), Monday to Friday, 12:00 - 15:00. Price excludes VAT.',0,'1','XXXX','LIVE-30S-MF-1200-1500',NULL,'Good',0.000000,0.000000,'-99',380.000000,380.000000,NULL,NULL,NULL,'0dddc97f-f1d4-4011-886d-91d482665412'),
('4222d908-7920-410f-befc-b181b143d790','Live Read (30s) - Sat-Sun 18:00 - 22:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Live Reads (30 Seconds), Saturday and Sunday, 18:00 - 22:00. Price excludes VAT.',0,'1','XXXX','LIVE-30S-SS-1800-2200',NULL,'Good',0.000000,0.000000,'-99',250.000000,250.000000,NULL,NULL,NULL,'0dddc97f-f1d4-4011-886d-91d482665412'),
('44a14bab-f19b-46c3-9951-71f1598b344e','Live Read (30s) - Mon-Fri 18:00 - 21:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Live Reads (30 Seconds), Monday to Friday, 18:00 - 21:00. Price excludes VAT.',0,'1','XXXX','LIVE-30S-MF-1800-2100',NULL,'Good',0.000000,0.000000,'-99',300.000000,300.000000,NULL,NULL,NULL,'0dddc97f-f1d4-4011-886d-91d482665412'),
('4bd807ae-fb7b-454d-bd50-e1da041f366b','Instagram - Instagram Story','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Social Media Advertising (Instagram @stationhandle): Instagram Story. Price excludes VAT.',0,'1','XXXX','SOC-IG-STORY',NULL,'Good',0.000000,0.000000,'-99',400.000000,400.000000,NULL,NULL,NULL,'99f8d224-f85b-463e-98b6-4764d29c1792'),
('4df21963-27da-43ee-9d26-5ea5e55fcffe','Radio Advert: Midday Pulse (12:00 - 15:00)','2026-10-16 11:21:46','2026-10-20 21:01:40','1','1','One 30 second prerecorded advertisement played between 12:00 and 15:00.',0,'1','XXXX','MIDDAY-PULSE',NULL,'Good',350.000000,0.000000,'-99',350.000000,350.000000,NULL,NULL,NULL,'caf0c6c8-dcce-46cc-b6a4-6dc94177018d'),
('51d26296-f37a-404b-bbc1-1e804326cb5d','Recorded Ad (30s) - Sat-Sun 10:00 - 14:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Recorded Ads (30 Seconds), Saturday and Sunday, 10:00 - 14:00. Price excludes VAT.',0,'1','XXXX','REC-30S-SS-1000-1400',NULL,'Good',0.000000,0.000000,'-99',350.000000,350.000000,NULL,NULL,NULL,'1580dc4d-116e-4aa4-ab84-4e7703f5d028'),
('527b0a11-fd86-41b9-a24a-711dea94da13','Monthly Package - Option 3: 30 Prime Time Recorded Ads x 4 weeks','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Monthly Package (Option 3): 30 Prime Time Recorded Ads x 4 weeks (120 ads total). Price excludes VAT.',0,'1','XXXX','PKG-MO-OPT3-30X4-REC',NULL,'Good',0.000000,0.000000,'-99',15999.000000,15999.000000,NULL,NULL,NULL,'68b79f0b-dbd2-426c-906e-57ba0e88a0f2'),
('53877527-e5b9-4081-bb54-ff5e81c15f54','Monthly Package - Option 4: 30 Prime Time Live Reads x 4 weeks','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Monthly Package (Option 4): 30 Prime Time Live Reads x 4 weeks (120 live reads total). Price excludes VAT.',0,'1','XXXX','PKG-MO-OPT4-30X4-LIVE',NULL,'Good',0.000000,0.000000,'-99',16999.000000,16999.000000,NULL,NULL,NULL,'68b79f0b-dbd2-426c-906e-57ba0e88a0f2'),
('613cc22b-d7af-4cb3-a38f-a988190e8994','Facebook - Sponsored Post','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Social Media Advertising (Facebook @stationhandle): Sponsored Post. Price excludes VAT.',0,'1','XXXX','SOC-FB-SPONS-POST',NULL,'Good',0.000000,0.000000,'-99',1000.000000,1000.000000,NULL,NULL,NULL,'99f8d224-f85b-463e-98b6-4764d29c1792'),
('634cbb03-749d-4c86-accf-561e8a416c96','Radio Advert: Pre-Breakfast (05:00 - 06:00)','2026-10-16 11:21:46','2026-10-20 21:01:40','1','1','One 30 second prerecorded advertisement played between 05:00 and 06:00.',0,'1','XXXX','PRE-BREAKFAST',NULL,'Good',120.000000,0.000000,'-99',120.000000,300.000000,NULL,NULL,NULL,'caf0c6c8-dcce-46cc-b6a4-6dc94177018d'),
('6441ae55-a841-4436-bd11-252c95222b34','Twitter (X) - Pinned Tweet (1 Month)','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Social Media Advertising (Twitter/X @stationhandle): Pinned Tweet (1 Month). Price excludes VAT.',0,'1','XXXX','SOC-TW-PINNED-1MO',NULL,'Good',0.000000,0.000000,'-99',1000.000000,1000.000000,NULL,NULL,NULL,'99f8d224-f85b-463e-98b6-4764d29c1792'),
('6dd91f27-14ca-49e9-8680-23877fee74f2','Recorded Ad (30s) - Sat-Sun 22:00 - 00:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Recorded Ads (30 Seconds), Saturday and Sunday, 22:00 - 00:00. Price excludes VAT.',0,'1','XXXX','REC-30S-SS-2200-0000',NULL,'Good',0.000000,0.000000,'-99',120.000000,120.000000,NULL,NULL,NULL,'1580dc4d-116e-4aa4-ab84-4e7703f5d028'),
('6eddc431-9ef9-4913-b00f-f3e82c33c61b','Instagram - Sponsored Post','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Social Media Advertising (Instagram @stationhandle): Sponsored Post. Price excludes VAT.',0,'1','XXXX','SOC-IG-SPONS-POST',NULL,'Good',0.000000,0.000000,'-99',500.000000,500.000000,NULL,NULL,NULL,'99f8d224-f85b-463e-98b6-4764d29c1792'),
('7a655edd-daf5-4e41-a9d7-48131c323f73','Instagram - Sponsored Post Package (4 posts)','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Social Media Advertising (Instagram @stationhandle): Sponsored Post Package (4 posts). Price excludes VAT.',0,'1','XXXX','SOC-IG-SPONS-PKG-4',NULL,'Good',0.000000,0.000000,'-99',1500.000000,1500.000000,NULL,NULL,NULL,'99f8d224-f85b-463e-98b6-4764d29c1792'),
('7ba7055f-46e9-4f51-ad2b-9b9db90cb4d5','Radio Advert: Morning Buzz (Breakfast Show) (06:00 - 09:00)','2026-10-19 17:53:19','2026-10-20 21:01:40',NULL,NULL,'One 30 second prerecorded advertisement played between 06:00 and 09:00.',0,NULL,'XXXX','MORNING-BUZZ',NULL,'Good',350.000000,NULL,'-99',350.000000,NULL,NULL,NULL,NULL,'caf0c6c8-dcce-46cc-b6a4-6dc94177018d'),
('7efe283c-a970-4f4d-a7dd-ea6c9c2222a9','Twitter (X) - Sponsored Tweet','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Social Media Advertising (Twitter/X @stationhandle): Sponsored Tweet. Price excludes VAT.',0,'1','XXXX','SOC-TW-SPONS-TWEET',NULL,'Good',0.000000,0.000000,'-99',500.000000,500.000000,NULL,NULL,NULL,'99f8d224-f85b-463e-98b6-4764d29c1792'),
('7f6913f1-c10b-4258-ae2b-0652569d3941','Recorded Ad (30s) - Mon-Fri 18:00 - 21:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Recorded Ads (30 Seconds), Monday to Friday, 18:00 - 21:00. Price excludes VAT.',0,'1','XXXX','REC-30S-MF-1800-2100',NULL,'Good',0.000000,0.000000,'-99',300.000000,300.000000,NULL,NULL,NULL,'1580dc4d-116e-4aa4-ab84-4e7703f5d028'),
('814f74d9-028f-4136-ab44-3df5d33d0ba5','Facebook - Sponsored Post Package (4 posts)','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Social Media Advertising (Facebook @stationhandle): Sponsored Post Package (4 posts). Price excludes VAT.',0,'1','XXXX','SOC-FB-SPONS-PKG-4',NULL,'Good',0.000000,0.000000,'-99',1950.000000,1950.000000,NULL,NULL,NULL,'99f8d224-f85b-463e-98b6-4764d29c1792'),
('82e44e8d-25a7-47a9-804b-e6bcdd838fba','Recorded Ad (30s) - Mon-Fri 06:00 - 09:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Recorded Ads (30 Seconds), Monday to Friday, 06:00 - 09:00. Price excludes VAT.',0,'1','XXXX','REC-30S-MF-0600-0900',NULL,'Good',0.000000,0.000000,'-99',350.000000,350.000000,NULL,NULL,NULL,'1580dc4d-116e-4aa4-ab84-4e7703f5d028'),
('86e16000-350e-4430-84f4-e46d5e402726','Radio Advert: Specialty Show 2 (Late Evening) (21:00 - 00:00)','2026-10-16 11:21:46','2026-10-20 21:01:40','1','1','One 30 second prerecorded advertisement played between 21:00 and 00:00.',0,'1','XXXX','SPECIALTY-SHOW-2',NULL,'Good',220.000000,0.000000,'-99',220.000000,220.000000,NULL,NULL,NULL,'caf0c6c8-dcce-46cc-b6a4-6dc94177018d'),
('8a31f353-4e64-414e-8dbc-09327fbf92a5','Live Read (30s) - Sat-Sun 10:00 - 14:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Live Reads (30 Seconds), Saturday and Sunday, 10:00 - 14:00. Price excludes VAT.',0,'1','XXXX','LIVE-30S-SS-1000-1400',NULL,'Good',0.000000,0.000000,'-99',350.000000,350.000000,NULL,NULL,NULL,'0dddc97f-f1d4-4011-886d-91d482665412'),
('8f5bc157-90f6-4203-9b8a-cc509f04eefe','Live Read (30s) - Sat-Sun 06:00 - 10:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Live Reads (30 Seconds), Saturday and Sunday, 06:00 - 10:00. Price excludes VAT.',0,'1','XXXX','LIVE-30S-SS-0600-1000',NULL,'Good',0.000000,0.000000,'-99',380.000000,380.000000,NULL,NULL,NULL,'0dddc97f-f1d4-4011-886d-91d482665412'),
('9a6b0c93-6ca4-4de5-a25e-13ec7792f5c6','Radio Advert: The Breakfast Club (06:00 - 09:00)','2026-10-16 11:21:46','2026-10-20 21:01:40','1','1','Flagship morning breakfast drive show (06:00 - 09:00). High student & commuter listenership.',0,'1','XXXX','MORNING-BUZZ',NULL,'Good',399.000000,0.000000,'-99',399.000000,320.000000,NULL,NULL,NULL,'caf0c6c8-dcce-46cc-b6a4-6dc94177018d'),
('a37c3643-e61b-4f62-93a6-8fb1afdc1b5f','Recorded Ad (30s) - Mon-Fri 12:00 - 15:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Recorded Ads (30 Seconds), Monday to Friday, 12:00 - 15:00. Price excludes VAT.',0,'1','XXXX','REC-30S-MF-1200-1500',NULL,'Good',0.000000,0.000000,'-99',350.000000,350.000000,NULL,NULL,NULL,'1580dc4d-116e-4aa4-ab84-4e7703f5d028'),
('acd0f07f-6519-4a09-aa57-dfaabf81c1be','30 Minute Interview (In-person/Telephonic)','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Misc. Rates: 30 Minute Interview (In-person/Telephonic). Price excludes VAT.',0,'1','XXXX','MISC-INT-30MIN',NULL,'Good',0.000000,0.000000,'-99',5000.000000,5000.000000,NULL,NULL,NULL,'37df3010-4e9b-47f0-8c0c-5dad0ffe4629'),
('acff4828-49bb-4c03-a120-8a71f9a46eb0','Radio Advert: News Bulletin Sponsorship (Hourly)','2026-10-19 17:53:19','2026-10-20 21:01:40',NULL,NULL,'10s opener and closer sponsorship tags.',0,NULL,'XXXX','SPON-NEWS',NULL,'Good',500.000000,NULL,'-99',500.000000,NULL,NULL,NULL,NULL,NULL),
('b209bca6-026e-425c-854a-0064dac96613','Live Read (30s) - Sat-Sun 22:00 - 00:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Live Reads (30 Seconds), Saturday and Sunday, 22:00 - 00:00. Price excludes VAT.',0,'1','XXXX','LIVE-30S-SS-2200-0000',NULL,'Good',0.000000,0.000000,'-99',150.000000,150.000000,NULL,NULL,NULL,'0dddc97f-f1d4-4011-886d-91d482665412'),
('ba895018-925c-4679-8dc4-23a60ee7f405','Live Read (30s) - Mon-Fri 15:00 - 18:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Live Reads (30 Seconds), Monday to Friday, 15:00 - 18:00. Price excludes VAT.',0,'1','XXXX','LIVE-30S-MF-1500-1800',NULL,'Good',0.000000,0.000000,'-99',380.000000,380.000000,NULL,NULL,NULL,'0dddc97f-f1d4-4011-886d-91d482665412'),
('badbf090-344c-4b85-b0c8-cd72cd664044','Recorded Ad (30s) - Sat-Sun 06:00 - 10:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Recorded Ads (30 Seconds), Saturday and Sunday, 06:00 - 10:00. Price excludes VAT.',0,'1','XXXX','REC-30S-SS-0600-1000',NULL,'Good',0.000000,0.000000,'-99',300.000000,300.000000,NULL,NULL,NULL,'1580dc4d-116e-4aa4-ab84-4e7703f5d028'),
('c104c168-befb-4f78-a8da-0889fd561838','Recorded Ad (30s) - Sat-Sun 14:00 - 18:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Recorded Ads (30 Seconds), Saturday and Sunday, 14:00 - 18:00. Price excludes VAT.',0,'1','XXXX','REC-30S-SS-1400-1800',NULL,'Good',0.000000,0.000000,'-99',350.000000,350.000000,NULL,NULL,NULL,'1580dc4d-116e-4aa4-ab84-4e7703f5d028'),
('c17f6ef6-7af7-4494-b55f-c72e6eef58c4','Weekly Package - Option 1: 50 Prime Time Recorded Ads','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Weekly Package (Option 1): 50 Prime Time Recorded Ads. Price excludes VAT.',0,'1','XXXX','PKG-WK-OPT1-50-REC',NULL,'Good',0.000000,0.000000,'-99',5999.000000,5999.000000,NULL,NULL,NULL,'68b79f0b-dbd2-426c-906e-57ba0e88a0f2'),
('c454cd0b-1baf-4aba-9a7f-25c75542db09','Instagram - Story/Post Combo','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Social Media Advertising (Instagram @stationhandle): Story/Post Combo. Price excludes VAT.',0,'1','XXXX','SOC-IG-STORY-POST-CMB',NULL,'Good',0.000000,0.000000,'-99',700.000000,700.000000,NULL,NULL,NULL,'99f8d224-f85b-463e-98b6-4764d29c1792'),
('c832bc67-0fb9-4876-ad41-f5519ce72f85','Recorded Ad (30s) - Mon-Fri 00:00 - 06:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Recorded Ads (30 Seconds), Monday to Friday, 00:00 - 06:00. Price excludes VAT.',0,'1','XXXX','REC-30S-MF-0000-0600',NULL,'Good',0.000000,0.000000,'-99',120.000000,120.000000,NULL,NULL,NULL,'1580dc4d-116e-4aa4-ab84-4e7703f5d028'),
('c8e5a59e-d520-4c82-b3fa-2871c1f433c7','Recorded Ad (30s) - Mon-Fri 09:00 - 12:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Recorded Ads (30 Seconds), Monday to Friday, 09:00 - 12:00. Price excludes VAT.',0,'1','XXXX','REC-30S-MF-0900-1200',NULL,'Good',0.000000,0.000000,'-99',320.000000,320.000000,NULL,NULL,NULL,'1580dc4d-116e-4aa4-ab84-4e7703f5d028'),
('cc1ea120-4788-4ea1-b966-b7a68706dd18','Recorded Ad (30s) - Sat-Sun 18:00 - 22:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Recorded Ads (30 Seconds), Saturday and Sunday, 18:00 - 22:00. Price excludes VAT.',0,'1','XXXX','REC-30S-SS-1800-2200',NULL,'Good',0.000000,0.000000,'-99',220.000000,220.000000,NULL,NULL,NULL,'1580dc4d-116e-4aa4-ab84-4e7703f5d028'),
('daf4bf29-8432-4ab3-8f90-6474b738b0a1','Facebook - Story/Post Combo','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Social Media Advertising (Facebook @stationhandle): Story/Post Combo. Price excludes VAT.',0,'1','XXXX','SOC-FB-STORY-POST-CMB',NULL,'Good',0.000000,0.000000,'-99',1200.000000,1200.000000,NULL,NULL,NULL,'99f8d224-f85b-463e-98b6-4764d29c1792'),
('ee8d3a8c-ac00-41c3-a504-ed1558be1b4a','Powerspot (Prime time shows)','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Misc. Rates: Powerspot (Prime time shows). Price excludes VAT.',0,'1','XXXX','MISC-POWERSPOT',NULL,'Good',0.000000,0.000000,'-99',500.000000,500.000000,NULL,NULL,NULL,'37df3010-4e9b-47f0-8c0c-5dad0ffe4629'),
('efb88f61-156d-47ff-9ac4-c04b19e52166','TikTok - Sponsored Post Package (4 posts)','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Social Media Advertising (TikTok @stationhandle): Sponsored Post Package (4 posts). Price excludes VAT.',0,'1','XXXX','SOC-TT-SPONS-PKG-4',NULL,'Good',0.000000,0.000000,'-99',1500.000000,1500.000000,NULL,NULL,NULL,'99f8d224-f85b-463e-98b6-4764d29c1792'),
('f2457c2b-cba5-4078-bff4-6b6896d8af7a','Recorded Ad (30s) - Sat-Sun 00:00 - 06:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Recorded Ads (30 Seconds), Saturday and Sunday, 00:00 - 06:00. Price excludes VAT.',0,'1','XXXX','REC-30S-SS-0000-0600',NULL,'Good',0.000000,0.000000,'-99',120.000000,120.000000,NULL,NULL,NULL,'1580dc4d-116e-4aa4-ab84-4e7703f5d028'),
('fa6d080c-6286-45f0-9fc0-3d1b5c0a685d','Recorded Ad (30s) - Mon-Fri 15:00 - 18:00','2026-10-16 17:58:04','2026-10-20 20:59:17','1','1','Radio Rate Card - Recorded Ads (30 Seconds), Monday to Friday, 15:00 - 18:00. Price excludes VAT.',0,'1','XXXX','REC-30S-MF-1500-1800',NULL,'Good',0.000000,0.000000,'-99',350.000000,350.000000,NULL,NULL,NULL,'1580dc4d-116e-4aa4-ab84-4e7703f5d028'),
('fc753a36-d620-498d-916a-12f8ce7e6318','Radio Advert: Midmorning Banter (09:00 - 12:00)','2026-10-16 11:21:46','2026-10-20 21:01:40','1','1','One 30 second prerecorded advertisement played between 09:00 and 12:00.',0,'1','XXXX','MIDMORNING-BANTER',NULL,'Good',320.000000,0.000000,'-99',320.000000,350.000000,NULL,NULL,NULL,'caf0c6c8-dcce-46cc-b6a4-6dc94177018d');
/*!40000 ALTER TABLE `aos_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_products_audit`
--

DROP TABLE IF EXISTS `aos_products_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_products_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aos_products_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_products_audit`
--

LOCK TABLES `aos_products_audit` WRITE;
/*!40000 ALTER TABLE `aos_products_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_products_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_products_quotes`
--

DROP TABLE IF EXISTS `aos_products_quotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_products_quotes` (
  `id` char(36) NOT NULL,
  `name` text DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `part_number` varchar(255) DEFAULT NULL,
  `item_description` text DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `product_qty` decimal(18,4) DEFAULT NULL,
  `product_cost_price` decimal(26,6) DEFAULT NULL,
  `product_cost_price_usdollar` decimal(26,6) DEFAULT NULL,
  `product_list_price` decimal(26,6) DEFAULT NULL,
  `product_list_price_usdollar` decimal(26,6) DEFAULT NULL,
  `product_discount` decimal(26,6) DEFAULT NULL,
  `product_discount_usdollar` decimal(26,6) DEFAULT NULL,
  `product_discount_amount` decimal(26,6) DEFAULT NULL,
  `product_discount_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `discount` varchar(255) DEFAULT 'Percentage',
  `product_unit_price` decimal(26,6) DEFAULT NULL,
  `product_unit_price_usdollar` decimal(26,6) DEFAULT NULL,
  `vat_amt` decimal(26,6) DEFAULT NULL,
  `vat_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `product_total_price` decimal(26,6) DEFAULT NULL,
  `product_total_price_usdollar` decimal(26,6) DEFAULT NULL,
  `vat` varchar(100) DEFAULT '5.0',
  `parent_type` varchar(100) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `product_id` char(36) DEFAULT NULL,
  `group_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aospq_par_del` (`parent_id`,`parent_type`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_products_quotes`
--

LOCK TABLES `aos_products_quotes` WRITE;
/*!40000 ALTER TABLE `aos_products_quotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_products_quotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_products_quotes_audit`
--

DROP TABLE IF EXISTS `aos_products_quotes_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_products_quotes_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aos_products_quotes_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_products_quotes_audit`
--

LOCK TABLES `aos_products_quotes_audit` WRITE;
/*!40000 ALTER TABLE `aos_products_quotes_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_products_quotes_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_quotes`
--

DROP TABLE IF EXISTS `aos_quotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_quotes` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `approval_issue` text DEFAULT NULL,
  `billing_account_id` char(36) DEFAULT NULL,
  `billing_contact_id` char(36) DEFAULT NULL,
  `billing_address_street` varchar(150) DEFAULT NULL,
  `billing_address_city` varchar(100) DEFAULT NULL,
  `billing_address_state` varchar(100) DEFAULT NULL,
  `billing_address_postalcode` varchar(20) DEFAULT NULL,
  `billing_address_country` varchar(255) DEFAULT NULL,
  `shipping_address_street` varchar(150) DEFAULT NULL,
  `shipping_address_city` varchar(100) DEFAULT NULL,
  `shipping_address_state` varchar(100) DEFAULT NULL,
  `shipping_address_postalcode` varchar(20) DEFAULT NULL,
  `shipping_address_country` varchar(255) DEFAULT NULL,
  `expiration` date DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `opportunity_id` char(36) DEFAULT NULL,
  `template_ddown_c` text DEFAULT NULL,
  `total_amt` decimal(26,6) DEFAULT NULL,
  `total_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `subtotal_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `discount_amount` decimal(26,6) DEFAULT NULL,
  `discount_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `tax_amount` decimal(26,6) DEFAULT NULL,
  `tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_amount` decimal(26,6) DEFAULT NULL,
  `shipping_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_tax` varchar(100) DEFAULT NULL,
  `shipping_tax_amt` decimal(26,6) DEFAULT NULL,
  `shipping_tax_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `total_amount` decimal(26,6) DEFAULT NULL,
  `total_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `stage` varchar(100) DEFAULT 'Draft',
  `term` varchar(100) DEFAULT NULL,
  `terms_c` text DEFAULT NULL,
  `approval_status` varchar(100) DEFAULT NULL,
  `invoice_status` varchar(100) DEFAULT 'Not Invoiced',
  `subtotal_tax_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_quotes`
--

LOCK TABLES `aos_quotes` WRITE;
/*!40000 ALTER TABLE `aos_quotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_quotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_quotes_aos_invoices_c`
--

DROP TABLE IF EXISTS `aos_quotes_aos_invoices_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_quotes_aos_invoices_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `aos_quotes77d9_quotes_ida` varchar(36) DEFAULT NULL,
  `aos_quotes6b83nvoices_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aos_quotes_aos_invoices_alt` (`aos_quotes77d9_quotes_ida`,`aos_quotes6b83nvoices_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_quotes_aos_invoices_c`
--

LOCK TABLES `aos_quotes_aos_invoices_c` WRITE;
/*!40000 ALTER TABLE `aos_quotes_aos_invoices_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_quotes_aos_invoices_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_quotes_audit`
--

DROP TABLE IF EXISTS `aos_quotes_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_quotes_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aos_quotes_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_quotes_audit`
--

LOCK TABLES `aos_quotes_audit` WRITE;
/*!40000 ALTER TABLE `aos_quotes_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_quotes_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_quotes_cstm`
--

DROP TABLE IF EXISTS `aos_quotes_cstm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_quotes_cstm` (
  `id_c` char(36) NOT NULL,
  `campaign_start_date_c` date DEFAULT NULL,
  `campaign_end_date_c` date DEFAULT NULL,
  `mon_pre_breakfast_0500_0600_c` int(11) DEFAULT 0,
  `tue_pre_breakfast_0500_0600_c` int(11) DEFAULT 0,
  `wed_pre_breakfast_0500_0600_c` int(11) DEFAULT 0,
  `thu_pre_breakfast_0500_0600_c` int(11) DEFAULT 0,
  `fri_pre_breakfast_0500_0600_c` int(11) DEFAULT 0,
  `sat_pre_breakfast_0500_0600_c` int(11) DEFAULT 0,
  `sun_pre_breakfast_0500_0600_c` int(11) DEFAULT 0,
  `mon_morning_buzz_0600_0700_c` int(11) DEFAULT 0,
  `tue_morning_buzz_0600_0700_c` int(11) DEFAULT 0,
  `wed_morning_buzz_0600_0700_c` int(11) DEFAULT 0,
  `thu_morning_buzz_0600_0700_c` int(11) DEFAULT 0,
  `fri_morning_buzz_0600_0700_c` int(11) DEFAULT 0,
  `sat_morning_buzz_0600_0700_c` int(11) DEFAULT 0,
  `sun_morning_buzz_0600_0700_c` int(11) DEFAULT 0,
  `mon_morning_buzz_0700_0800_c` int(11) DEFAULT 0,
  `tue_morning_buzz_0700_0800_c` int(11) DEFAULT 0,
  `wed_morning_buzz_0700_0800_c` int(11) DEFAULT 0,
  `thu_morning_buzz_0700_0800_c` int(11) DEFAULT 0,
  `fri_morning_buzz_0700_0800_c` int(11) DEFAULT 0,
  `sat_morning_buzz_0700_0800_c` int(11) DEFAULT 0,
  `sun_morning_buzz_0700_0800_c` int(11) DEFAULT 0,
  `mon_morning_buzz_0800_0900_c` int(11) DEFAULT 0,
  `tue_morning_buzz_0800_0900_c` int(11) DEFAULT 0,
  `wed_morning_buzz_0800_0900_c` int(11) DEFAULT 0,
  `thu_morning_buzz_0800_0900_c` int(11) DEFAULT 0,
  `fri_morning_buzz_0800_0900_c` int(11) DEFAULT 0,
  `sat_morning_buzz_0800_0900_c` int(11) DEFAULT 0,
  `sun_morning_buzz_0800_0900_c` int(11) DEFAULT 0,
  `mon_midmorning_banter_0900_1000_c` int(11) DEFAULT 0,
  `tue_midmorning_banter_0900_1000_c` int(11) DEFAULT 0,
  `wed_midmorning_banter_0900_1000_c` int(11) DEFAULT 0,
  `thu_midmorning_banter_0900_1000_c` int(11) DEFAULT 0,
  `fri_midmorning_banter_0900_1000_c` int(11) DEFAULT 0,
  `sat_midmorning_banter_0900_1000_c` int(11) DEFAULT 0,
  `sun_midmorning_banter_0900_1000_c` int(11) DEFAULT 0,
  `mon_midmorning_banter_1000_1100_c` int(11) DEFAULT 0,
  `tue_midmorning_banter_1000_1100_c` int(11) DEFAULT 0,
  `wed_midmorning_banter_1000_1100_c` int(11) DEFAULT 0,
  `thu_midmorning_banter_1000_1100_c` int(11) DEFAULT 0,
  `fri_midmorning_banter_1000_1100_c` int(11) DEFAULT 0,
  `sat_midmorning_banter_1000_1100_c` int(11) DEFAULT 0,
  `sun_midmorning_banter_1000_1100_c` int(11) DEFAULT 0,
  `mon_midmorning_banter_1100_1200_c` int(11) DEFAULT 0,
  `tue_midmorning_banter_1100_1200_c` int(11) DEFAULT 0,
  `wed_midmorning_banter_1100_1200_c` int(11) DEFAULT 0,
  `thu_midmorning_banter_1100_1200_c` int(11) DEFAULT 0,
  `fri_midmorning_banter_1100_1200_c` int(11) DEFAULT 0,
  `sat_midmorning_banter_1100_1200_c` int(11) DEFAULT 0,
  `sun_midmorning_banter_1100_1200_c` int(11) DEFAULT 0,
  `mon_midday_pulse_1200_1300_c` int(11) DEFAULT 0,
  `tue_midday_pulse_1200_1300_c` int(11) DEFAULT 0,
  `wed_midday_pulse_1200_1300_c` int(11) DEFAULT 0,
  `thu_midday_pulse_1200_1300_c` int(11) DEFAULT 0,
  `fri_midday_pulse_1200_1300_c` int(11) DEFAULT 0,
  `sat_midday_pulse_1200_1300_c` int(11) DEFAULT 0,
  `sun_midday_pulse_1200_1300_c` int(11) DEFAULT 0,
  `mon_midday_pulse_1300_1400_c` int(11) DEFAULT 0,
  `tue_midday_pulse_1300_1400_c` int(11) DEFAULT 0,
  `wed_midday_pulse_1300_1400_c` int(11) DEFAULT 0,
  `thu_midday_pulse_1300_1400_c` int(11) DEFAULT 0,
  `fri_midday_pulse_1300_1400_c` int(11) DEFAULT 0,
  `sat_midday_pulse_1300_1400_c` int(11) DEFAULT 0,
  `sun_midday_pulse_1300_1400_c` int(11) DEFAULT 0,
  `mon_midday_pulse_1400_1500_c` int(11) DEFAULT 0,
  `tue_midday_pulse_1400_1500_c` int(11) DEFAULT 0,
  `wed_midday_pulse_1400_1500_c` int(11) DEFAULT 0,
  `thu_midday_pulse_1400_1500_c` int(11) DEFAULT 0,
  `fri_midday_pulse_1400_1500_c` int(11) DEFAULT 0,
  `sat_midday_pulse_1400_1500_c` int(11) DEFAULT 0,
  `sun_midday_pulse_1400_1500_c` int(11) DEFAULT 0,
  `mon_cruise_control_1500_1600_c` int(11) DEFAULT 0,
  `tue_cruise_control_1500_1600_c` int(11) DEFAULT 0,
  `wed_cruise_control_1500_1600_c` int(11) DEFAULT 0,
  `thu_cruise_control_1500_1600_c` int(11) DEFAULT 0,
  `fri_cruise_control_1500_1600_c` int(11) DEFAULT 0,
  `sat_cruise_control_1500_1600_c` int(11) DEFAULT 0,
  `sun_cruise_control_1500_1600_c` int(11) DEFAULT 0,
  `mon_cruise_control_1600_1700_c` int(11) DEFAULT 0,
  `tue_cruise_control_1600_1700_c` int(11) DEFAULT 0,
  `wed_cruise_control_1600_1700_c` int(11) DEFAULT 0,
  `thu_cruise_control_1600_1700_c` int(11) DEFAULT 0,
  `fri_cruise_control_1600_1700_c` int(11) DEFAULT 0,
  `sat_cruise_control_1600_1700_c` int(11) DEFAULT 0,
  `sun_cruise_control_1600_1700_c` int(11) DEFAULT 0,
  `mon_cruise_control_1700_1800_c` int(11) DEFAULT 0,
  `tue_cruise_control_1700_1800_c` int(11) DEFAULT 0,
  `wed_cruise_control_1700_1800_c` int(11) DEFAULT 0,
  `thu_cruise_control_1700_1800_c` int(11) DEFAULT 0,
  `fri_cruise_control_1700_1800_c` int(11) DEFAULT 0,
  `sat_cruise_control_1700_1800_c` int(11) DEFAULT 0,
  `sun_cruise_control_1700_1800_c` int(11) DEFAULT 0,
  `mon_specialty_show_1_1800_1900_c` int(11) DEFAULT 0,
  `tue_specialty_show_1_1800_1900_c` int(11) DEFAULT 0,
  `wed_specialty_show_1_1800_1900_c` int(11) DEFAULT 0,
  `thu_specialty_show_1_1800_1900_c` int(11) DEFAULT 0,
  `fri_specialty_show_1_1800_1900_c` int(11) DEFAULT 0,
  `sat_specialty_show_1_1800_1900_c` int(11) DEFAULT 0,
  `sun_specialty_show_1_1800_1900_c` int(11) DEFAULT 0,
  `mon_specialty_show_1_1900_2000_c` int(11) DEFAULT 0,
  `tue_specialty_show_1_1900_2000_c` int(11) DEFAULT 0,
  `wed_specialty_show_1_1900_2000_c` int(11) DEFAULT 0,
  `thu_specialty_show_1_1900_2000_c` int(11) DEFAULT 0,
  `fri_specialty_show_1_1900_2000_c` int(11) DEFAULT 0,
  `sat_specialty_show_1_1900_2000_c` int(11) DEFAULT 0,
  `sun_specialty_show_1_1900_2000_c` int(11) DEFAULT 0,
  `mon_specialty_show_1_2000_2100_c` int(11) DEFAULT 0,
  `tue_specialty_show_1_2000_2100_c` int(11) DEFAULT 0,
  `wed_specialty_show_1_2000_2100_c` int(11) DEFAULT 0,
  `thu_specialty_show_1_2000_2100_c` int(11) DEFAULT 0,
  `fri_specialty_show_1_2000_2100_c` int(11) DEFAULT 0,
  `sat_specialty_show_1_2000_2100_c` int(11) DEFAULT 0,
  `sun_specialty_show_1_2000_2100_c` int(11) DEFAULT 0,
  `mon_specialty_show_2_2100_2200_c` int(11) DEFAULT 0,
  `tue_specialty_show_2_2100_2200_c` int(11) DEFAULT 0,
  `wed_specialty_show_2_2100_2200_c` int(11) DEFAULT 0,
  `thu_specialty_show_2_2100_2200_c` int(11) DEFAULT 0,
  `fri_specialty_show_2_2100_2200_c` int(11) DEFAULT 0,
  `sat_specialty_show_2_2100_2200_c` int(11) DEFAULT 0,
  `sun_specialty_show_2_2100_2200_c` int(11) DEFAULT 0,
  `mon_specialty_show_2_2200_2300_c` int(11) DEFAULT 0,
  `tue_specialty_show_2_2200_2300_c` int(11) DEFAULT 0,
  `wed_specialty_show_2_2200_2300_c` int(11) DEFAULT 0,
  `thu_specialty_show_2_2200_2300_c` int(11) DEFAULT 0,
  `fri_specialty_show_2_2200_2300_c` int(11) DEFAULT 0,
  `sat_specialty_show_2_2200_2300_c` int(11) DEFAULT 0,
  `sun_specialty_show_2_2200_2300_c` int(11) DEFAULT 0,
  `mon_specialty_show_2_2300_0000_c` int(11) DEFAULT 0,
  `tue_specialty_show_2_2300_0000_c` int(11) DEFAULT 0,
  `wed_specialty_show_2_2300_0000_c` int(11) DEFAULT 0,
  `thu_specialty_show_2_2300_0000_c` int(11) DEFAULT 0,
  `fri_specialty_show_2_2300_0000_c` int(11) DEFAULT 0,
  `sat_specialty_show_2_2300_0000_c` int(11) DEFAULT 0,
  `sun_specialty_show_2_2300_0000_c` int(11) DEFAULT 0,
  `mon_music_unlimited_0000_0100_c` int(11) DEFAULT 0,
  `tue_music_unlimited_0000_0100_c` int(11) DEFAULT 0,
  `wed_music_unlimited_0000_0100_c` int(11) DEFAULT 0,
  `thu_music_unlimited_0000_0100_c` int(11) DEFAULT 0,
  `fri_music_unlimited_0000_0100_c` int(11) DEFAULT 0,
  `sat_music_unlimited_0000_0100_c` int(11) DEFAULT 0,
  `sun_music_unlimited_0000_0100_c` int(11) DEFAULT 0,
  `mon_music_unlimited_0100_0200_c` int(11) DEFAULT 0,
  `tue_music_unlimited_0100_0200_c` int(11) DEFAULT 0,
  `wed_music_unlimited_0100_0200_c` int(11) DEFAULT 0,
  `thu_music_unlimited_0100_0200_c` int(11) DEFAULT 0,
  `fri_music_unlimited_0100_0200_c` int(11) DEFAULT 0,
  `sat_music_unlimited_0100_0200_c` int(11) DEFAULT 0,
  `sun_music_unlimited_0100_0200_c` int(11) DEFAULT 0,
  `mon_music_unlimited_0200_0300_c` int(11) DEFAULT 0,
  `tue_music_unlimited_0200_0300_c` int(11) DEFAULT 0,
  `wed_music_unlimited_0200_0300_c` int(11) DEFAULT 0,
  `thu_music_unlimited_0200_0300_c` int(11) DEFAULT 0,
  `fri_music_unlimited_0200_0300_c` int(11) DEFAULT 0,
  `sat_music_unlimited_0200_0300_c` int(11) DEFAULT 0,
  `sun_music_unlimited_0200_0300_c` int(11) DEFAULT 0,
  `mon_music_unlimited_0300_0400_c` int(11) DEFAULT 0,
  `tue_music_unlimited_0300_0400_c` int(11) DEFAULT 0,
  `wed_music_unlimited_0300_0400_c` int(11) DEFAULT 0,
  `thu_music_unlimited_0300_0400_c` int(11) DEFAULT 0,
  `fri_music_unlimited_0300_0400_c` int(11) DEFAULT 0,
  `sat_music_unlimited_0300_0400_c` int(11) DEFAULT 0,
  `sun_music_unlimited_0300_0400_c` int(11) DEFAULT 0,
  `mon_music_unlimited_0400_0500_c` int(11) DEFAULT 0,
  `tue_music_unlimited_0400_0500_c` int(11) DEFAULT 0,
  `wed_music_unlimited_0400_0500_c` int(11) DEFAULT 0,
  `thu_music_unlimited_0400_0500_c` int(11) DEFAULT 0,
  `fri_music_unlimited_0400_0500_c` int(11) DEFAULT 0,
  `sat_music_unlimited_0400_0500_c` int(11) DEFAULT 0,
  `sun_music_unlimited_0400_0500_c` int(11) DEFAULT 0,
  `industry_category_c` varchar(100) DEFAULT 'other',
  `spot_duration_c` varchar(20) DEFAULT '30 sec',
  `applied_package_c` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_quotes_cstm`
--

LOCK TABLES `aos_quotes_cstm` WRITE;
/*!40000 ALTER TABLE `aos_quotes_cstm` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_quotes_cstm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_quotes_os_contracts_c`
--

DROP TABLE IF EXISTS `aos_quotes_os_contracts_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_quotes_os_contracts_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `aos_quotese81e_quotes_ida` varchar(36) DEFAULT NULL,
  `aos_quotes4dc0ntracts_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aos_quotes_aos_contracts_alt` (`aos_quotese81e_quotes_ida`,`aos_quotes4dc0ntracts_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_quotes_os_contracts_c`
--

LOCK TABLES `aos_quotes_os_contracts_c` WRITE;
/*!40000 ALTER TABLE `aos_quotes_os_contracts_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_quotes_os_contracts_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aos_quotes_project_c`
--

DROP TABLE IF EXISTS `aos_quotes_project_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aos_quotes_project_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `aos_quotes1112_quotes_ida` varchar(36) DEFAULT NULL,
  `aos_quotes7207project_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aos_quotes_project_alt` (`aos_quotes1112_quotes_ida`,`aos_quotes7207project_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aos_quotes_project_c`
--

LOCK TABLES `aos_quotes_project_c` WRITE;
/*!40000 ALTER TABLE `aos_quotes_project_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `aos_quotes_project_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aow_actions`
--

DROP TABLE IF EXISTS `aow_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aow_actions` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `aow_workflow_id` char(36) DEFAULT NULL,
  `action_order` int(255) DEFAULT NULL,
  `action` varchar(100) DEFAULT NULL,
  `parameters` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aow_action_index_workflow_id` (`aow_workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aow_actions`
--

LOCK TABLES `aow_actions` WRITE;
/*!40000 ALTER TABLE `aow_actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `aow_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aow_conditions`
--

DROP TABLE IF EXISTS `aow_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aow_conditions` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `aow_workflow_id` char(36) DEFAULT NULL,
  `condition_order` int(255) DEFAULT NULL,
  `module_path` longtext DEFAULT NULL,
  `field` varchar(100) DEFAULT NULL,
  `operator` varchar(100) DEFAULT NULL,
  `value_type` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aow_conditions_index_workflow_id` (`aow_workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aow_conditions`
--

LOCK TABLES `aow_conditions` WRITE;
/*!40000 ALTER TABLE `aow_conditions` DISABLE KEYS */;
/*!40000 ALTER TABLE `aow_conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aow_processed`
--

DROP TABLE IF EXISTS `aow_processed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aow_processed` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `aow_workflow_id` char(36) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Pending',
  PRIMARY KEY (`id`),
  KEY `aow_processed_index_workflow` (`aow_workflow_id`,`status`,`parent_id`,`deleted`),
  KEY `aow_processed_index_status` (`status`),
  KEY `aow_processed_index_workflow_id` (`aow_workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aow_processed`
--

LOCK TABLES `aow_processed` WRITE;
/*!40000 ALTER TABLE `aow_processed` DISABLE KEYS */;
/*!40000 ALTER TABLE `aow_processed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aow_processed_aow_actions`
--

DROP TABLE IF EXISTS `aow_processed_aow_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aow_processed_aow_actions` (
  `id` varchar(36) NOT NULL,
  `aow_processed_id` varchar(36) DEFAULT NULL,
  `aow_action_id` varchar(36) DEFAULT NULL,
  `status` varchar(36) DEFAULT 'Pending',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_aow_processed_aow_actions` (`aow_processed_id`,`aow_action_id`),
  KEY `idx_actid_del_freid` (`aow_action_id`,`deleted`,`aow_processed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aow_processed_aow_actions`
--

LOCK TABLES `aow_processed_aow_actions` WRITE;
/*!40000 ALTER TABLE `aow_processed_aow_actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `aow_processed_aow_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aow_workflow`
--

DROP TABLE IF EXISTS `aow_workflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aow_workflow` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `flow_module` varchar(100) DEFAULT NULL,
  `flow_run_on` varchar(100) DEFAULT '0',
  `status` varchar(100) DEFAULT 'Active',
  `run_when` varchar(100) DEFAULT 'Always',
  `multiple_runs` tinyint(1) DEFAULT 0,
  `run_on_import` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `aow_workflow_index_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aow_workflow`
--

LOCK TABLES `aow_workflow` WRITE;
/*!40000 ALTER TABLE `aow_workflow` DISABLE KEYS */;
/*!40000 ALTER TABLE `aow_workflow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aow_workflow_audit`
--

DROP TABLE IF EXISTS `aow_workflow_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aow_workflow_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aow_workflow_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aow_workflow_audit`
--

LOCK TABLES `aow_workflow_audit` WRITE;
/*!40000 ALTER TABLE `aow_workflow_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `aow_workflow_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `archived_documents_media_objects`
--

DROP TABLE IF EXISTS `archived_documents_media_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `archived_documents_media_objects` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `dimensions` varchar(50) DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `parent_field` varchar(100) DEFAULT NULL,
  `temporary` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `archived_documents_media_objects`
--

LOCK TABLES `archived_documents_media_objects` WRITE;
/*!40000 ALTER TABLE `archived_documents_media_objects` DISABLE KEYS */;
/*!40000 ALTER TABLE `archived_documents_media_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `async_task_items`
--

DROP TABLE IF EXISTS `async_task_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `async_task_items` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `async_task_id` varchar(36) DEFAULT NULL,
  `item_key` varchar(255) DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `item_module` varchar(100) DEFAULT NULL,
  `status` varchar(36) DEFAULT 'queued',
  `error_message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  `result_data` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `retry_count` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_ati_async_task_id` (`async_task_id`),
  KEY `idx_ati_async_task_status` (`async_task_id`,`status`),
  KEY `idx_ati_item_key` (`async_task_id`,`item_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `async_task_items`
--

LOCK TABLES `async_task_items` WRITE;
/*!40000 ALTER TABLE `async_task_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `async_task_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachments_references`
--

DROP TABLE IF EXISTS `attachments_references`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachments_references` (
  `parent_id` char(36) DEFAULT NULL,
  `parent_field` varchar(255) DEFAULT NULL,
  `parent_type` varchar(25) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `source_record_id` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  KEY `idx_attachments_ref_parent_id` (`parent_id`),
  KEY `idx_attachments_ref_source_record_id` (`source_record_id`),
  KEY `idx_attachments_ref_parent` (`parent_id`,`parent_type`,`parent_field`),
  KEY `idx_attachments_ref_source_type` (`type`,`source_record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachments_references`
--

LOCK TABLES `attachments_references` WRITE;
/*!40000 ALTER TABLE `attachments_references` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachments_references` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bugs`
--

DROP TABLE IF EXISTS `bugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bugs` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `bug_number` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `priority` varchar(100) DEFAULT NULL,
  `resolution` varchar(255) DEFAULT NULL,
  `work_log` text DEFAULT NULL,
  `found_in_release` char(36) DEFAULT NULL,
  `fixed_in_release` char(36) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `product_category` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bugsnumk` (`bug_number`),
  KEY `bug_number` (`bug_number`),
  KEY `idx_bug_name` (`name`),
  KEY `idx_bugs_assigned_user` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bugs`
--

LOCK TABLES `bugs` WRITE;
/*!40000 ALTER TABLE `bugs` DISABLE KEYS */;
/*!40000 ALTER TABLE `bugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bugs_audit`
--

DROP TABLE IF EXISTS `bugs_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bugs_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_bugs_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bugs_audit`
--

LOCK TABLES `bugs_audit` WRITE;
/*!40000 ALTER TABLE `bugs_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `bugs_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rebuild`
--

DROP TABLE IF EXISTS `cache_rebuild`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rebuild` (
  `cache_key` varchar(255) DEFAULT NULL,
  `rebuild` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rebuild`
--

LOCK TABLES `cache_rebuild` WRITE;
/*!40000 ALTER TABLE `cache_rebuild` DISABLE KEYS */;
INSERT INTO `cache_rebuild` VALUES
('rebuild_all',1),
('app-metadata-system-configs',1),
('rebuild_all',1),
('rebuild_all',1),
('app-metadata-navigation-0700a608-2bc2-4174-ae5d-7eef89fc2187',1),
('app-metadata-user-preferences-0700a608-2bc2-4174-ae5d-7eef89fc2187',1),
('app-metadata-language-strings-',1),
('app-metadata-theme-images',1),
('all-module-metadata-0700a608-2bc2-4174-ae5d-7eef89fc2187',1);
/*!40000 ALTER TABLE `cache_rebuild` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_account_meetings`
--

DROP TABLE IF EXISTS `calendar_account_meetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_account_meetings` (
  `id` varchar(36) NOT NULL,
  `calendar_account_id` varchar(36) DEFAULT NULL,
  `meeting_id` varchar(36) DEFAULT NULL,
  `calendar_account_source` varchar(255) DEFAULT NULL,
  `external_event_id` varchar(255) DEFAULT NULL,
  `last_sync` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_calendar_account_meeting` (`calendar_account_id`,`meeting_id`),
  KEY `idx_cal_acc_mtg_cal` (`calendar_account_id`),
  KEY `idx_cal_acc_mtg_mtg` (`meeting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_account_meetings`
--

LOCK TABLES `calendar_account_meetings` WRITE;
/*!40000 ALTER TABLE `calendar_account_meetings` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_account_meetings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_accounts`
--

DROP TABLE IF EXISTS `calendar_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_accounts` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  `type` varchar(255) DEFAULT 'personal',
  `oauth_connection_id` char(36) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `server_url` varchar(500) DEFAULT NULL,
  `api_key` varchar(255) DEFAULT NULL,
  `api_endpoint` varchar(500) DEFAULT NULL,
  `calendar_user_id` char(36) NOT NULL,
  `last_connection_status` tinyint(1) DEFAULT 0,
  `last_connection_test` datetime DEFAULT NULL,
  `last_sync_attempt_date` datetime DEFAULT NULL,
  `last_sync_attempt_status` varchar(20) DEFAULT NULL,
  `last_sync_attempt_message` varchar(50) DEFAULT NULL,
  `last_sync_date` datetime DEFAULT NULL,
  `external_calendar_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cal_acct_user_type_status` (`calendar_user_id`,`type`,`last_connection_status`,`deleted`),
  KEY `idx_cal_acct_external_cal_id` (`external_calendar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_accounts`
--

LOCK TABLES `calendar_accounts` WRITE;
/*!40000 ALTER TABLE `calendar_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calls`
--

DROP TABLE IF EXISTS `calls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `calls` (
  `id` char(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `duration_hours` int(2) DEFAULT NULL,
  `duration_minutes` int(2) DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `parent_type` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Planned',
  `direction` varchar(100) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `reminder_time` int(11) DEFAULT -1,
  `email_reminder_time` int(11) DEFAULT -1,
  `email_reminder_sent` tinyint(1) DEFAULT 0,
  `outlook_id` varchar(255) DEFAULT NULL,
  `repeat_type` varchar(36) DEFAULT NULL,
  `repeat_interval` int(3) DEFAULT 1,
  `repeat_dow` varchar(7) DEFAULT NULL,
  `repeat_until` date DEFAULT NULL,
  `repeat_count` int(7) DEFAULT NULL,
  `repeat_parent_id` char(36) DEFAULT NULL,
  `recurring_source` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_call_name` (`name`),
  KEY `idx_status` (`status`),
  KEY `idx_calls_date_start` (`date_start`),
  KEY `idx_calls_par_del` (`parent_id`,`parent_type`,`deleted`),
  KEY `idx_calls_assigned_del` (`deleted`,`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calls`
--

LOCK TABLES `calls` WRITE;
/*!40000 ALTER TABLE `calls` DISABLE KEYS */;
/*!40000 ALTER TABLE `calls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calls_contacts`
--

DROP TABLE IF EXISTS `calls_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `calls_contacts` (
  `id` varchar(36) NOT NULL,
  `call_id` varchar(36) DEFAULT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_con_call_call` (`call_id`),
  KEY `idx_con_call_con` (`contact_id`),
  KEY `idx_call_contact` (`call_id`,`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calls_contacts`
--

LOCK TABLES `calls_contacts` WRITE;
/*!40000 ALTER TABLE `calls_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `calls_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calls_leads`
--

DROP TABLE IF EXISTS `calls_leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `calls_leads` (
  `id` varchar(36) NOT NULL,
  `call_id` varchar(36) DEFAULT NULL,
  `lead_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_lead_call_call` (`call_id`),
  KEY `idx_lead_call_lead` (`lead_id`),
  KEY `idx_call_lead` (`call_id`,`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calls_leads`
--

LOCK TABLES `calls_leads` WRITE;
/*!40000 ALTER TABLE `calls_leads` DISABLE KEYS */;
/*!40000 ALTER TABLE `calls_leads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calls_reschedule`
--

DROP TABLE IF EXISTS `calls_reschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `calls_reschedule` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `call_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calls_reschedule`
--

LOCK TABLES `calls_reschedule` WRITE;
/*!40000 ALTER TABLE `calls_reschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `calls_reschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calls_reschedule_audit`
--

DROP TABLE IF EXISTS `calls_reschedule_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `calls_reschedule_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_calls_reschedule_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calls_reschedule_audit`
--

LOCK TABLES `calls_reschedule_audit` WRITE;
/*!40000 ALTER TABLE `calls_reschedule_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `calls_reschedule_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calls_users`
--

DROP TABLE IF EXISTS `calls_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `calls_users` (
  `id` varchar(36) NOT NULL,
  `call_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_usr_call_call` (`call_id`),
  KEY `idx_usr_call_usr` (`user_id`),
  KEY `idx_call_users` (`call_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calls_users`
--

LOCK TABLES `calls_users` WRITE;
/*!40000 ALTER TABLE `calls_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `calls_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_log`
--

DROP TABLE IF EXISTS `campaign_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_log` (
  `id` char(36) NOT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `target_tracker_key` varchar(36) DEFAULT NULL,
  `target_id` varchar(36) DEFAULT NULL,
  `target_type` varchar(100) DEFAULT NULL,
  `activity_type` varchar(100) DEFAULT NULL,
  `activity_date` datetime DEFAULT NULL,
  `archived` tinyint(1) DEFAULT 0,
  `hits` int(11) DEFAULT 0,
  `list_id` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `is_test_entry` tinyint(1) DEFAULT 0,
  `related_type` varchar(255) DEFAULT NULL,
  `related_id` char(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `more_information` varchar(100) DEFAULT NULL,
  `marketing_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_camp_tracker` (`target_tracker_key`),
  KEY `idx_camp_campaign_id` (`campaign_id`),
  KEY `idx_camp_more_info` (`more_information`),
  KEY `idx_target_id` (`target_id`),
  KEY `idx_related` (`related_id`,`related_type`,`marketing_id`,`deleted`),
  KEY `idx_target_id_deleted` (`target_id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_log`
--

LOCK TABLES `campaign_log` WRITE;
/*!40000 ALTER TABLE `campaign_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_trkrs`
--

DROP TABLE IF EXISTS `campaign_trkrs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_trkrs` (
  `id` char(36) NOT NULL,
  `tracker_name` varchar(255) DEFAULT NULL,
  `tracker_url` varchar(255) DEFAULT 'http://',
  `tracker_key` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` char(36) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `is_optout` tinyint(1) DEFAULT 0,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `campaign_tracker_key_idx` (`tracker_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_trkrs`
--

LOCK TABLES `campaign_trkrs` WRITE;
/*!40000 ALTER TABLE `campaign_trkrs` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_trkrs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaigns`
--

DROP TABLE IF EXISTS `campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaigns` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `tracker_key` int(11) NOT NULL AUTO_INCREMENT,
  `tracker_count` int(11) DEFAULT 0,
  `refer_url` varchar(255) DEFAULT 'http://',
  `tracker_text` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Planning',
  `impressions` int(11) DEFAULT 0,
  `currency_id` char(36) DEFAULT NULL,
  `budget` double DEFAULT NULL,
  `budget_usdollar` double DEFAULT NULL,
  `expected_cost_usdollar` double DEFAULT NULL,
  `actual_cost_usdollar` double DEFAULT NULL,
  `expected_revenue_usdollar` double DEFAULT NULL,
  `expected_cost` double DEFAULT NULL,
  `actual_cost` double DEFAULT NULL,
  `expected_revenue` double DEFAULT NULL,
  `campaign_type` varchar(100) DEFAULT 'NewsLetter',
  `objective` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `frequency` varchar(100) DEFAULT NULL,
  `survey_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `camp_auto_tracker_key` (`tracker_key`),
  KEY `idx_campaign_name` (`name`),
  KEY `idx_survey_id` (`survey_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaigns`
--

LOCK TABLES `campaigns` WRITE;
/*!40000 ALTER TABLE `campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaigns_audit`
--

DROP TABLE IF EXISTS `campaigns_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaigns_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_campaigns_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaigns_audit`
--

LOCK TABLES `campaigns_audit` WRITE;
/*!40000 ALTER TABLE `campaigns_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaigns_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cases`
--

DROP TABLE IF EXISTS `cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cases` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `case_number` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `priority` varchar(100) DEFAULT NULL,
  `resolution` text DEFAULT NULL,
  `work_log` text DEFAULT NULL,
  `account_id` char(36) DEFAULT NULL,
  `state` varchar(100) DEFAULT 'Open',
  `contact_created_by_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `casesnumk` (`case_number`),
  KEY `case_number` (`case_number`),
  KEY `idx_case_name` (`name`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_cases_stat_del` (`assigned_user_id`,`status`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cases`
--

LOCK TABLES `cases` WRITE;
/*!40000 ALTER TABLE `cases` DISABLE KEYS */;
/*!40000 ALTER TABLE `cases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cases_audit`
--

DROP TABLE IF EXISTS `cases_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cases_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cases_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cases_audit`
--

LOCK TABLES `cases_audit` WRITE;
/*!40000 ALTER TABLE `cases_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `cases_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cases_bugs`
--

DROP TABLE IF EXISTS `cases_bugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cases_bugs` (
  `id` varchar(36) NOT NULL,
  `case_id` varchar(36) DEFAULT NULL,
  `bug_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_cas_bug_cas` (`case_id`),
  KEY `idx_cas_bug_bug` (`bug_id`),
  KEY `idx_case_bug` (`case_id`,`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cases_bugs`
--

LOCK TABLES `cases_bugs` WRITE;
/*!40000 ALTER TABLE `cases_bugs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cases_bugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cases_cstm`
--

DROP TABLE IF EXISTS `cases_cstm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cases_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT 0.00000000,
  `jjwg_maps_lat_c` float(10,8) DEFAULT 0.00000000,
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cases_cstm`
--

LOCK TABLES `cases_cstm` WRITE;
/*!40000 ALTER TABLE `cases_cstm` DISABLE KEYS */;
/*!40000 ALTER TABLE `cases_cstm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `config` (
  `category` varchar(32) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `value` text DEFAULT NULL,
  KEY `idx_config_cat` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES
('notify','fromaddress','do_not_reply@example.com'),
('notify','fromname','SuiteCRM'),
('notify','send_by_default','1'),
('notify','on','1'),
('notify','send_from_assigning_user','0'),
('info','sugar_version','6.5.25'),
('MySettings','tab','YToyMzp7aTowO3M6NDoiSG9tZSI7aToxO3M6ODoiQWNjb3VudHMiO2k6MjtzOjg6IkNvbnRhY3RzIjtpOjM7czoxMDoiQU9TX1F1b3RlcyI7aTo0O3M6OToiRG9jdW1lbnRzIjtpOjU7czo5OiJDYW1wYWlnbnMiO2k6NjtzOjEyOiJBT1NfSW52b2ljZXMiO2k6NztzOjE3OiJSVF9SYWRpb0NhbXBhaWducyI7aTo4O3M6MTM6IkFPU19Db250cmFjdHMiO2k6OTtzOjk6IlByb3NwZWN0cyI7aToxMDtzOjEzOiJQcm9zcGVjdExpc3RzIjtpOjExO3M6NzoiUHJvamVjdCI7aToxMjtzOjE5OiJBTV9Qcm9qZWN0VGVtcGxhdGVzIjtpOjEzO3M6OToiRlBfZXZlbnRzIjtpOjE0O3M6MTg6IkZQX0V2ZW50X0xvY2F0aW9ucyI7aToxNTtzOjEyOiJBT1NfUHJvZHVjdHMiO2k6MTY7czoyMjoiQU9TX1Byb2R1Y3RfQ2F0ZWdvcmllcyI7aToxNztzOjE3OiJBT1NfUERGX1RlbXBsYXRlcyI7aToxODtzOjExOiJBT1JfUmVwb3J0cyI7aToxOTtzOjE3OiJBT0tfS25vd2xlZGdlQmFzZSI7aToyMDtzOjI5OiJBT0tfS25vd2xlZGdlX0Jhc2VfQ2F0ZWdvcmllcyI7aToyMTtzOjE0OiJFbWFpbFRlbXBsYXRlcyI7aToyMjtzOjc6IlN1cnZleXMiO30='),
('portal','on','0'),
('system','drafts_popup','1'),
('tracker','Tracker','1'),
('sugarfeed','enabled','1'),
('sugarfeed','module_UserFeed','1'),
('sugarfeed','module_Contacts','1'),
('sugarfeed','module_Opportunities','1'),
('sugarfeed','module_Cases','1'),
('sugarfeed','module_Leads','1'),
('Update','CheckUpdates','manual'),
('system','name','SuiteCRM'),
('system','adminwizard','1'),
('info','suitecrm_version','8.10.1'),
('MySettings','disable_useredit','no'),
('MySettings','hide_subpanels','YTowOnt9');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `salutation` varchar(255) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `do_not_call` tinyint(1) DEFAULT 0,
  `phone_home` varchar(100) DEFAULT NULL,
  `phone_mobile` varchar(100) DEFAULT NULL,
  `phone_work` varchar(100) DEFAULT NULL,
  `phone_other` varchar(100) DEFAULT NULL,
  `phone_fax` varchar(100) DEFAULT NULL,
  `lawful_basis` text DEFAULT NULL,
  `date_reviewed` date DEFAULT NULL,
  `lawful_basis_source` varchar(100) DEFAULT NULL,
  `primary_address_street` varchar(150) DEFAULT NULL,
  `primary_address_city` varchar(100) DEFAULT NULL,
  `primary_address_state` varchar(100) DEFAULT NULL,
  `primary_address_postalcode` varchar(20) DEFAULT NULL,
  `primary_address_country` varchar(255) DEFAULT NULL,
  `alt_address_street` varchar(150) DEFAULT NULL,
  `alt_address_city` varchar(100) DEFAULT NULL,
  `alt_address_state` varchar(100) DEFAULT NULL,
  `alt_address_postalcode` varchar(20) DEFAULT NULL,
  `alt_address_country` varchar(255) DEFAULT NULL,
  `assistant` varchar(75) DEFAULT NULL,
  `assistant_phone` varchar(100) DEFAULT NULL,
  `lead_source` varchar(255) DEFAULT NULL,
  `reports_to_id` char(36) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `joomla_account_id` varchar(255) DEFAULT NULL,
  `portal_account_disabled` tinyint(1) DEFAULT NULL,
  `portal_user_type` varchar(100) DEFAULT 'Single',
  PRIMARY KEY (`id`),
  KEY `idx_cont_last_first` (`last_name`,`first_name`,`deleted`),
  KEY `idx_contacts_del_last` (`deleted`,`last_name`),
  KEY `idx_cont_del_reports` (`deleted`,`reports_to_id`,`last_name`),
  KEY `idx_reports_to_id` (`reports_to_id`),
  KEY `idx_del_id_user` (`deleted`,`id`,`assigned_user_id`),
  KEY `idx_cont_assigned` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts_audit`
--

DROP TABLE IF EXISTS `contacts_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_contacts_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts_audit`
--

LOCK TABLES `contacts_audit` WRITE;
/*!40000 ALTER TABLE `contacts_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts_bugs`
--

DROP TABLE IF EXISTS `contacts_bugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts_bugs` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `bug_id` varchar(36) DEFAULT NULL,
  `contact_role` varchar(50) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_con_bug_con` (`contact_id`),
  KEY `idx_con_bug_bug` (`bug_id`),
  KEY `idx_contact_bug` (`contact_id`,`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts_bugs`
--

LOCK TABLES `contacts_bugs` WRITE;
/*!40000 ALTER TABLE `contacts_bugs` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts_bugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts_cases`
--

DROP TABLE IF EXISTS `contacts_cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts_cases` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `case_id` varchar(36) DEFAULT NULL,
  `contact_role` varchar(50) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_con_case_con` (`contact_id`),
  KEY `idx_con_case_case` (`case_id`),
  KEY `idx_contacts_cases` (`contact_id`,`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts_cases`
--

LOCK TABLES `contacts_cases` WRITE;
/*!40000 ALTER TABLE `contacts_cases` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts_cases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts_cstm`
--

DROP TABLE IF EXISTS `contacts_cstm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT 0.00000000,
  `jjwg_maps_lat_c` float(10,8) DEFAULT 0.00000000,
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts_cstm`
--

LOCK TABLES `contacts_cstm` WRITE;
/*!40000 ALTER TABLE `contacts_cstm` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts_cstm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts_users`
--

DROP TABLE IF EXISTS `contacts_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts_users` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_con_users_con` (`contact_id`),
  KEY `idx_con_users_user` (`user_id`),
  KEY `idx_contacts_users` (`contact_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts_users`
--

LOCK TABLES `contacts_users` WRITE;
/*!40000 ALTER TABLE `contacts_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cron_remove_documents`
--

DROP TABLE IF EXISTS `cron_remove_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cron_remove_documents` (
  `id` varchar(36) NOT NULL,
  `bean_id` varchar(36) DEFAULT NULL,
  `module` varchar(25) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cron_remove_document_bean_id` (`bean_id`),
  KEY `idx_cron_remove_document_stamp` (`date_modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cron_remove_documents`
--

LOCK TABLES `cron_remove_documents` WRITE;
/*!40000 ALTER TABLE `cron_remove_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `cron_remove_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `currencies` (
  `id` char(36) NOT NULL,
  `name` varchar(36) DEFAULT NULL,
  `symbol` varchar(36) DEFAULT NULL,
  `iso4217` varchar(3) DEFAULT NULL,
  `conversion_rate` double DEFAULT 0,
  `status` varchar(100) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `created_by` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_currency_name` (`name`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currencies`
--

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields`
--

DROP TABLE IF EXISTS `custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_fields` (
  `bean_id` varchar(36) DEFAULT NULL,
  `set_num` int(11) DEFAULT 0,
  `field0` varchar(255) DEFAULT NULL,
  `field1` varchar(255) DEFAULT NULL,
  `field2` varchar(255) DEFAULT NULL,
  `field3` varchar(255) DEFAULT NULL,
  `field4` varchar(255) DEFAULT NULL,
  `field5` varchar(255) DEFAULT NULL,
  `field6` varchar(255) DEFAULT NULL,
  `field7` varchar(255) DEFAULT NULL,
  `field8` varchar(255) DEFAULT NULL,
  `field9` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  KEY `idx_beanid_set_num` (`bean_id`,`set_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields`
--

LOCK TABLES `custom_fields` WRITE;
/*!40000 ALTER TABLE `custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_revisions`
--

DROP TABLE IF EXISTS `document_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_revisions` (
  `id` varchar(36) NOT NULL,
  `change_log` varchar(255) DEFAULT NULL,
  `document_id` varchar(36) DEFAULT NULL,
  `doc_id` varchar(100) DEFAULT NULL,
  `doc_type` varchar(100) DEFAULT NULL,
  `doc_url` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `file_ext` varchar(100) DEFAULT NULL,
  `file_mime_type` varchar(100) DEFAULT NULL,
  `revision` varchar(100) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documentrevision_mimetype` (`file_mime_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_revisions`
--

LOCK TABLES `document_revisions` WRITE;
/*!40000 ALTER TABLE `document_revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `document_name` varchar(255) DEFAULT NULL,
  `doc_id` varchar(100) DEFAULT NULL,
  `doc_type` varchar(100) DEFAULT 'Sugar',
  `doc_url` varchar(255) DEFAULT NULL,
  `active_date` date DEFAULT NULL,
  `exp_date` date DEFAULT NULL,
  `category_id` varchar(100) DEFAULT NULL,
  `subcategory_id` varchar(100) DEFAULT NULL,
  `status_id` varchar(100) DEFAULT 'Active',
  `document_revision_id` varchar(36) DEFAULT NULL,
  `related_doc_id` char(36) DEFAULT NULL,
  `related_doc_rev_id` char(36) DEFAULT NULL,
  `is_template` tinyint(1) DEFAULT 0,
  `template_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_doc_cat` (`category_id`,`subcategory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_accounts`
--

DROP TABLE IF EXISTS `documents_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_accounts` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `document_id` varchar(36) DEFAULT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_accounts_account_id` (`account_id`,`document_id`),
  KEY `documents_accounts_document_id` (`document_id`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_accounts`
--

LOCK TABLES `documents_accounts` WRITE;
/*!40000 ALTER TABLE `documents_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_bugs`
--

DROP TABLE IF EXISTS `documents_bugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_bugs` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `document_id` varchar(36) DEFAULT NULL,
  `bug_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_bugs_bug_id` (`bug_id`,`document_id`),
  KEY `documents_bugs_document_id` (`document_id`,`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_bugs`
--

LOCK TABLES `documents_bugs` WRITE;
/*!40000 ALTER TABLE `documents_bugs` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_bugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_cases`
--

DROP TABLE IF EXISTS `documents_cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_cases` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `document_id` varchar(36) DEFAULT NULL,
  `case_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_cases_case_id` (`case_id`,`document_id`),
  KEY `documents_cases_document_id` (`document_id`,`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_cases`
--

LOCK TABLES `documents_cases` WRITE;
/*!40000 ALTER TABLE `documents_cases` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_cases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_contacts`
--

DROP TABLE IF EXISTS `documents_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_contacts` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `document_id` varchar(36) DEFAULT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_contacts_contact_id` (`contact_id`,`document_id`),
  KEY `documents_contacts_document_id` (`document_id`,`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_contacts`
--

LOCK TABLES `documents_contacts` WRITE;
/*!40000 ALTER TABLE `documents_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_opportunities`
--

DROP TABLE IF EXISTS `documents_opportunities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_opportunities` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `document_id` varchar(36) DEFAULT NULL,
  `opportunity_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_docu_opps_oppo_id` (`opportunity_id`,`document_id`),
  KEY `idx_docu_oppo_docu_id` (`document_id`,`opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_opportunities`
--

LOCK TABLES `documents_opportunities` WRITE;
/*!40000 ALTER TABLE `documents_opportunities` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_opportunities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eapm`
--

DROP TABLE IF EXISTS `eapm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `eapm` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `application` varchar(100) DEFAULT 'webex',
  `api_data` text DEFAULT NULL,
  `consumer_key` varchar(255) DEFAULT NULL,
  `consumer_secret` varchar(255) DEFAULT NULL,
  `oauth_token` varchar(255) DEFAULT NULL,
  `oauth_secret` varchar(255) DEFAULT NULL,
  `validated` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_app_active` (`assigned_user_id`,`application`,`validated`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eapm`
--

LOCK TABLES `eapm` WRITE;
/*!40000 ALTER TABLE `eapm` DISABLE KEYS */;
/*!40000 ALTER TABLE `eapm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_addr_bean_rel`
--

DROP TABLE IF EXISTS `email_addr_bean_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_addr_bean_rel` (
  `id` char(36) NOT NULL,
  `email_address_id` char(36) NOT NULL,
  `bean_id` char(36) NOT NULL,
  `bean_module` varchar(100) DEFAULT NULL,
  `primary_address` tinyint(1) DEFAULT 0,
  `reply_to_address` tinyint(1) DEFAULT 0,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_email_address_id` (`email_address_id`),
  KEY `idx_bean_id` (`bean_id`,`bean_module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_addr_bean_rel`
--

LOCK TABLES `email_addr_bean_rel` WRITE;
/*!40000 ALTER TABLE `email_addr_bean_rel` DISABLE KEYS */;
INSERT INTO `email_addr_bean_rel` VALUES
('1','1','1','Users',1,0,'2026-10-20 23:02:02','2026-10-20 23:02:02',0);
/*!40000 ALTER TABLE `email_addr_bean_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_addresses`
--

DROP TABLE IF EXISTS `email_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_addresses` (
  `id` char(36) NOT NULL,
  `email_address` varchar(255) DEFAULT NULL,
  `email_address_caps` varchar(255) DEFAULT NULL,
  `invalid_email` tinyint(1) DEFAULT 0,
  `opt_out` tinyint(1) DEFAULT 0,
  `confirm_opt_in` varchar(255) DEFAULT 'not-opt-in',
  `confirm_opt_in_date` datetime DEFAULT NULL,
  `confirm_opt_in_sent_date` datetime DEFAULT NULL,
  `confirm_opt_in_fail_date` datetime DEFAULT NULL,
  `confirm_opt_in_token` varchar(255) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_ea_caps_opt_out_invalid` (`email_address_caps`,`opt_out`,`invalid_email`),
  KEY `idx_ea_opt_out_invalid` (`email_address`,`opt_out`,`invalid_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_addresses`
--

LOCK TABLES `email_addresses` WRITE;
/*!40000 ALTER TABLE `email_addresses` DISABLE KEYS */;
INSERT INTO `email_addresses` VALUES
('1','admin@radiocrm.local','ADMIN@RADIOCRM.LOCAL',0,0,'not-opt-in',NULL,NULL,NULL,NULL,'2026-10-20 23:02:02','2026-10-20 23:02:02',0);
/*!40000 ALTER TABLE `email_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_addresses_audit`
--

DROP TABLE IF EXISTS `email_addresses_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_addresses_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email_addresses_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_addresses_audit`
--

LOCK TABLES `email_addresses_audit` WRITE;
/*!40000 ALTER TABLE `email_addresses_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_addresses_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_cache`
--

DROP TABLE IF EXISTS `email_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_cache` (
  `ie_id` char(36) DEFAULT NULL,
  `mbox` varchar(60) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `fromaddr` varchar(100) DEFAULT NULL,
  `toaddr` varchar(255) DEFAULT NULL,
  `senddate` datetime DEFAULT NULL,
  `message_id` varchar(255) DEFAULT NULL,
  `mailsize` int(10) unsigned DEFAULT NULL,
  `imap_uid` int(10) unsigned DEFAULT NULL,
  `msgno` int(10) unsigned DEFAULT NULL,
  `recent` tinyint(4) DEFAULT NULL,
  `flagged` tinyint(4) DEFAULT NULL,
  `answered` tinyint(4) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `seen` tinyint(4) DEFAULT NULL,
  `draft` tinyint(4) DEFAULT NULL,
  KEY `idx_ie_id` (`ie_id`),
  KEY `idx_mail_date` (`ie_id`,`mbox`,`senddate`),
  KEY `idx_mail_from` (`ie_id`,`mbox`,`fromaddr`),
  KEY `idx_mail_subj` (`subject`),
  KEY `idx_mail_to` (`toaddr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_cache`
--

LOCK TABLES `email_cache` WRITE;
/*!40000 ALTER TABLE `email_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_marketing`
--

DROP TABLE IF EXISTS `email_marketing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_marketing` (
  `id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `from_name` varchar(100) DEFAULT NULL,
  `from_addr` varchar(100) DEFAULT NULL,
  `reply_to_name` varchar(100) DEFAULT NULL,
  `reply_to_addr` varchar(100) DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `template_id` char(36) NOT NULL,
  `status` varchar(100) DEFAULT 'draft',
  `duplicate` varchar(255) DEFAULT 'email',
  `queueing_status` varchar(100) DEFAULT 'not_started',
  `type` varchar(100) DEFAULT NULL,
  `has_test_data` tinyint(1) DEFAULT 0,
  `pause_reason` text DEFAULT NULL,
  `trackers_enabled` tinyint(1) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `outbound_email_id` char(36) DEFAULT NULL,
  `all_prospect_lists` tinyint(1) DEFAULT 0,
  `subject` varchar(255) DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `survey_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_emmkt_name` (`name`),
  KEY `idx_emmkit_del` (`deleted`),
  KEY `idx_status` (`status`),
  KEY `idx_date_start` (`date_start`),
  KEY `idx_survey_id` (`survey_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_marketing`
--

LOCK TABLES `email_marketing` WRITE;
/*!40000 ALTER TABLE `email_marketing` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_marketing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_marketing_prospect_lists`
--

DROP TABLE IF EXISTS `email_marketing_prospect_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_marketing_prospect_lists` (
  `id` varchar(36) NOT NULL,
  `prospect_list_id` varchar(36) DEFAULT NULL,
  `email_marketing_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `email_mp_prospects` (`email_marketing_id`,`prospect_list_id`),
  KEY `idx_prospect_list_id` (`prospect_list_id`),
  KEY `idx_email_marketing_id` (`email_marketing_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_marketing_prospect_lists`
--

LOCK TABLES `email_marketing_prospect_lists` WRITE;
/*!40000 ALTER TABLE `email_marketing_prospect_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_marketing_prospect_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `published` varchar(3) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `body_html` longtext DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `text_only` tinyint(1) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email_template_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates`
--

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
INSERT INTO `email_templates` VALUES
('21239b6e-61c2-4f85-a634-f15c4992f068','2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','off','Joomla Account Creation','Template used when informing a contact that they\'ve been given an account on the joomla portal.','Support Portal Account Created','Hi $contact_name,\n					   An account has been created for you at $portal_address.\n					   You may login using this email address and the password $joomla_pass','<p>Hi $contact_name,</p>\n					    <p>An account has been created for you at <a href=\"$portal_address\">$portal_address</a>.</p>\n					    <p>You may login using this email address and the password $joomla_pass</p>',0,NULL,NULL,'system'),
('4967f464-ccb9-4f99-a2f0-dc900052a21f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','off','Case Closure','Template for informing a contact that their case has been closed.','$acase_name [CASE:$acase_case_number] closed','Hi $contact_first_name $contact_last_name,\n\n					   Your case $acase_name (# $acase_case_number) has been closed on $acase_date_entered\n					   Status:				$acase_status\n					   Reference:			$acase_case_number\n					   Resolution:			$acase_resolution','<p> Hi $contact_first_name $contact_last_name,</p>\n					    <p>Your case $acase_name (# $acase_case_number) has been closed on $acase_date_entered</p>\n					    <table border=\"0\"><tbody>\n					    <tr><td>Status</td><td>$acase_status</td></tr>\n					    <tr><td>Reference</td><td>$acase_case_number</td></tr>\n					    <tr><td>Resolution</td><td>$acase_resolution</td></tr>\n					    </tbody></table>',0,NULL,NULL,'system'),
('63a6145f-8d62-4690-a0dc-6959b41e3b85','2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','off','Two Factor Authentication email','This template is used to send a user a code for Two Factor Authentication.','Two Factor Authentication Code','Two Factor Authentication code is $code.','<div><table width=\"550\"><tbody><tr><td><p>Two Factor Authentication code is <b>$code</b>.</p>  </td>         </tr><tr><td></td>         </tr> </tbody></table> </div>',0,NULL,0,'system'),
('7adc3a19-aeb8-461e-b26a-469f0600e14f','2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','off','Contact Case Update','Template to send to a contact when their case is updated.','$acase_name update [CASE:$acase_case_number]','Hi $user_first_name $user_last_name,\n\n					   You\'ve had an update to your case $acase_name (# $acase_case_number) on $aop_case_updates_date_entered:\n					       $contact_first_name $contact_last_name, said:\n					               $aop_case_updates_description','<p>Hi $contact_first_name $contact_last_name,</p>\n					    <p> </p>\n					    <p>You\'ve had an update to your case $acase_name (# $acase_case_number) on $aop_case_updates_date_entered:</p>\n					    <p><strong>$user_first_name $user_last_name said:</strong></p>\n					    <p style=\"padding-left:30px;\">$aop_case_updates_description</p>',0,NULL,NULL,'system'),
('89e6a7a7-cd65-43fb-849f-a9b876a0ed74','2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','off','User Case Update','Email template to send to a SuiteCRM user when their case is updated.','$acase_name (# $acase_case_number) update','Hi $user_first_name $user_last_name,\n\n					   You\'ve had an update to your case $acase_name (# $acase_case_number) on $aop_case_updates_date_entered:\n					       $contact_first_name $contact_last_name, said:\n					               $aop_case_updates_description\n                        You may review this Case at:\n                            $sugarurl/index.php?module=Cases&action=DetailView&record=$acase_id;','<p>Hi $user_first_name $user_last_name,</p>\n					     <p> </p>\n					     <p>You\'ve had an update to your case $acase_name (# $acase_case_number) on $aop_case_updates_date_entered:</p>\n					     <p><strong>$contact_first_name $contact_last_name, said:</strong></p>\n					     <p style=\"padding-left:30px;\">$aop_case_updates_description</p>\n					     <p>You may review this Case at: $sugarurl/index.php?module=Cases&action=DetailView&record=$acase_id;</p>',0,NULL,NULL,'system'),
('97738af4-3e7a-4d8b-ad98-fa2494507318','2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','off','System-generated password email','This template is used when the System Administrator sends a new password to a user.','New account information','\nHere is your account username and temporary password:\nUsername : $contact_user_user_name\nPassword : $contact_user_user_hash\n\n$config_site_url\n\nAfter you log in using the above password, you may be required to reset the password to one of your own choice.','<div><table width=\"550\"><tbody><tr><td><p>Here is your account username and temporary password:</p><p>Username : $contact_user_user_name </p><p>Password : $contact_user_user_hash </p><br /><p>$config_site_url</p><br /><p>After you log in using the above password, you may be required to reset the password to one of your own choice.</p>   </td>         </tr><tr><td></td>         </tr> </tbody></table> </div>',0,NULL,0,'system'),
('a5724d0c-be48-4f23-acf4-094b4f5f94e1','2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','off','Confirmed Opt In','Email template to send to a contact to confirm they have opted in.','Confirm Opt In','Hi $contact_first_name $contact_last_name, \\n Please confirm that you have opted in by selecting the following link: $sugarurl/index.php?entryPoint=ConfirmOptIn&from=$emailaddress_email_address','<p>Hi $contact_first_name $contact_last_name,</p>\n             <p>\n                Please confirm that you have opted in by selecting the following link:\n                <a href=\"$sugarurl/index.php?entryPoint=ConfirmOptIn&from=$emailaddress_confirm_opt_in_token\">Opt In</a>\n             </p>',0,NULL,NULL,'system'),
('b697b2ea-5946-465b-a6ad-b72a3549c430','2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','off','Case Creation','Template to send to a contact when a case is received from them.','$acase_name [CASE:$acase_case_number]','Hi $contact_first_name $contact_last_name,\n\n					   We\'ve received your case $acase_name (# $acase_case_number) on $acase_date_entered\n					   Status:		$acase_status\n					   Reference:	$acase_case_number\n					   Description:	$acase_description','<p> Hi $contact_first_name $contact_last_name,</p>\n					    <p>We\'ve received your case $acase_name (# $acase_case_number) on $acase_date_entered</p>\n					    <table border=\"0\"><tbody>\n					    <tr><td>Status</td><td>$acase_status</td></tr>\n					    <tr><td>Reference</td><td>$acase_case_number</td></tr>\n					    <tr><td>Description</td><td>$acase_description</td></tr>\n					    </tbody></table>',0,NULL,NULL,'system'),
('c563a646-ae78-4e65-ac6b-5555b4ec94d8','2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','off','Forgot Password email','This template is used to send a user a link to click to reset the user\'s account password.','Reset your account password','\nYou recently requested on $contact_user_pwd_last_changed to be able to reset your account password.\n\nClick on the link below to reset your password:\n\n$contact_user_link_guid','<div><table width=\"550\"><tbody><tr><td><p>You recently requested on $contact_user_pwd_last_changed to be able to reset your account password. </p><p>Click on the link below to reset your password:</p><p> $contact_user_link_guid </p>  </td>         </tr><tr><td></td>         </tr> </tbody></table> </div>',0,NULL,0,'system'),
('fa4c65ba-bcdd-4698-8509-2b2d87618ba5','2013-05-24 14:31:45','2026-10-16 10:57:58','1','1','off','Event Invite Template','Default event invite template.','You have been invited to $fp_events_name','Dear $contact_name,\nYou have been invited to $fp_events_name on $fp_events_date_start to $fp_events_date_end\n$fp_events_description\nYours Sincerely,\n','\n<p>Dear $contact_name,</p>\n<p>You have been invited to $fp_events_name on $fp_events_date_start to $fp_events_date_end</p>\n<p>$fp_events_description</p>\n<p>If you would like to accept this invititation please click accept.</p>\n<p> $fp_events_link or $fp_events_link_declined</p>\n<p>Yours Sincerely,</p>\n',0,NULL,NULL,'system');
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emailman`
--

DROP TABLE IF EXISTS `emailman`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `emailman` (
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `user_id` char(36) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `list_id` char(36) DEFAULT NULL,
  `send_date_time` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `more_information` varchar(100) DEFAULT NULL,
  `in_queue` tinyint(1) DEFAULT 0,
  `in_queue_date` datetime DEFAULT NULL,
  `send_attempts` int(11) DEFAULT 0,
  `deleted` tinyint(1) DEFAULT 0,
  `related_type` varchar(100) DEFAULT NULL,
  `related_id` char(36) DEFAULT NULL,
  `related_confirm_opt_in` tinyint(1) DEFAULT 0,
  `marketing_id` char(36) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_eman_list` (`list_id`,`user_id`,`deleted`),
  KEY `idx_eman_campaign_id` (`campaign_id`),
  KEY `idx_eman_relid_reltype_id` (`related_id`,`related_type`,`campaign_id`),
  KEY `idx_eman_related` (`related_id`,`related_type`,`marketing_id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emailman`
--

LOCK TABLES `emailman` WRITE;
/*!40000 ALTER TABLE `emailman` DISABLE KEYS */;
/*!40000 ALTER TABLE `emailman` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emails`
--

DROP TABLE IF EXISTS `emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `emails` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `orphaned` tinyint(1) DEFAULT NULL,
  `last_synced` datetime DEFAULT NULL,
  `date_sent_received` datetime DEFAULT NULL,
  `message_id` varchar(255) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `flagged` tinyint(1) DEFAULT NULL,
  `reply_to_status` tinyint(1) DEFAULT NULL,
  `intent` varchar(100) DEFAULT 'pick',
  `mailbox_id` char(36) DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `addrs_metadata` text DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `uid` varchar(255) DEFAULT NULL,
  `category_id` varchar(100) DEFAULT NULL,
  `outbound_email_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email_name` (`name`),
  KEY `idx_message_id` (`message_id`),
  KEY `idx_email_parent_id` (`parent_id`),
  KEY `idx_email_assigned` (`assigned_user_id`,`type`,`status`),
  KEY `idx_email_cat` (`category_id`),
  KEY `idx_email_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emails`
--

LOCK TABLES `emails` WRITE;
/*!40000 ALTER TABLE `emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emails_beans`
--

DROP TABLE IF EXISTS `emails_beans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `emails_beans` (
  `id` char(36) NOT NULL,
  `email_id` char(36) DEFAULT NULL,
  `bean_id` char(36) DEFAULT NULL,
  `bean_module` varchar(100) DEFAULT NULL,
  `campaign_data` text DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_emails_beans_bean_id` (`bean_id`),
  KEY `idx_emails_beans_email_bean` (`email_id`,`bean_id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emails_beans`
--

LOCK TABLES `emails_beans` WRITE;
/*!40000 ALTER TABLE `emails_beans` DISABLE KEYS */;
/*!40000 ALTER TABLE `emails_beans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emails_email_addr_rel`
--

DROP TABLE IF EXISTS `emails_email_addr_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `emails_email_addr_rel` (
  `id` char(36) NOT NULL,
  `email_id` char(36) NOT NULL,
  `address_type` varchar(4) DEFAULT NULL,
  `email_address_id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_eearl_email_id` (`email_id`,`address_type`),
  KEY `idx_eearl_address_id` (`email_address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emails_email_addr_rel`
--

LOCK TABLES `emails_email_addr_rel` WRITE;
/*!40000 ALTER TABLE `emails_email_addr_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `emails_email_addr_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emails_text`
--

DROP TABLE IF EXISTS `emails_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `emails_text` (
  `email_id` char(36) NOT NULL,
  `from_addr` varchar(255) DEFAULT NULL,
  `reply_to_addr` varchar(255) DEFAULT NULL,
  `to_addrs` text DEFAULT NULL,
  `cc_addrs` text DEFAULT NULL,
  `bcc_addrs` text DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `description_html` longtext DEFAULT NULL,
  `raw_source` longtext DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`email_id`),
  KEY `emails_textfromaddr` (`from_addr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emails_text`
--

LOCK TABLES `emails_text` WRITE;
/*!40000 ALTER TABLE `emails_text` DISABLE KEYS */;
/*!40000 ALTER TABLE `emails_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `external_oauth_connections`
--

DROP TABLE IF EXISTS `external_oauth_connections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `external_oauth_connections` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `type` varchar(255) DEFAULT NULL,
  `client_id` varchar(32) DEFAULT NULL,
  `client_secret` varchar(32) DEFAULT NULL,
  `token_type` varchar(32) DEFAULT NULL,
  `expires_in` varchar(32) DEFAULT NULL,
  `access_token` text DEFAULT NULL,
  `refresh_token` text DEFAULT NULL,
  `external_oauth_provider_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `external_oauth_connections`
--

LOCK TABLES `external_oauth_connections` WRITE;
/*!40000 ALTER TABLE `external_oauth_connections` DISABLE KEYS */;
/*!40000 ALTER TABLE `external_oauth_connections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `external_oauth_providers`
--

DROP TABLE IF EXISTS `external_oauth_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `external_oauth_providers` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `type` varchar(255) DEFAULT NULL,
  `connector` varchar(255) DEFAULT NULL,
  `redirect_uri_type` varchar(50) DEFAULT 'pretty_url',
  `client_id` varchar(255) DEFAULT NULL,
  `client_secret` varchar(255) DEFAULT NULL,
  `scope` text DEFAULT NULL,
  `url_authorize` varchar(255) DEFAULT NULL,
  `authorize_url_options` text DEFAULT NULL,
  `url_access_token` varchar(255) DEFAULT NULL,
  `extra_provider_params` text DEFAULT NULL,
  `get_token_request_grant` varchar(255) DEFAULT 'authorization_code',
  `get_token_request_options` text DEFAULT NULL,
  `refresh_token_request_grant` varchar(255) DEFAULT 'refresh_token',
  `refresh_token_request_options` text DEFAULT NULL,
  `access_token_mapping` varchar(255) DEFAULT 'access_token',
  `expires_in_mapping` varchar(255) DEFAULT 'expires_in',
  `refresh_token_mapping` varchar(255) DEFAULT 'refresh_token',
  `token_type_mapping` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `external_oauth_providers`
--

LOCK TABLES `external_oauth_providers` WRITE;
/*!40000 ALTER TABLE `external_oauth_providers` DISABLE KEYS */;
/*!40000 ALTER TABLE `external_oauth_providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorites` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `parent_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorites`
--

LOCK TABLES `favorites` WRITE;
/*!40000 ALTER TABLE `favorites` DISABLE KEYS */;
/*!40000 ALTER TABLE `favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields_meta_data`
--

DROP TABLE IF EXISTS `fields_meta_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields_meta_data` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `vname` varchar(255) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `help` varchar(255) DEFAULT NULL,
  `custom_module` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `len` int(11) DEFAULT NULL,
  `required` tinyint(1) DEFAULT 0,
  `default_value` varchar(255) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `audited` tinyint(1) DEFAULT 0,
  `massupdate` tinyint(1) DEFAULT 0,
  `duplicate_merge` smallint(6) DEFAULT 0,
  `reportable` tinyint(1) DEFAULT 1,
  `importable` varchar(255) DEFAULT NULL,
  `ext1` varchar(255) DEFAULT NULL,
  `ext2` varchar(255) DEFAULT NULL,
  `ext3` varchar(255) DEFAULT NULL,
  `ext4` text DEFAULT NULL,
  `metadata` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_meta_id_del` (`id`,`deleted`),
  KEY `idx_meta_cm_del` (`custom_module`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields_meta_data`
--

LOCK TABLES `fields_meta_data` WRITE;
/*!40000 ALTER TABLE `fields_meta_data` DISABLE KEYS */;
INSERT INTO `fields_meta_data` VALUES
('Accountsjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Accounts','varchar',255,0,NULL,'2026-10-16 10:57:58',0,0,0,0,1,'true',NULL,'','','','[]'),
('Accountsjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Accounts','varchar',255,0,NULL,'2026-10-16 10:57:58',0,0,0,0,1,'true',NULL,'','','','[]'),
('Accountsjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Accounts','float',10,0,'0.00000000','2026-10-16 10:57:58',0,0,0,0,1,'true','8','','','','[]'),
('Accountsjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Accounts','float',11,0,'0.00000000','2026-10-16 10:57:58',0,0,0,0,1,'true','8','','','','[]'),
('Casesjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Cases','varchar',255,0,NULL,'2026-10-16 10:57:58',0,0,0,0,1,'true',NULL,'','','','[]'),
('Casesjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Cases','varchar',255,0,NULL,'2026-10-16 10:57:58',0,0,0,0,1,'true',NULL,'','','','[]'),
('Casesjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Cases','float',10,0,'0.00000000','2026-10-16 10:57:58',0,0,0,0,1,'true','8','','','','[]'),
('Casesjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Cases','float',11,0,'0.00000000','2026-10-16 10:57:58',0,0,0,0,1,'true','8','','','','[]'),
('Contactsjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Contacts','varchar',255,0,NULL,'2026-10-16 10:57:58',0,0,0,0,1,'true',NULL,'','','','[]'),
('Contactsjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Contacts','varchar',255,0,NULL,'2026-10-16 10:57:58',0,0,0,0,1,'true',NULL,'','','','[]'),
('Contactsjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Contacts','float',10,0,'0.00000000','2026-10-16 10:57:58',0,0,0,0,1,'true','8','','','','[]'),
('Contactsjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Contacts','float',11,0,'0.00000000','2026-10-16 10:57:58',0,0,0,0,1,'true','8','','','','[]'),
('Leadsjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Leads','varchar',255,0,NULL,'2026-10-16 10:57:58',0,0,0,0,1,'true',NULL,'','','','[]'),
('Leadsjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Leads','varchar',255,0,NULL,'2026-10-16 10:57:58',0,0,0,0,1,'true',NULL,'','','','[]'),
('Leadsjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Leads','float',10,0,'0.00000000','2026-10-16 10:57:58',0,0,0,0,1,'true','8','','','','[]'),
('Leadsjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Leads','float',11,0,'0.00000000','2026-10-16 10:57:58',0,0,0,0,1,'true','8','','','','[]'),
('Meetingsjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Meetings','varchar',255,0,NULL,'2026-10-16 10:57:58',0,0,0,0,1,'true',NULL,'','','','[]'),
('Meetingsjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Meetings','varchar',255,0,NULL,'2026-10-16 10:57:58',0,0,0,0,1,'true',NULL,'','','','[]'),
('Meetingsjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Meetings','float',10,0,'0.00000000','2026-10-16 10:57:58',0,0,0,0,1,'true','8','','','','[]'),
('Meetingsjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Meetings','float',11,0,'0.00000000','2026-10-16 10:57:58',0,0,0,0,1,'true','8','','','','[]'),
('Opportunitiesjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Opportunities','varchar',255,0,NULL,'2026-10-16 10:57:58',0,0,0,0,1,'true',NULL,'','','','[]'),
('Opportunitiesjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Opportunities','varchar',255,0,NULL,'2026-10-16 10:57:58',0,0,0,0,1,'true',NULL,'','','','[]'),
('Opportunitiesjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Opportunities','float',10,0,'0.00000000','2026-10-16 10:57:58',0,0,0,0,1,'true','8','','','','[]'),
('Opportunitiesjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Opportunities','float',11,0,'0.00000000','2026-10-16 10:57:58',0,0,0,0,1,'true','8','','','','[]'),
('Projectjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Project','varchar',255,0,NULL,'2026-10-16 10:57:58',0,0,0,0,1,'true',NULL,'','','','[]'),
('Projectjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Project','varchar',255,0,NULL,'2026-10-16 10:57:58',0,0,0,0,1,'true',NULL,'','','','[]'),
('Projectjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Project','float',10,0,'0.00000000','2026-10-16 10:57:58',0,0,0,0,1,'true','8','','','','[]'),
('Projectjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Project','float',11,0,'0.00000000','2026-10-16 10:57:58',0,0,0,0,1,'true','8','','','','[]'),
('Prospectsjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Prospects','varchar',255,0,NULL,'2026-10-16 10:57:58',0,0,0,0,1,'true',NULL,'','','','[]'),
('Prospectsjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Prospects','varchar',255,0,NULL,'2026-10-16 10:57:58',0,0,0,0,1,'true',NULL,'','','','[]'),
('Prospectsjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Prospects','float',10,0,'0.00000000','2026-10-16 10:57:58',0,0,0,0,1,'true','8','','','','[]'),
('Prospectsjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Prospects','float',11,0,'0.00000000','2026-10-16 10:57:58',0,0,0,0,1,'true','8','','','','[]');
/*!40000 ALTER TABLE `fields_meta_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folders`
--

DROP TABLE IF EXISTS `folders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `folders` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `folder_type` varchar(25) DEFAULT NULL,
  `parent_folder` char(36) DEFAULT NULL,
  `has_child` tinyint(1) DEFAULT 0,
  `is_group` tinyint(1) DEFAULT 0,
  `is_dynamic` tinyint(1) DEFAULT 0,
  `dynamic_query` text DEFAULT NULL,
  `assign_to_id` char(36) DEFAULT NULL,
  `created_by` char(36) NOT NULL,
  `modified_by` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_parent_folder` (`parent_folder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folders`
--

LOCK TABLES `folders` WRITE;
/*!40000 ALTER TABLE `folders` DISABLE KEYS */;
/*!40000 ALTER TABLE `folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folders_rel`
--

DROP TABLE IF EXISTS `folders_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `folders_rel` (
  `id` char(36) NOT NULL,
  `folder_id` char(36) NOT NULL,
  `polymorphic_module` varchar(25) DEFAULT NULL,
  `polymorphic_id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_poly_module_poly_id` (`polymorphic_module`,`polymorphic_id`),
  KEY `idx_fr_id_deleted_poly` (`folder_id`,`deleted`,`polymorphic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folders_rel`
--

LOCK TABLES `folders_rel` WRITE;
/*!40000 ALTER TABLE `folders_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `folders_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folders_subscriptions`
--

DROP TABLE IF EXISTS `folders_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `folders_subscriptions` (
  `id` char(36) NOT NULL,
  `folder_id` char(36) NOT NULL,
  `assigned_user_id` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_folder_id_assigned_user_id` (`folder_id`,`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folders_subscriptions`
--

LOCK TABLES `folders_subscriptions` WRITE;
/*!40000 ALTER TABLE `folders_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `folders_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fp_event_locations`
--

DROP TABLE IF EXISTS `fp_event_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fp_event_locations` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `address_city` varchar(100) DEFAULT NULL,
  `address_country` varchar(100) DEFAULT NULL,
  `address_postalcode` varchar(20) DEFAULT NULL,
  `address_state` varchar(100) DEFAULT NULL,
  `capacity` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fp_event_locations`
--

LOCK TABLES `fp_event_locations` WRITE;
/*!40000 ALTER TABLE `fp_event_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `fp_event_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fp_event_locations_audit`
--

DROP TABLE IF EXISTS `fp_event_locations_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fp_event_locations_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fp_event_locations_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fp_event_locations_audit`
--

LOCK TABLES `fp_event_locations_audit` WRITE;
/*!40000 ALTER TABLE `fp_event_locations_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `fp_event_locations_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fp_event_locations_fp_events_1_c`
--

DROP TABLE IF EXISTS `fp_event_locations_fp_events_1_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fp_event_locations_fp_events_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `fp_event_locations_fp_events_1fp_event_locations_ida` varchar(36) DEFAULT NULL,
  `fp_event_locations_fp_events_1fp_events_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fp_event_locations_fp_events_1_ida1` (`fp_event_locations_fp_events_1fp_event_locations_ida`),
  KEY `fp_event_locations_fp_events_1_alt` (`fp_event_locations_fp_events_1fp_events_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fp_event_locations_fp_events_1_c`
--

LOCK TABLES `fp_event_locations_fp_events_1_c` WRITE;
/*!40000 ALTER TABLE `fp_event_locations_fp_events_1_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `fp_event_locations_fp_events_1_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fp_events`
--

DROP TABLE IF EXISTS `fp_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fp_events` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `duration_hours` int(3) DEFAULT NULL,
  `duration_minutes` int(2) DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `budget` decimal(26,6) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `invite_templates` varchar(100) DEFAULT NULL,
  `accept_redirect` varchar(255) DEFAULT NULL,
  `decline_redirect` varchar(255) DEFAULT NULL,
  `activity_status_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fp_events`
--

LOCK TABLES `fp_events` WRITE;
/*!40000 ALTER TABLE `fp_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `fp_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fp_events_audit`
--

DROP TABLE IF EXISTS `fp_events_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fp_events_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fp_events_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fp_events_audit`
--

LOCK TABLES `fp_events_audit` WRITE;
/*!40000 ALTER TABLE `fp_events_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `fp_events_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fp_events_contacts_c`
--

DROP TABLE IF EXISTS `fp_events_contacts_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fp_events_contacts_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `fp_events_contactsfp_events_ida` varchar(36) DEFAULT NULL,
  `fp_events_contactscontacts_idb` varchar(36) DEFAULT NULL,
  `invite_status` varchar(25) DEFAULT 'Not Invited',
  `accept_status` varchar(25) DEFAULT 'No Response',
  `email_responded` int(2) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `fp_events_contacts_alt` (`fp_events_contactsfp_events_ida`,`fp_events_contactscontacts_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fp_events_contacts_c`
--

LOCK TABLES `fp_events_contacts_c` WRITE;
/*!40000 ALTER TABLE `fp_events_contacts_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `fp_events_contacts_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fp_events_fp_event_delegates_1_c`
--

DROP TABLE IF EXISTS `fp_events_fp_event_delegates_1_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fp_events_fp_event_delegates_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `fp_events_fp_event_delegates_1fp_events_ida` varchar(36) DEFAULT NULL,
  `fp_events_fp_event_delegates_1fp_event_delegates_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fp_events_fp_event_delegates_1_ida1` (`fp_events_fp_event_delegates_1fp_events_ida`),
  KEY `fp_events_fp_event_delegates_1_alt` (`fp_events_fp_event_delegates_1fp_event_delegates_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fp_events_fp_event_delegates_1_c`
--

LOCK TABLES `fp_events_fp_event_delegates_1_c` WRITE;
/*!40000 ALTER TABLE `fp_events_fp_event_delegates_1_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `fp_events_fp_event_delegates_1_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fp_events_fp_event_locations_1_c`
--

DROP TABLE IF EXISTS `fp_events_fp_event_locations_1_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fp_events_fp_event_locations_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `fp_events_fp_event_locations_1fp_events_ida` varchar(36) DEFAULT NULL,
  `fp_events_fp_event_locations_1fp_event_locations_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fp_events_fp_event_locations_1_alt` (`fp_events_fp_event_locations_1fp_events_ida`,`fp_events_fp_event_locations_1fp_event_locations_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fp_events_fp_event_locations_1_c`
--

LOCK TABLES `fp_events_fp_event_locations_1_c` WRITE;
/*!40000 ALTER TABLE `fp_events_fp_event_locations_1_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `fp_events_fp_event_locations_1_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fp_events_leads_1_c`
--

DROP TABLE IF EXISTS `fp_events_leads_1_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fp_events_leads_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `fp_events_leads_1fp_events_ida` varchar(36) DEFAULT NULL,
  `fp_events_leads_1leads_idb` varchar(36) DEFAULT NULL,
  `invite_status` varchar(25) DEFAULT 'Not Invited',
  `accept_status` varchar(25) DEFAULT 'No Response',
  `email_responded` int(2) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `fp_events_leads_1_alt` (`fp_events_leads_1fp_events_ida`,`fp_events_leads_1leads_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fp_events_leads_1_c`
--

LOCK TABLES `fp_events_leads_1_c` WRITE;
/*!40000 ALTER TABLE `fp_events_leads_1_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `fp_events_leads_1_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fp_events_prospects_1_c`
--

DROP TABLE IF EXISTS `fp_events_prospects_1_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fp_events_prospects_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `fp_events_prospects_1fp_events_ida` varchar(36) DEFAULT NULL,
  `fp_events_prospects_1prospects_idb` varchar(36) DEFAULT NULL,
  `invite_status` varchar(25) DEFAULT 'Not Invited',
  `accept_status` varchar(25) DEFAULT 'No Response',
  `email_responded` int(2) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `fp_events_prospects_1_alt` (`fp_events_prospects_1fp_events_ida`,`fp_events_prospects_1prospects_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fp_events_prospects_1_c`
--

LOCK TABLES `fp_events_prospects_1_c` WRITE;
/*!40000 ALTER TABLE `fp_events_prospects_1_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `fp_events_prospects_1_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_maps`
--

DROP TABLE IF EXISTS `import_maps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_maps` (
  `id` char(36) NOT NULL,
  `name` varchar(254) DEFAULT NULL,
  `source` varchar(36) DEFAULT NULL,
  `enclosure` varchar(1) DEFAULT ' ',
  `delimiter` varchar(1) DEFAULT ',',
  `module` varchar(36) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `default_values` text DEFAULT NULL,
  `has_header` tinyint(1) DEFAULT 1,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `is_published` varchar(3) DEFAULT 'no',
  PRIMARY KEY (`id`),
  KEY `idx_owner_module_name` (`assigned_user_id`,`module`,`name`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_maps`
--

LOCK TABLES `import_maps` WRITE;
/*!40000 ALTER TABLE `import_maps` DISABLE KEYS */;
/*!40000 ALTER TABLE `import_maps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inbound_email`
--

DROP TABLE IF EXISTS `inbound_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inbound_email` (
  `id` varchar(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `last_import_run_datetime` datetime DEFAULT NULL,
  `mailbox_last_imported_days` text DEFAULT NULL,
  `email_import_per_run_threshold` int(11) DEFAULT NULL,
  `email_import_timeframe_start` varchar(255) DEFAULT NULL,
  `email_import_unread_only` tinyint(1) DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Active',
  `email_body_filtering` varchar(255) DEFAULT 'multi',
  `server_url` varchar(100) DEFAULT NULL,
  `connection_string` varchar(255) DEFAULT NULL,
  `email_user` varchar(100) DEFAULT NULL,
  `email_password` varchar(100) DEFAULT NULL,
  `port` int(5) DEFAULT 143,
  `service` varchar(50) DEFAULT NULL,
  `mailbox` text DEFAULT NULL,
  `sentFolder` varchar(255) DEFAULT NULL,
  `trashFolder` varchar(255) DEFAULT NULL,
  `delete_seen` tinyint(1) DEFAULT 0,
  `move_messages_to_trash_after_import` tinyint(1) DEFAULT 0,
  `mailbox_type` varchar(10) DEFAULT NULL,
  `template_id` char(36) DEFAULT NULL,
  `stored_options` text DEFAULT NULL,
  `group_id` char(36) DEFAULT NULL,
  `is_personal` tinyint(1) DEFAULT 0,
  `groupfolder_id` char(36) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `auth_type` varchar(255) DEFAULT 'basic',
  `protocol` varchar(255) DEFAULT 'imap',
  `is_ssl` tinyint(1) DEFAULT 0,
  `distribution_user_id` char(36) DEFAULT NULL,
  `outbound_email_id` char(36) DEFAULT NULL,
  `create_case_template_id` char(36) DEFAULT NULL,
  `external_oauth_connection_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inbound_email`
--

LOCK TABLES `inbound_email` WRITE;
/*!40000 ALTER TABLE `inbound_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `inbound_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inbound_email_autoreply`
--

DROP TABLE IF EXISTS `inbound_email_autoreply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inbound_email_autoreply` (
  `id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `autoreplied_to` varchar(100) DEFAULT NULL,
  `ie_id` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ie_autoreplied_to` (`autoreplied_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inbound_email_autoreply`
--

LOCK TABLES `inbound_email_autoreply` WRITE;
/*!40000 ALTER TABLE `inbound_email_autoreply` DISABLE KEYS */;
/*!40000 ALTER TABLE `inbound_email_autoreply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inbound_email_cache_ts`
--

DROP TABLE IF EXISTS `inbound_email_cache_ts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inbound_email_cache_ts` (
  `id` varchar(255) NOT NULL,
  `ie_timestamp` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inbound_email_cache_ts`
--

LOCK TABLES `inbound_email_cache_ts` WRITE;
/*!40000 ALTER TABLE `inbound_email_cache_ts` DISABLE KEYS */;
/*!40000 ALTER TABLE `inbound_email_cache_ts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jjwg_address_cache`
--

DROP TABLE IF EXISTS `jjwg_address_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jjwg_address_cache` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `lat` float(10,8) DEFAULT NULL,
  `lng` float(11,8) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jjwg_address_cache`
--

LOCK TABLES `jjwg_address_cache` WRITE;
/*!40000 ALTER TABLE `jjwg_address_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `jjwg_address_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jjwg_address_cache_audit`
--

DROP TABLE IF EXISTS `jjwg_address_cache_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jjwg_address_cache_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_jjwg_address_cache_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jjwg_address_cache_audit`
--

LOCK TABLES `jjwg_address_cache_audit` WRITE;
/*!40000 ALTER TABLE `jjwg_address_cache_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `jjwg_address_cache_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jjwg_areas`
--

DROP TABLE IF EXISTS `jjwg_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jjwg_areas` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `coordinates` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jjwg_areas`
--

LOCK TABLES `jjwg_areas` WRITE;
/*!40000 ALTER TABLE `jjwg_areas` DISABLE KEYS */;
/*!40000 ALTER TABLE `jjwg_areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jjwg_areas_audit`
--

DROP TABLE IF EXISTS `jjwg_areas_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jjwg_areas_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_jjwg_areas_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jjwg_areas_audit`
--

LOCK TABLES `jjwg_areas_audit` WRITE;
/*!40000 ALTER TABLE `jjwg_areas_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `jjwg_areas_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jjwg_maps`
--

DROP TABLE IF EXISTS `jjwg_maps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jjwg_maps` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `distance` float(9,4) DEFAULT NULL,
  `unit_type` varchar(100) DEFAULT 'mi',
  `module_type` varchar(100) DEFAULT 'Accounts',
  `parent_type` varchar(255) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jjwg_maps`
--

LOCK TABLES `jjwg_maps` WRITE;
/*!40000 ALTER TABLE `jjwg_maps` DISABLE KEYS */;
/*!40000 ALTER TABLE `jjwg_maps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jjwg_maps_audit`
--

DROP TABLE IF EXISTS `jjwg_maps_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jjwg_maps_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_jjwg_maps_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jjwg_maps_audit`
--

LOCK TABLES `jjwg_maps_audit` WRITE;
/*!40000 ALTER TABLE `jjwg_maps_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `jjwg_maps_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jjwg_maps_jjwg_areas_c`
--

DROP TABLE IF EXISTS `jjwg_maps_jjwg_areas_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jjwg_maps_jjwg_areas_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `jjwg_maps_5304wg_maps_ida` varchar(36) DEFAULT NULL,
  `jjwg_maps_41f2g_areas_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jjwg_maps_jjwg_areas_alt` (`jjwg_maps_5304wg_maps_ida`,`jjwg_maps_41f2g_areas_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jjwg_maps_jjwg_areas_c`
--

LOCK TABLES `jjwg_maps_jjwg_areas_c` WRITE;
/*!40000 ALTER TABLE `jjwg_maps_jjwg_areas_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `jjwg_maps_jjwg_areas_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jjwg_maps_jjwg_markers_c`
--

DROP TABLE IF EXISTS `jjwg_maps_jjwg_markers_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jjwg_maps_jjwg_markers_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `jjwg_maps_b229wg_maps_ida` varchar(36) DEFAULT NULL,
  `jjwg_maps_2e31markers_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jjwg_maps_jjwg_markers_alt` (`jjwg_maps_b229wg_maps_ida`,`jjwg_maps_2e31markers_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jjwg_maps_jjwg_markers_c`
--

LOCK TABLES `jjwg_maps_jjwg_markers_c` WRITE;
/*!40000 ALTER TABLE `jjwg_maps_jjwg_markers_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `jjwg_maps_jjwg_markers_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jjwg_markers`
--

DROP TABLE IF EXISTS `jjwg_markers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jjwg_markers` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `jjwg_maps_lat` float(10,8) DEFAULT 0.00000000,
  `jjwg_maps_lng` float(11,8) DEFAULT 0.00000000,
  `marker_image` varchar(100) DEFAULT 'company',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jjwg_markers`
--

LOCK TABLES `jjwg_markers` WRITE;
/*!40000 ALTER TABLE `jjwg_markers` DISABLE KEYS */;
/*!40000 ALTER TABLE `jjwg_markers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jjwg_markers_audit`
--

DROP TABLE IF EXISTS `jjwg_markers_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jjwg_markers_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_jjwg_markers_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jjwg_markers_audit`
--

LOCK TABLES `jjwg_markers_audit` WRITE;
/*!40000 ALTER TABLE `jjwg_markers_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `jjwg_markers_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_queue`
--

DROP TABLE IF EXISTS `job_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_queue` (
  `assigned_user_id` char(36) DEFAULT NULL,
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `scheduler_id` char(36) DEFAULT NULL,
  `execute_time` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `resolution` varchar(20) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `target` varchar(255) DEFAULT NULL,
  `data` text DEFAULT NULL,
  `requeue` tinyint(1) DEFAULT 0,
  `retry_count` tinyint(4) DEFAULT NULL,
  `failure_count` tinyint(4) DEFAULT NULL,
  `job_delay` int(11) DEFAULT NULL,
  `client` varchar(255) DEFAULT NULL,
  `percent_complete` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status_scheduler` (`status`,`scheduler_id`),
  KEY `idx_status_time` (`status`,`execute_time`,`date_entered`),
  KEY `idx_status_entered` (`status`,`date_entered`),
  KEY `idx_status_modified` (`status`,`date_modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_queue`
--

LOCK TABLES `job_queue` WRITE;
/*!40000 ALTER TABLE `job_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leads`
--

DROP TABLE IF EXISTS `leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leads` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `salutation` varchar(255) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `do_not_call` tinyint(1) DEFAULT 0,
  `phone_home` varchar(100) DEFAULT NULL,
  `phone_mobile` varchar(100) DEFAULT NULL,
  `phone_work` varchar(100) DEFAULT NULL,
  `phone_other` varchar(100) DEFAULT NULL,
  `phone_fax` varchar(100) DEFAULT NULL,
  `lawful_basis` text DEFAULT NULL,
  `date_reviewed` date DEFAULT NULL,
  `lawful_basis_source` varchar(100) DEFAULT NULL,
  `primary_address_street` varchar(150) DEFAULT NULL,
  `primary_address_city` varchar(100) DEFAULT NULL,
  `primary_address_state` varchar(100) DEFAULT NULL,
  `primary_address_postalcode` varchar(20) DEFAULT NULL,
  `primary_address_country` varchar(255) DEFAULT NULL,
  `alt_address_street` varchar(150) DEFAULT NULL,
  `alt_address_city` varchar(100) DEFAULT NULL,
  `alt_address_state` varchar(100) DEFAULT NULL,
  `alt_address_postalcode` varchar(20) DEFAULT NULL,
  `alt_address_country` varchar(255) DEFAULT NULL,
  `assistant` varchar(75) DEFAULT NULL,
  `assistant_phone` varchar(100) DEFAULT NULL,
  `converted` tinyint(1) DEFAULT 0,
  `refered_by` varchar(100) DEFAULT NULL,
  `lead_source` varchar(100) DEFAULT NULL,
  `lead_source_description` text DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `status_description` text DEFAULT NULL,
  `reports_to_id` char(36) DEFAULT NULL,
  `account_name` varchar(255) DEFAULT NULL,
  `account_description` text DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `account_id` char(36) DEFAULT NULL,
  `opportunity_id` char(36) DEFAULT NULL,
  `opportunity_name` varchar(255) DEFAULT NULL,
  `opportunity_amount` varchar(50) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `portal_name` varchar(255) DEFAULT NULL,
  `portal_app` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lead_acct_name_first` (`account_name`,`deleted`),
  KEY `idx_lead_last_first` (`last_name`,`first_name`,`deleted`),
  KEY `idx_lead_del_stat` (`last_name`,`status`,`deleted`,`first_name`),
  KEY `idx_lead_opp_del` (`opportunity_id`,`deleted`),
  KEY `idx_leads_acct_del` (`account_id`,`deleted`),
  KEY `idx_del_user` (`deleted`,`assigned_user_id`),
  KEY `idx_lead_assigned` (`assigned_user_id`),
  KEY `idx_lead_contact` (`contact_id`),
  KEY `idx_reports_to` (`reports_to_id`),
  KEY `idx_lead_phone_work` (`phone_work`),
  KEY `idx_leads_id_del` (`id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leads`
--

LOCK TABLES `leads` WRITE;
/*!40000 ALTER TABLE `leads` DISABLE KEYS */;
/*!40000 ALTER TABLE `leads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leads_audit`
--

DROP TABLE IF EXISTS `leads_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leads_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_leads_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leads_audit`
--

LOCK TABLES `leads_audit` WRITE;
/*!40000 ALTER TABLE `leads_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `leads_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leads_cstm`
--

DROP TABLE IF EXISTS `leads_cstm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leads_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT 0.00000000,
  `jjwg_maps_lat_c` float(10,8) DEFAULT 0.00000000,
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leads_cstm`
--

LOCK TABLES `leads_cstm` WRITE;
/*!40000 ALTER TABLE `leads_cstm` DISABLE KEYS */;
/*!40000 ALTER TABLE `leads_cstm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `linked_documents`
--

DROP TABLE IF EXISTS `linked_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `linked_documents` (
  `id` varchar(36) NOT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  `parent_type` varchar(25) DEFAULT NULL,
  `document_id` varchar(36) DEFAULT NULL,
  `document_revision_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_parent_document` (`parent_type`,`parent_id`,`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linked_documents`
--

LOCK TABLES `linked_documents` WRITE;
/*!40000 ALTER TABLE `linked_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `linked_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manual_migration_tasks`
--

DROP TABLE IF EXISTS `manual_migration_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `manual_migration_tasks` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `data` longtext DEFAULT NULL,
  `progress` text DEFAULT NULL,
  `phase` varchar(50) DEFAULT NULL,
  `service_key` varchar(255) DEFAULT NULL,
  `last_run_datetime` datetime DEFAULT NULL,
  `allow_failure_retry_action` tinyint(1) DEFAULT NULL,
  `allow_failure_rerun_action` tinyint(1) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manual_migration_tasks`
--

LOCK TABLES `manual_migration_tasks` WRITE;
/*!40000 ALTER TABLE `manual_migration_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `manual_migration_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meetings`
--

DROP TABLE IF EXISTS `meetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meetings` (
  `id` char(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `join_url` varchar(200) DEFAULT NULL,
  `host_url` varchar(400) DEFAULT NULL,
  `displayed_url` varchar(400) DEFAULT NULL,
  `creator` varchar(50) DEFAULT NULL,
  `external_id` varchar(50) DEFAULT NULL,
  `duration_hours` int(3) DEFAULT NULL,
  `duration_minutes` int(2) DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Planned',
  `type` varchar(255) DEFAULT 'Sugar',
  `parent_id` char(36) DEFAULT NULL,
  `reminder_time` int(11) DEFAULT -1,
  `email_reminder_time` int(11) DEFAULT -1,
  `email_reminder_sent` tinyint(1) DEFAULT 0,
  `outlook_id` varchar(255) DEFAULT NULL,
  `sequence` int(11) DEFAULT 0,
  `repeat_type` varchar(36) DEFAULT NULL,
  `repeat_interval` int(3) DEFAULT 1,
  `repeat_dow` varchar(7) DEFAULT NULL,
  `repeat_until` date DEFAULT NULL,
  `repeat_count` int(7) DEFAULT NULL,
  `repeat_parent_id` char(36) DEFAULT NULL,
  `recurring_source` varchar(36) DEFAULT NULL,
  `gsync_id` varchar(1024) DEFAULT NULL,
  `gsync_lastsync` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mtg_name` (`name`),
  KEY `idx_meet_par_del` (`parent_id`,`parent_type`,`deleted`),
  KEY `idx_meet_stat_del` (`assigned_user_id`,`status`,`deleted`),
  KEY `idx_meet_date_start` (`date_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meetings`
--

LOCK TABLES `meetings` WRITE;
/*!40000 ALTER TABLE `meetings` DISABLE KEYS */;
/*!40000 ALTER TABLE `meetings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meetings_contacts`
--

DROP TABLE IF EXISTS `meetings_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meetings_contacts` (
  `id` varchar(36) NOT NULL,
  `meeting_id` varchar(36) DEFAULT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_con_mtg_mtg` (`meeting_id`),
  KEY `idx_con_mtg_con` (`contact_id`),
  KEY `idx_meeting_contact` (`meeting_id`,`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meetings_contacts`
--

LOCK TABLES `meetings_contacts` WRITE;
/*!40000 ALTER TABLE `meetings_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `meetings_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meetings_cstm`
--

DROP TABLE IF EXISTS `meetings_cstm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meetings_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT 0.00000000,
  `jjwg_maps_lat_c` float(10,8) DEFAULT 0.00000000,
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meetings_cstm`
--

LOCK TABLES `meetings_cstm` WRITE;
/*!40000 ALTER TABLE `meetings_cstm` DISABLE KEYS */;
/*!40000 ALTER TABLE `meetings_cstm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meetings_leads`
--

DROP TABLE IF EXISTS `meetings_leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meetings_leads` (
  `id` varchar(36) NOT NULL,
  `meeting_id` varchar(36) DEFAULT NULL,
  `lead_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_lead_meeting_meeting` (`meeting_id`),
  KEY `idx_lead_meeting_lead` (`lead_id`),
  KEY `idx_meeting_lead` (`meeting_id`,`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meetings_leads`
--

LOCK TABLES `meetings_leads` WRITE;
/*!40000 ALTER TABLE `meetings_leads` DISABLE KEYS */;
/*!40000 ALTER TABLE `meetings_leads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meetings_users`
--

DROP TABLE IF EXISTS `meetings_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meetings_users` (
  `id` varchar(36) NOT NULL,
  `meeting_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_usr_mtg_mtg` (`meeting_id`),
  KEY `idx_usr_mtg_usr` (`user_id`),
  KEY `idx_meeting_users` (`meeting_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meetings_users`
--

LOCK TABLES `meetings_users` WRITE;
/*!40000 ALTER TABLE `meetings_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `meetings_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messenger_messages`
--

DROP TABLE IF EXISTS `messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `messenger_messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_msg_queue_available_delivered` (`queue_name`,`available_at`,`delivered_at`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messenger_messages`
--

LOCK TABLES `messenger_messages` WRITE;
/*!40000 ALTER TABLE `messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `assigned_user_id` char(36) DEFAULT NULL,
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `file_mime_type` varchar(100) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `parent_type` varchar(255) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `portal_flag` tinyint(1) DEFAULT NULL,
  `embed_flag` tinyint(1) DEFAULT 0,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_note_name` (`name`),
  KEY `idx_notes_parent` (`parent_id`,`parent_type`),
  KEY `idx_note_contact` (`contact_id`),
  KEY `idx_notes_assigned_del` (`deleted`,`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth2authcodes`
--

DROP TABLE IF EXISTS `oauth2authcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth2authcodes` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `auth_code_is_revoked` tinyint(1) DEFAULT NULL,
  `auto_authorize` tinyint(1) DEFAULT NULL,
  `auth_code_expires` datetime DEFAULT NULL,
  `auth_code` varchar(4000) DEFAULT NULL,
  `client` char(36) DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth2authcodes`
--

LOCK TABLES `oauth2authcodes` WRITE;
/*!40000 ALTER TABLE `oauth2authcodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth2authcodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth2clients`
--

DROP TABLE IF EXISTS `oauth2clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth2clients` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `secret` varchar(4000) DEFAULT NULL,
  `redirect_url` varchar(255) DEFAULT NULL,
  `is_confidential` tinyint(1) DEFAULT 1,
  `allowed_grant_type` varchar(255) DEFAULT 'password',
  `duration_value` int(11) DEFAULT NULL,
  `duration_amount` int(11) DEFAULT NULL,
  `duration_unit` varchar(255) DEFAULT 'Duration Unit',
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth2clients`
--

LOCK TABLES `oauth2clients` WRITE;
/*!40000 ALTER TABLE `oauth2clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth2clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth2tokens`
--

DROP TABLE IF EXISTS `oauth2tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth2tokens` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `token_is_revoked` tinyint(1) DEFAULT NULL,
  `token_type` varchar(255) DEFAULT NULL,
  `access_token_expires` datetime DEFAULT NULL,
  `access_token` varchar(4000) DEFAULT NULL,
  `refresh_token` varchar(4000) DEFAULT NULL,
  `refresh_token_expires` datetime DEFAULT NULL,
  `grant_type` varchar(255) DEFAULT NULL,
  `state` varchar(1024) DEFAULT NULL,
  `client` char(36) DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth2tokens`
--

LOCK TABLES `oauth2tokens` WRITE;
/*!40000 ALTER TABLE `oauth2tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth2tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_consumer`
--

DROP TABLE IF EXISTS `oauth_consumer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_consumer` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `c_key` varchar(255) DEFAULT NULL,
  `c_secret` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ckey` (`c_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_consumer`
--

LOCK TABLES `oauth_consumer` WRITE;
/*!40000 ALTER TABLE `oauth_consumer` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_consumer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_nonce`
--

DROP TABLE IF EXISTS `oauth_nonce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_nonce` (
  `conskey` varchar(32) NOT NULL,
  `nonce` varchar(32) NOT NULL,
  `nonce_ts` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`conskey`,`nonce`),
  KEY `oauth_nonce_keyts` (`conskey`,`nonce_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_nonce`
--

LOCK TABLES `oauth_nonce` WRITE;
/*!40000 ALTER TABLE `oauth_nonce` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_nonce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_tokens`
--

DROP TABLE IF EXISTS `oauth_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_tokens` (
  `id` char(36) NOT NULL,
  `secret` varchar(32) DEFAULT NULL,
  `tstate` varchar(1) DEFAULT NULL,
  `consumer` char(36) NOT NULL,
  `token_ts` bigint(20) DEFAULT NULL,
  `verify` varchar(32) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `callback_url` varchar(255) DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`,`deleted`),
  KEY `oauth_state_ts` (`tstate`,`token_ts`),
  KEY `constoken_key` (`consumer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_tokens`
--

LOCK TABLES `oauth_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opportunities`
--

DROP TABLE IF EXISTS `opportunities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `opportunities` (
  `id` char(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `opportunity_type` varchar(255) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `lead_source` varchar(50) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `amount_usdollar` double DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `date_closed` date DEFAULT NULL,
  `next_step` varchar(100) DEFAULT NULL,
  `sales_stage` varchar(255) DEFAULT NULL,
  `probability` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_opp_name` (`name`),
  KEY `idx_opp_assigned` (`assigned_user_id`),
  KEY `idx_opp_id_deleted` (`id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opportunities`
--

LOCK TABLES `opportunities` WRITE;
/*!40000 ALTER TABLE `opportunities` DISABLE KEYS */;
/*!40000 ALTER TABLE `opportunities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opportunities_audit`
--

DROP TABLE IF EXISTS `opportunities_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `opportunities_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_opportunities_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opportunities_audit`
--

LOCK TABLES `opportunities_audit` WRITE;
/*!40000 ALTER TABLE `opportunities_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `opportunities_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opportunities_contacts`
--

DROP TABLE IF EXISTS `opportunities_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `opportunities_contacts` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `opportunity_id` varchar(36) DEFAULT NULL,
  `contact_role` varchar(50) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_con_opp_con` (`contact_id`),
  KEY `idx_con_opp_opp` (`opportunity_id`),
  KEY `idx_opportunities_contacts` (`opportunity_id`,`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opportunities_contacts`
--

LOCK TABLES `opportunities_contacts` WRITE;
/*!40000 ALTER TABLE `opportunities_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `opportunities_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opportunities_cstm`
--

DROP TABLE IF EXISTS `opportunities_cstm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `opportunities_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT 0.00000000,
  `jjwg_maps_lat_c` float(10,8) DEFAULT 0.00000000,
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opportunities_cstm`
--

LOCK TABLES `opportunities_cstm` WRITE;
/*!40000 ALTER TABLE `opportunities_cstm` DISABLE KEYS */;
/*!40000 ALTER TABLE `opportunities_cstm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `outbound_email`
--

DROP TABLE IF EXISTS `outbound_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `outbound_email` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(15) DEFAULT 'user',
  `user_id` char(36) DEFAULT NULL,
  `is_personal` tinyint(1) DEFAULT 0,
  `smtp_from_name` varchar(255) DEFAULT NULL,
  `smtp_from_addr` varchar(255) DEFAULT NULL,
  `reply_to_name` varchar(255) DEFAULT NULL,
  `reply_to_addr` varchar(255) DEFAULT NULL,
  `signature` text DEFAULT NULL,
  `mail_sendtype` varchar(8) DEFAULT 'SMTP',
  `mail_smtptype` varchar(20) DEFAULT 'other',
  `mail_smtpserver` varchar(100) DEFAULT NULL,
  `mail_smtpport` varchar(5) DEFAULT '25',
  `mail_smtpuser` varchar(100) DEFAULT NULL,
  `mail_smtppass` varchar(100) DEFAULT NULL,
  `mail_smtpauth_req` tinyint(1) DEFAULT 0,
  `mail_smtpssl` varchar(1) DEFAULT '0',
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `auth_type` varchar(255) DEFAULT 'no_auth',
  `external_oauth_connection_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `outbound_email`
--

LOCK TABLES `outbound_email` WRITE;
/*!40000 ALTER TABLE `outbound_email` DISABLE KEYS */;
INSERT INTO `outbound_email` VALUES
('1209a782-5a8d-405c-98a5-b8aa3133d845','system','system','1',0,NULL,NULL,NULL,NULL,NULL,'SMTP','other','','25','','',1,'0',NULL,NULL,NULL,NULL,0,NULL,'no_auth',NULL);
/*!40000 ALTER TABLE `outbound_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `outbound_email_audit`
--

DROP TABLE IF EXISTS `outbound_email_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `outbound_email_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_outbound_email_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `outbound_email_audit`
--

LOCK TABLES `outbound_email_audit` WRITE;
/*!40000 ALTER TABLE `outbound_email_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `outbound_email_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `private_documents_media_objects`
--

DROP TABLE IF EXISTS `private_documents_media_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `private_documents_media_objects` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `dimensions` varchar(50) DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `parent_field` varchar(100) DEFAULT NULL,
  `temporary` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `private_documents_media_objects`
--

LOCK TABLES `private_documents_media_objects` WRITE;
/*!40000 ALTER TABLE `private_documents_media_objects` DISABLE KEYS */;
INSERT INTO `private_documents_media_objects` VALUES
('0f4312e3-af55-4c87-9fc8-f4616abfa2cf','Broadcast_Master_Spot.wav','2026-10-20 17:01:01','2026-10-20 17:01:01',NULL,NULL,NULL,0,NULL,'e7d8646c-c596-49b2-9ef2-a68619cc4273',44,'audio/wav','Broadcast_Master_Spot.wav',NULL,'RT_RadioCampaigns','da6080ff-2e01-4938-8dce-e0ab7a3f3cee','file',0),
('1f1cb25d-417f-6616-a4d5-e3a8c93878b7','Quotes_test.pdf','2026-10-18 20:57:55','2026-10-18 20:57:55','1','1',NULL,0,'1','01a15060-ae34-7f90-a447-d89448e40ed4',83174,'application/pdf','Quotes_test.pdf',NULL,'Notes','48264456-f4fa-4580-952e-e28bda2f7a70','file',0),
('1f1cb274-eaae-61ee-bcb3-7f37588a65ab','Quotes_Test.pdf','2026-10-18 21:08:30','2026-10-18 21:08:30','1','1',NULL,0,'1','01a1506a-5e17-7261-bfe9-cc4b0ee1e4c0',81017,'application/pdf','Quotes_Test.pdf',NULL,'Notes','7c56e5aa-005f-4cb8-b68f-94094033b6d8','file',0),
('1f1cb288-eeaa-625c-9939-f90bb6f4aeda','Quotes_test.pdf','2026-10-18 21:17:28','2026-10-18 21:17:28','1','1',NULL,0,'1','01a15072-91ef-7afe-83aa-fc89ba939482',83564,'application/pdf','Quotes_test.pdf',NULL,'Notes','b8ec0436-f76c-46fa-9cc4-289faa43fcf2','file',0),
('1f1cb28d-824e-62f2-b720-5f67fc0458d9','Quotes_test.pdf','2026-10-18 21:19:30','2026-10-18 21:19:30','1','1',NULL,0,'1','01a15074-718a-7ed8-8a34-6936528fb107',156033,'application/pdf','Quotes_test.pdf',NULL,'Notes','1ab0d7c2-d278-4a7c-bd45-5c3513d593fd','file',0),
('1f1cb28e-78af-6ea2-98a1-2d291c4112f1','Quotes_test.pdf','2026-10-18 21:19:56','2026-10-18 21:19:56','1','1',NULL,0,'1','01a15074-d6da-76f1-9160-ad9d288c7cfb',155082,'application/pdf','Quotes_test.pdf',NULL,'Notes','27ef8bf0-3943-4a33-9fb3-02f2caad1aa8','file',0),
('1f1cb299-mp30-6000-9000-0b46639f53b6','PUKfm_Promo_Spot.mp3','2026-10-18 19:57:51','2026-10-18 19:57:51',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-0b46639f53b6',164,'audio/mpeg','PUKfm_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','be729a14-30fd-484f-a3e6-6e44550aebc2','file',0),
('1f1cb299-mp30-6000-9000-219a2ae64178','Radio_Promo_Spot.mp3','2026-10-19 16:41:41','2026-10-19 16:41:41',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-219a2ae64178',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','e8fb6551-d372-4ec0-a4a7-4fd27defa5cd','file',0),
('1f1cb299-mp30-6000-9000-25b4a498833b','Radio_Promo_Spot.mp3','2026-10-19 16:23:49','2026-10-19 16:23:49',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-25b4a498833b',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','5349fcfb-2dc4-4dd0-8edf-f1b26ca41723','file',0),
('1f1cb299-mp30-6000-9000-31949a5e430a','Radio_Promo_Spot.mp3','2026-10-19 18:05:55','2026-10-19 18:05:55',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-31949a5e430a',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','58feadd3-6421-42f4-b67b-7bf5a3b27910','file',0),
('1f1cb299-mp30-6000-9000-3d1eca6617aa','PUKfm_Promo_Spot.mp3','2026-10-19 13:12:57','2026-10-19 13:12:57',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-3d1eca6617aa',164,'audio/mpeg','PUKfm_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','37624a42-0f30-4d7e-8d6f-eaa644fd9842','file',0),
('1f1cb299-mp30-6000-9000-417550e32032','Radio_Promo_Spot.mp3','2026-10-19 17:26:10','2026-10-19 17:26:10',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-417550e32032',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','9e4266ef-0101-4f0a-acf7-0c6c27c8ba22','file',0),
('1f1cb299-mp30-6000-9000-69366832f504','PUKfm_Promo_Spot.mp3','2026-10-19 14:26:04','2026-10-19 14:26:04',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-69366832f504',164,'audio/mpeg','PUKfm_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','9135a3fa-c2ae-499a-abe1-3f3267a83032','file',0),
('1f1cb299-mp30-6000-9000-6c341eae363d','Radio_Promo_Spot.mp3','2026-10-19 20:53:32','2026-10-19 20:53:32',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-6c341eae363d',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','e61f0629-09a3-46d8-9a63-e068b78cd9a1','file',0),
('1f1cb299-mp30-6000-9000-70165c6c81cc','Radio_Promo_Spot.mp3','2026-10-20 20:39:02','2026-10-20 20:39:03',NULL,NULL,NULL,1,NULL,'01a15099-mp30-7000-8000-70165c6c81cc',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','27b6afc7-f088-473e-b392-d49659d6f7e2','file',0),
('1f1cb299-mp30-6000-9000-71f51b97ec04','Radio_Promo_Spot.mp3','2026-10-19 16:19:56','2026-10-19 16:19:56',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-71f51b97ec04',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','e6421c95-bc4b-452f-b981-83c5ebda3e03','file',0),
('1f1cb299-mp30-6000-9000-773179048070','Radio_Promo_Spot.mp3','2026-10-20 16:47:13','2026-10-20 16:47:13',NULL,NULL,NULL,1,NULL,'01a15099-mp30-7000-8000-773179048070',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','c9687304-da9f-4486-b2c8-4fc682a94978','file',0),
('1f1cb299-mp30-6000-9000-848c75c3a113','Radio_Promo_Spot.mp3','2026-10-20 21:01:29','2026-10-20 21:01:29',NULL,NULL,NULL,1,NULL,'01a15099-mp30-7000-8000-848c75c3a113',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','cc611a06-02bf-4bfd-baf3-a6452501376a','file',0),
('1f1cb299-mp30-6000-9000-853d592ccec1','PUKfm_Promo_Spot.mp3','2026-10-19 14:17:17','2026-10-19 14:17:17',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-853d592ccec1',164,'audio/mpeg','PUKfm_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','67ab30c2-2b46-4dfc-9ef3-f4652ee5d75a','file',0),
('1f1cb299-mp30-6000-9000-85c3dd6fba4d','Radio_Promo_Spot.mp3','2026-10-20 20:32:13','2026-10-20 20:32:14',NULL,NULL,NULL,1,NULL,'01a15099-mp30-7000-8000-85c3dd6fba4d',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','8280d8a2-5bf0-48f7-9a76-9036c57e10d0','file',0),
('1f1cb299-mp30-6000-9000-873612bca932','Radio_Promo_Spot.mp3','2026-10-19 15:40:10','2026-10-19 15:40:10',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-873612bca932',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','0b409ee3-c6a3-43a0-ad36-d15f91f0cb9f','file',0),
('1f1cb299-mp30-6000-9000-875ddb9787ac','PUKfm_Promo_Spot.mp3','2026-10-19 13:23:01','2026-10-19 13:23:01',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-875ddb9787ac',164,'audio/mpeg','PUKfm_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','1f009905-cc26-4284-af98-f17d7e6dd390','file',0),
('1f1cb299-mp30-6000-9000-907cf87aa457','Radio_Promo_Spot.mp3','2026-10-19 16:18:58','2026-10-19 16:18:58',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-907cf87aa457',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','199cf60b-60f1-4440-a406-5b561a2149cc','file',0),
('1f1cb299-mp30-6000-9000-927e449fd52a','PUKfm_Promo_Spot.mp3','2026-10-19 14:18:28','2026-10-19 14:18:28',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-927e449fd52a',164,'audio/mpeg','PUKfm_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','3e849eb1-207a-4c55-bedd-9e286723cbfe','file',0),
('1f1cb299-mp30-6000-9000-95c27e7e12a8','Radio_Promo_Spot.mp3','2026-10-19 19:58:35','2026-10-19 19:58:35',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-95c27e7e12a8',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','291891bd-3992-4618-858d-15ff5ee023ce','file',0),
('1f1cb299-mp30-6000-9000-a06eb5477ba3','Radio_Promo_Spot.mp3','2026-10-19 18:25:45','2026-10-19 18:25:45',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-a06eb5477ba3',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','c81281d8-b797-4174-9339-dfe73d9cf6c9','file',0),
('1f1cb299-mp30-6000-9000-aac0d75b20d9','Radio_Promo_Spot.mp3','2026-10-20 16:48:18','2026-10-20 16:48:19',NULL,NULL,NULL,1,NULL,'01a15099-mp30-7000-8000-aac0d75b20d9',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','e9a546c1-e25f-44e1-bdd3-ecd092c262aa','file',0),
('1f1cb299-mp30-6000-9000-ab2c401da379','Radio_Promo_Spot.mp3','2026-10-20 17:40:39','2026-10-20 17:40:39',NULL,NULL,NULL,1,NULL,'01a15099-mp30-7000-8000-ab2c401da379',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','dccdee0d-066c-4a1c-b147-ab086ccb5d3f','file',0),
('1f1cb299-mp30-6000-9000-b1fe5773e790','Radio_Promo_Spot.mp3','2026-10-19 15:58:22','2026-10-19 15:58:22',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-b1fe5773e790',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','5a5cc959-c9eb-4662-8291-09747a9b1b05','file',0),
('1f1cb299-mp30-6000-9000-b320071a60f3','Radio_Promo_Spot.mp3','2026-10-19 19:26:13','2026-10-19 19:26:13',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-b320071a60f3',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','2387f30e-33e2-4734-9c59-0e636454a474','file',0),
('1f1cb299-mp30-6000-9000-b458661dfade','PUKfm_Promo_Spot.mp3','2026-10-19 14:57:59','2026-10-19 14:57:59',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-b458661dfade',164,'audio/mpeg','PUKfm_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','8c73c22d-4397-4a24-8844-e6abd7f872ab','file',0),
('1f1cb299-mp30-6000-9000-b9828baf34b9','Radio_Promo_Spot.mp3','2026-10-19 17:29:32','2026-10-19 17:29:32',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-b9828baf34b9',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','934c06f6-9aff-44d5-bd77-3abeda3009f2','file',0),
('1f1cb299-mp30-6000-9000-c0c0b5ddf449','PUKfm_Promo_Spot.mp3','2026-10-19 13:12:06','2026-10-19 13:12:06',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-c0c0b5ddf449',164,'audio/mpeg','PUKfm_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','3ec77cfc-1675-45d8-ac49-5bb7d04daefb','file',0),
('1f1cb299-mp30-6000-9000-da19edb16e94','Radio_Promo_Spot.mp3','2026-10-19 19:35:54','2026-10-19 19:35:54',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-da19edb16e94',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','12e855c7-aae7-42be-9a5f-69058fecd6e1','file',0),
('1f1cb299-mp30-6000-9000-e8c1b7790e5c','PUKfm_Promo_Spot.mp3','2026-10-19 12:21:49','2026-10-19 12:21:49',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-e8c1b7790e5c',164,'audio/mpeg','PUKfm_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','b883226c-eaff-4c05-b017-21a74ad23577','file',0),
('1f1cb299-mp30-6000-9000-f0a84ae4a3ee','Radio_Promo_Spot.mp3','2026-10-19 18:45:20','2026-10-19 18:45:20',NULL,NULL,NULL,0,NULL,'01a15099-mp30-7000-8000-f0a84ae4a3ee',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','586ca57e-b02c-455a-99ac-25240b9c9a48','file',0),
('1f1cb299-mp30-6000-9000-f8d62bf7a7e5','Radio_Promo_Spot.mp3','2026-10-20 17:01:01','2026-10-20 17:01:01',NULL,NULL,NULL,1,NULL,'01a15099-mp30-7000-8000-f8d62bf7a7e5',164,'audio/mpeg','Radio_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','da6080ff-2e01-4938-8dce-e0ab7a3f3cee','file',0),
('1f1cb2a0-1c5b-666c-978a-03888ee840fa','Quotes_Test.pdf','2026-10-18 21:27:50','2026-10-18 21:27:50','1','1',NULL,0,'1','01a1507c-104c-7296-8a1a-36f400f98284',154274,'application/pdf','Quotes_Test.pdf',NULL,'Notes','4005f952-664c-45f2-a27c-cb98cc203051','file',0),
('1f1cb2a2-53a6-6322-b5b8-851918ee7f76','Quotes_Test.pdf','2026-10-18 21:28:49','2026-10-18 21:28:49','1','1',NULL,1,'1','01a1507c-f8db-78a6-9018-7a75bd79c942',154274,'application/pdf','Quotes_Test.pdf',NULL,'Emails','c0d7a2dd-85ef-464d-bf19-e9a7f0e89a21','email_attachments',0),
('1f1cb2f5-49f4-6916-b654-7530d5168fe7','Quotes_Test_Radio_Advert_Quote.pdf','2026-10-18 22:05:56','2026-10-18 22:05:56','1','1',NULL,0,'1','01a1509e-f40a-7641-b8b5-f108520a1190',153763,'application/pdf','Quotes_Test_Radio_Advert_Quote.pdf',NULL,'Notes','d4c9d0c7-c692-42ee-942f-a0b8b171981a','file',0),
('1f1cbc1a-f99e-6e42-a1cc-49a90200c26b','Quotes_test.pdf','2026-10-19 15:33:35','2026-10-19 15:33:35','1','1',NULL,0,'1','01a1545e-1a29-7400-b4ea-f80c5607dda4',153760,'application/pdf','Quotes_test.pdf',NULL,'Notes','cd51280e-2963-4cb5-a832-e93a99a460ca','file',0),
('1f1cc98b-a797-6b66-ab98-2b67dc2bd304','Quotes_Hello_Sushi.pdf','2026-10-20 17:12:55','2026-10-20 17:12:55','1','1',NULL,0,'1','01a159df-68f8-7f2e-88d6-034c47e80d72',155437,'application/pdf','Quotes_Hello_Sushi.pdf',NULL,'Notes','70c78ac3-c065-42eb-a912-d97fb61857ec','file',0),
('366b5b97-1cb9-4c52-aefe-82f82647fb5e','Broadcast_Master_Spot.wav','2026-10-20 16:47:13','2026-10-20 16:47:13',NULL,NULL,NULL,0,NULL,'bb82e0da-9774-4f47-901f-f74060d192d3',44,'audio/wav','Broadcast_Master_Spot.wav',NULL,'RT_RadioCampaigns','c9687304-da9f-4486-b2c8-4fc682a94978','file',0),
('600c56ff-5c70-4812-8ab7-d7fdce1865be','Broadcast_Master_Spot.wav','2026-10-20 17:40:39','2026-10-20 17:40:39',NULL,NULL,NULL,0,NULL,'25b15892-b981-4d94-b9ee-373bb0f23bec',44,'audio/wav','Broadcast_Master_Spot.wav',NULL,'RT_RadioCampaigns','dccdee0d-066c-4a1c-b147-ab086ccb5d3f','file',0),
('623c7938-43ef-4b6e-a031-777d411ad446','Broadcast_Master_Spot.wav','2026-10-20 20:32:14','2026-10-20 20:32:14',NULL,NULL,NULL,0,NULL,'afbca988-82f3-4faa-b2e5-766acfcc0db5',44,'audio/wav','Broadcast_Master_Spot.wav',NULL,'RT_RadioCampaigns','8280d8a2-5bf0-48f7-9a76-9036c57e10d0','file',0),
('6d7188e4-4c95-4d94-a92a-35db4b14016b','PUKfm_Promo_Spot.mp3','2026-10-20 16:06:49','2026-10-20 16:07:39',NULL,NULL,NULL,1,NULL,'ce24a4d1-d8dc-4a6b-b999-8bf402450127',154,'audio/mpeg','PUKfm_Promo_Spot.mp3',NULL,'RT_RadioCampaigns','77d498e1-fbf6-4484-9e4b-f10746e382e6','file',0),
('85589767-a649-4746-9ea3-a4d6e33ffdcb','Broadcast_Master_Spot.wav','2026-10-20 20:31:18','2026-10-20 20:32:14',NULL,NULL,NULL,1,NULL,'72471cf4-18e2-40d7-9b7f-eaca8894a8df',44,'audio/wav','Broadcast_Master_Spot.wav',NULL,'RT_RadioCampaigns','8280d8a2-5bf0-48f7-9a76-9036c57e10d0','file',0),
('9a44194a-7fd0-401b-bce3-5fdcfd35f886','Broadcast_Master_Spot.wav','2026-10-20 15:58:56','2026-10-20 16:47:13',NULL,NULL,NULL,1,NULL,'5ded23ac-0259-4d04-898f-972f8a43c229',44,'audio/wav','Broadcast_Master_Spot.wav',NULL,'RT_RadioCampaigns','c9687304-da9f-4486-b2c8-4fc682a94978','file',0),
('9a561927-3dfd-4d79-9f88-d936c63709e5','Broadcast_Master_Spot.wav','2026-10-20 20:39:03','2026-10-20 20:39:03',NULL,NULL,NULL,0,NULL,'8af11839-8ab1-4e00-aa46-bc074df48cba',44,'audio/wav','Broadcast_Master_Spot.wav',NULL,'RT_RadioCampaigns','27b6afc7-f088-473e-b392-d49659d6f7e2','file',0),
('efdf37fc-3af8-4897-9c62-52cd751866f8','Broadcast_Master_Spot.wav','2026-10-20 21:01:29','2026-10-20 21:01:29',NULL,NULL,NULL,0,NULL,'7be36219-76f2-4f9e-9ac5-5d28accd5f78',44,'audio/wav','Broadcast_Master_Spot.wav',NULL,'RT_RadioCampaigns','cc611a06-02bf-4bfd-baf3-a6452501376a','file',0),
('fc9afa75-531f-48d5-9a4b-843f3bd03bd1','rec_20260803-210000.mp3','2026-10-20 16:09:29','2026-10-20 16:09:29',NULL,NULL,NULL,0,NULL,'43ad2121-16b1-4374-a69f-5d42f3531bc3',57606749,'audio/mpeg','rec_20260803-210000.mp3',NULL,'RT_RadioCampaigns','77d498e1-fbf6-4484-9e4b-f10746e382e6','file',0),
('fdc9cf37-86da-48c1-934d-54ccc1e7c3c2','Broadcast_Master_Spot.wav','2026-10-20 16:48:19','2026-10-20 16:48:19',NULL,NULL,NULL,0,NULL,'c3f0221e-0d07-4595-aa2f-c26e11fa8460',44,'audio/wav','Broadcast_Master_Spot.wav',NULL,'RT_RadioCampaigns','e9a546c1-e25f-44e1-bdd3-ecd092c262aa','file',0);
/*!40000 ALTER TABLE `private_documents_media_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `private_images_media_objects`
--

DROP TABLE IF EXISTS `private_images_media_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `private_images_media_objects` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `dimensions` varchar(50) DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `parent_field` varchar(100) DEFAULT NULL,
  `temporary` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `private_images_media_objects`
--

LOCK TABLES `private_images_media_objects` WRITE;
/*!40000 ALTER TABLE `private_images_media_objects` DISABLE KEYS */;
/*!40000 ALTER TABLE `private_images_media_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `processes`
--

DROP TABLE IF EXISTS `processes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `processes` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `data` longtext DEFAULT NULL,
  `progress` text DEFAULT NULL,
  `phase` varchar(50) DEFAULT NULL,
  `service_key` varchar(255) DEFAULT NULL,
  `last_run_datetime` datetime DEFAULT NULL,
  `allow_failure_retry_action` tinyint(1) DEFAULT NULL,
  `allow_failure_rerun_action` tinyint(1) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `processes`
--

LOCK TABLES `processes` WRITE;
/*!40000 ALTER TABLE `processes` DISABLE KEYS */;
/*!40000 ALTER TABLE `processes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `estimated_start_date` date DEFAULT NULL,
  `estimated_end_date` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `override_business_hours` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_contacts_1_c`
--

DROP TABLE IF EXISTS `project_contacts_1_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_contacts_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `project_contacts_1project_ida` varchar(36) DEFAULT NULL,
  `project_contacts_1contacts_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_contacts_1_alt` (`project_contacts_1project_ida`,`project_contacts_1contacts_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_contacts_1_c`
--

LOCK TABLES `project_contacts_1_c` WRITE;
/*!40000 ALTER TABLE `project_contacts_1_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_contacts_1_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_cstm`
--

DROP TABLE IF EXISTS `project_cstm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT 0.00000000,
  `jjwg_maps_lat_c` float(10,8) DEFAULT 0.00000000,
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_cstm`
--

LOCK TABLES `project_cstm` WRITE;
/*!40000 ALTER TABLE `project_cstm` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_cstm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_task`
--

DROP TABLE IF EXISTS `project_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_task` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `project_id` char(36) NOT NULL,
  `project_task_id` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `relationship_type` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `predecessors` text DEFAULT NULL,
  `date_start` date DEFAULT NULL,
  `time_start` int(11) DEFAULT NULL,
  `time_finish` int(11) DEFAULT NULL,
  `date_finish` date DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `duration_unit` text DEFAULT NULL,
  `actual_duration` int(11) DEFAULT NULL,
  `percent_complete` int(11) DEFAULT NULL,
  `date_due` date DEFAULT NULL,
  `time_due` time DEFAULT NULL,
  `parent_task_id` int(11) DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `milestone_flag` tinyint(1) DEFAULT NULL,
  `order_number` int(11) DEFAULT 1,
  `task_number` int(11) DEFAULT NULL,
  `estimated_effort` int(11) DEFAULT NULL,
  `actual_effort` int(11) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `utilization` int(11) DEFAULT 100,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_task`
--

LOCK TABLES `project_task` WRITE;
/*!40000 ALTER TABLE `project_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_task_audit`
--

DROP TABLE IF EXISTS `project_task_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_task_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_project_task_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_task_audit`
--

LOCK TABLES `project_task_audit` WRITE;
/*!40000 ALTER TABLE `project_task_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_task_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_users_1_c`
--

DROP TABLE IF EXISTS `project_users_1_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_users_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `project_users_1project_ida` varchar(36) DEFAULT NULL,
  `project_users_1users_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_users_1_alt` (`project_users_1project_ida`,`project_users_1users_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_users_1_c`
--

LOCK TABLES `project_users_1_c` WRITE;
/*!40000 ALTER TABLE `project_users_1_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_users_1_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects_accounts`
--

DROP TABLE IF EXISTS `projects_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects_accounts` (
  `id` varchar(36) NOT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_proj_acct_proj` (`project_id`),
  KEY `idx_proj_acct_acct` (`account_id`),
  KEY `projects_accounts_alt` (`project_id`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects_accounts`
--

LOCK TABLES `projects_accounts` WRITE;
/*!40000 ALTER TABLE `projects_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `projects_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects_bugs`
--

DROP TABLE IF EXISTS `projects_bugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects_bugs` (
  `id` varchar(36) NOT NULL,
  `bug_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_proj_bug_proj` (`project_id`),
  KEY `idx_proj_bug_bug` (`bug_id`),
  KEY `projects_bugs_alt` (`project_id`,`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects_bugs`
--

LOCK TABLES `projects_bugs` WRITE;
/*!40000 ALTER TABLE `projects_bugs` DISABLE KEYS */;
/*!40000 ALTER TABLE `projects_bugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects_cases`
--

DROP TABLE IF EXISTS `projects_cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects_cases` (
  `id` varchar(36) NOT NULL,
  `case_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_proj_case_proj` (`project_id`),
  KEY `idx_proj_case_case` (`case_id`),
  KEY `projects_cases_alt` (`project_id`,`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects_cases`
--

LOCK TABLES `projects_cases` WRITE;
/*!40000 ALTER TABLE `projects_cases` DISABLE KEYS */;
/*!40000 ALTER TABLE `projects_cases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects_contacts`
--

DROP TABLE IF EXISTS `projects_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects_contacts` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_proj_con_proj` (`project_id`),
  KEY `idx_proj_con_con` (`contact_id`),
  KEY `projects_contacts_alt` (`project_id`,`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects_contacts`
--

LOCK TABLES `projects_contacts` WRITE;
/*!40000 ALTER TABLE `projects_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `projects_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects_opportunities`
--

DROP TABLE IF EXISTS `projects_opportunities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects_opportunities` (
  `id` varchar(36) NOT NULL,
  `opportunity_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_proj_opp_proj` (`project_id`),
  KEY `idx_proj_opp_opp` (`opportunity_id`),
  KEY `projects_opportunities_alt` (`project_id`,`opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects_opportunities`
--

LOCK TABLES `projects_opportunities` WRITE;
/*!40000 ALTER TABLE `projects_opportunities` DISABLE KEYS */;
/*!40000 ALTER TABLE `projects_opportunities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects_products`
--

DROP TABLE IF EXISTS `projects_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects_products` (
  `id` varchar(36) NOT NULL,
  `product_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_proj_prod_project` (`project_id`),
  KEY `idx_proj_prod_product` (`product_id`),
  KEY `projects_products_alt` (`project_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects_products`
--

LOCK TABLES `projects_products` WRITE;
/*!40000 ALTER TABLE `projects_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `projects_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prospect_list_campaigns`
--

DROP TABLE IF EXISTS `prospect_list_campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_list_campaigns` (
  `id` varchar(36) NOT NULL,
  `prospect_list_id` varchar(36) DEFAULT NULL,
  `campaign_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_pro_id` (`prospect_list_id`),
  KEY `idx_cam_id` (`campaign_id`),
  KEY `idx_prospect_list_campaigns` (`prospect_list_id`,`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prospect_list_campaigns`
--

LOCK TABLES `prospect_list_campaigns` WRITE;
/*!40000 ALTER TABLE `prospect_list_campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `prospect_list_campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prospect_lists`
--

DROP TABLE IF EXISTS `prospect_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_lists` (
  `assigned_user_id` char(36) DEFAULT NULL,
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `list_type` varchar(100) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `domain_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_prospect_list_name` (`name`),
  KEY `idx_list_type` (`list_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prospect_lists`
--

LOCK TABLES `prospect_lists` WRITE;
/*!40000 ALTER TABLE `prospect_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `prospect_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prospect_lists_prospects`
--

DROP TABLE IF EXISTS `prospect_lists_prospects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_lists_prospects` (
  `id` varchar(36) NOT NULL,
  `prospect_list_id` varchar(36) DEFAULT NULL,
  `related_id` varchar(36) DEFAULT NULL,
  `related_type` varchar(25) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_plp_pro_id` (`prospect_list_id`,`deleted`),
  KEY `idx_plp_rel_id` (`related_id`,`related_type`,`prospect_list_id`),
  KEY `idx_related` (`related_id`,`related_type`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prospect_lists_prospects`
--

LOCK TABLES `prospect_lists_prospects` WRITE;
/*!40000 ALTER TABLE `prospect_lists_prospects` DISABLE KEYS */;
/*!40000 ALTER TABLE `prospect_lists_prospects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prospects`
--

DROP TABLE IF EXISTS `prospects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospects` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `salutation` varchar(255) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `do_not_call` tinyint(1) DEFAULT 0,
  `phone_home` varchar(100) DEFAULT NULL,
  `phone_mobile` varchar(100) DEFAULT NULL,
  `phone_work` varchar(100) DEFAULT NULL,
  `phone_other` varchar(100) DEFAULT NULL,
  `phone_fax` varchar(100) DEFAULT NULL,
  `lawful_basis` text DEFAULT NULL,
  `date_reviewed` date DEFAULT NULL,
  `lawful_basis_source` varchar(100) DEFAULT NULL,
  `primary_address_street` varchar(150) DEFAULT NULL,
  `primary_address_city` varchar(100) DEFAULT NULL,
  `primary_address_state` varchar(100) DEFAULT NULL,
  `primary_address_postalcode` varchar(20) DEFAULT NULL,
  `primary_address_country` varchar(255) DEFAULT NULL,
  `alt_address_street` varchar(150) DEFAULT NULL,
  `alt_address_city` varchar(100) DEFAULT NULL,
  `alt_address_state` varchar(100) DEFAULT NULL,
  `alt_address_postalcode` varchar(20) DEFAULT NULL,
  `alt_address_country` varchar(255) DEFAULT NULL,
  `assistant` varchar(75) DEFAULT NULL,
  `assistant_phone` varchar(100) DEFAULT NULL,
  `tracker_key` int(11) NOT NULL AUTO_INCREMENT,
  `birthdate` date DEFAULT NULL,
  `lead_id` char(36) DEFAULT NULL,
  `account_name` varchar(150) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prospect_auto_tracker_key` (`tracker_key`),
  KEY `idx_prospects_last_first` (`last_name`,`first_name`,`deleted`),
  KEY `idx_prospecs_del_last` (`last_name`,`deleted`),
  KEY `idx_prospects_id_del` (`id`,`deleted`),
  KEY `idx_prospects_assigned` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prospects`
--

LOCK TABLES `prospects` WRITE;
/*!40000 ALTER TABLE `prospects` DISABLE KEYS */;
/*!40000 ALTER TABLE `prospects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prospects_cstm`
--

DROP TABLE IF EXISTS `prospects_cstm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospects_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT 0.00000000,
  `jjwg_maps_lat_c` float(10,8) DEFAULT 0.00000000,
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prospects_cstm`
--

LOCK TABLES `prospects_cstm` WRITE;
/*!40000 ALTER TABLE `prospects_cstm` DISABLE KEYS */;
/*!40000 ALTER TABLE `prospects_cstm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `public_documents_media_objects`
--

DROP TABLE IF EXISTS `public_documents_media_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `public_documents_media_objects` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `dimensions` varchar(50) DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `parent_field` varchar(100) DEFAULT NULL,
  `temporary` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `public_documents_media_objects`
--

LOCK TABLES `public_documents_media_objects` WRITE;
/*!40000 ALTER TABLE `public_documents_media_objects` DISABLE KEYS */;
/*!40000 ALTER TABLE `public_documents_media_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `public_images_media_objects`
--

DROP TABLE IF EXISTS `public_images_media_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `public_images_media_objects` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `dimensions` varchar(50) DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `parent_field` varchar(100) DEFAULT NULL,
  `temporary` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `public_images_media_objects`
--

LOCK TABLES `public_images_media_objects` WRITE;
/*!40000 ALTER TABLE `public_images_media_objects` DISABLE KEYS */;
/*!40000 ALTER TABLE `public_images_media_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radio_station_settings`
--

DROP TABLE IF EXISTS `radio_station_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `radio_station_settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` longtext DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radio_station_settings`
--

LOCK TABLES `radio_station_settings` WRITE;
/*!40000 ALTER TABLE `radio_station_settings` DISABLE KEYS */;
INSERT INTO `radio_station_settings` VALUES
('cart_range_end','2999','2026-10-20 21:01:40'),
('cart_range_start','2000','2026-10-20 21:01:40'),
('category_discounts','{\"other\":{\"name\":\"General \\/ Other\",\"discount\":0},\"automotive\":{\"name\":\"Automotive & Dealerships\",\"discount\":0},\"dining\":{\"name\":\"Restaurants & Fast Food\",\"discount\":0},\"hospitality\":{\"name\":\"Nightlife, Bars & Events\",\"discount\":0},\"financial\":{\"name\":\"Banking & Financial\",\"discount\":0},\"campus\":{\"name\":\"Campus Retail & Student Services\",\"discount\":10},\"telecom\":{\"name\":\"Telecom & Tech\",\"discount\":0},\"health\":{\"name\":\"Healthcare & Fitness\",\"discount\":0},\"education\":{\"name\":\"Education & Departments\",\"discount\":15}}','2026-10-20 21:01:40'),
('currency_iso','ZAR','2026-10-20 21:01:40'),
('currency_symbol','R','2026-10-20 21:01:40'),
('duration_multipliers','{\"15 sec\":0.5,\"30 sec\":1,\"45 sec\":1.5,\"60 sec\":2}','2026-10-20 21:01:40'),
('export_dir','/srv/myriad_exports','2026-10-20 21:01:40'),
('hourly_capacity','20','2026-10-20 21:01:40'),
('max_ad_minutes_per_hour','10','2026-10-20 21:01:40'),
('package_presets','{\"option_1\":{\"key\":\"option_1\",\"name\":\"Option 1: 50 Prime Recorded Ads\",\"type\":\"weekly\",\"total_spots\":50,\"rate\":5999,\"description\":\"\"},\"option_2\":{\"key\":\"option_2\",\"name\":\"Option 2: 50 Prime Live Reads\",\"type\":\"weekly\",\"total_spots\":50,\"rate\":6999,\"description\":\"\"},\"option_3\":{\"key\":\"option_3\",\"name\":\"Option 3: 120 Prime Recorded Ads\",\"type\":\"monthly\",\"total_spots\":120,\"rate\":15999,\"description\":\"\"},\"option_4\":{\"key\":\"option_4\",\"name\":\"Option 4: 120 Prime Live Reads\",\"type\":\"monthly\",\"total_spots\":120,\"rate\":16999,\"description\":\"\"}}','2026-10-20 21:01:40'),
('playout_log_dir','/srv/myriad_reconciliation','2026-10-20 21:01:40'),
('slots','{\"PRE-BREAKFAST\":{\"part_number\":\"PRE-BREAKFAST\",\"orig_part_number\":\"PRE-BREAKFAST\",\"title\":\"Pre-Breakfast\",\"hours\":\"05:00 - 06:00\",\"rate\":120,\"weekend_rate\":120,\"description\":\"One 30 second prerecorded advertisement played between 05:00 and 06:00.\"},\"MORNING-BUZZ\":{\"part_number\":\"MORNING-BUZZ\",\"orig_part_number\":\"MORNING-BUZZ\",\"title\":\"Morning Buzz (Breakfast Show)\",\"hours\":\"06:00 - 09:00\",\"rate\":350,\"weekend_rate\":300,\"description\":\"One 30 second prerecorded advertisement played between 06:00 and 09:00.\"},\"MIDMORNING-BANTER\":{\"part_number\":\"MIDMORNING-BANTER\",\"orig_part_number\":\"MIDMORNING-BANTER\",\"title\":\"Midmorning Banter\",\"hours\":\"09:00 - 12:00\",\"rate\":320,\"weekend_rate\":320,\"description\":\"One 30 second prerecorded advertisement played between 09:00 and 12:00.\"},\"MIDDAY-PULSE\":{\"part_number\":\"MIDDAY-PULSE\",\"orig_part_number\":\"MIDDAY-PULSE\",\"title\":\"Midday Pulse\",\"hours\":\"12:00 - 15:00\",\"rate\":350,\"weekend_rate\":350,\"description\":\"One 30 second prerecorded advertisement played between 12:00 and 15:00.\"},\"CRUISE-CONTROL\":{\"part_number\":\"CRUISE-CONTROL\",\"orig_part_number\":\"CRUISE-CONTROL\",\"title\":\"Cruise Control (Afternoon Drive)\",\"hours\":\"15:00 - 18:00\",\"rate\":350,\"weekend_rate\":350,\"description\":\"One 30 second prerecorded advertisement played between 15:00 and 18:00.\"},\"SPECIALTY-SHOW-1\":{\"part_number\":\"SPECIALTY-SHOW-1\",\"orig_part_number\":\"SPECIALTY-SHOW-1\",\"title\":\"Specialty Show 1 (Evening)\",\"hours\":\"18:00 - 21:00\",\"rate\":300,\"weekend_rate\":220,\"description\":\"One 30 second prerecorded advertisement played between 18:00 and 21:00.\"},\"SPECIALTY-SHOW-2\":{\"part_number\":\"SPECIALTY-SHOW-2\",\"orig_part_number\":\"SPECIALTY-SHOW-2\",\"title\":\"Specialty Show 2 (Late Evening)\",\"hours\":\"21:00 - 00:00\",\"rate\":220,\"weekend_rate\":120,\"description\":\"One 30 second prerecorded advertisement played between 21:00 and 00:00.\"},\"MUSIC-UNLIMITED\":{\"part_number\":\"MUSIC-UNLIMITED\",\"orig_part_number\":\"MUSIC-UNLIMITED\",\"title\":\"Music Unlimited (Overnight)\",\"hours\":\"00:00 - 05:00\",\"rate\":120,\"weekend_rate\":120,\"description\":\"One 30 second prerecorded advertisement played between 00:00 and 05:00.\"}}','2026-10-20 21:01:40'),
('station_callsign','PUKfm','2026-10-20 21:01:40'),
('station_configured','true','2026-10-20 21:01:40'),
('station_email','traffic@station.local','2026-10-20 21:01:40'),
('station_frequency','93.6 FM','2026-10-20 21:01:40'),
('station_logo_url','custom/include/RadioCRM/pukfm_logo_round.jpeg','2026-10-20 21:01:40'),
('station_manager_name','Station Manager','2026-10-20 21:01:40'),
('station_name','PUKfm 93.6','2026-10-20 21:01:40'),
('station_phone','+27 18 299 1111','2026-10-20 21:01:40'),
('station_tagline','Hear the beat of campus','2026-10-20 21:01:40'),
('studio_address','Broadcasting House, Studio 1, Main Campus','2026-10-20 21:01:40'),
('vat_number','4099887766','2026-10-20 21:01:40'),
('vat_rate','15','2026-10-20 21:01:40');
/*!40000 ALTER TABLE `radio_station_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relationships`
--

DROP TABLE IF EXISTS `relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `relationships` (
  `id` char(36) NOT NULL,
  `relationship_name` varchar(150) DEFAULT NULL,
  `lhs_module` varchar(100) DEFAULT NULL,
  `lhs_table` varchar(64) DEFAULT NULL,
  `lhs_key` varchar(64) DEFAULT NULL,
  `rhs_module` varchar(100) DEFAULT NULL,
  `rhs_table` varchar(64) DEFAULT NULL,
  `rhs_key` varchar(64) DEFAULT NULL,
  `join_table` varchar(64) DEFAULT NULL,
  `join_key_lhs` varchar(64) DEFAULT NULL,
  `join_key_rhs` varchar(64) DEFAULT NULL,
  `relationship_type` varchar(64) DEFAULT NULL,
  `relationship_role_column` varchar(64) DEFAULT NULL,
  `relationship_role_column_value` varchar(50) DEFAULT NULL,
  `reverse` tinyint(1) DEFAULT 0,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_rel_name` (`relationship_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relationships`
--

LOCK TABLES `relationships` WRITE;
/*!40000 ALTER TABLE `relationships` DISABLE KEYS */;
INSERT INTO `relationships` VALUES
('00f673ee-d303-4f3f-be45-d949595b0283','surveyresponses_modified_user','Users','users','id','SurveyResponses','surveyresponses','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('012436c8-f0d6-48f1-9dcb-c538bfb9593d','aos_quotes_aos_line_item_groups','AOS_Quotes','aos_quotes','id','AOS_Line_Item_Groups','aos_line_item_groups','parent_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('026be312-3a77-4c29-809e-7a0573f8b124','bugs_modified_user','Users','users','id','Bugs','bugs','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('0281d9e4-58d2-44c4-ab2e-d16602f4d001','am_projecttemplates_modified_user','Users','users','id','AM_ProjectTemplates','am_projecttemplates','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('03874a71-8ee6-44bc-a51f-1f5fb92a9704','calls_modified_user','Users','users','id','Calls','calls','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('042b29ef-3df8-48de-aa7b-f145dfd3376d','aos_line_item_groups_modified_user','Users','users','id','AOS_Line_Item_Groups','aos_line_item_groups','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('0512c764-0b9c-459b-893f-d48e72a6c9b9','contact_tasks','Contacts','contacts','id','Tasks','tasks','contact_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('05776336-902a-4ca0-9315-322e2cdd158e','bug_tasks','Bugs','bugs','id','Tasks','tasks','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Bugs',0,0),
('0589e699-f152-494c-9827-46d383a4f58d','schedulers_modified_user_id_rel','Users','users','id','Schedulers','schedulers','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('05be3f93-e7fb-466a-abac-17edb25726f5','contact_notes','Contacts','contacts','id','Notes','notes','contact_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('0625838a-e93f-4ff2-bdcd-39faa3487b1f','aos_line_item_groups_created_by','Users','users','id','AOS_Line_Item_Groups','aos_line_item_groups','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('062d7b6b-ce0d-43ce-8eb7-4d37fcb0ad33','opportunities_contacts','Opportunities','opportunities','id','Contacts','contacts','id','opportunities_contacts','opportunity_id','contact_id','many-to-many',NULL,NULL,0,0),
('06a5f20c-fb72-452a-a6f5-d6734532a5c2','reminders_created_by','Users','users','id','Reminders','reminders','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('06aa0a96-5e19-46e5-bb45-1b53ae71eba9','cases_aop_case_updates','Cases','cases','id','AOP_Case_Updates','aop_case_updates','case_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('07860257-dc0c-4dde-b6b7-43cbbcfa3822','securitygroups_bugs','SecurityGroups','securitygroups','id','Bugs','bugs','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Bugs',0,0),
('082fa223-6e80-4db3-a983-22d32e82895c','aos_quotes_created_by','Users','users','id','AOS_Quotes','aos_quotes','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('0a484b4a-6e2f-4822-bc19-2c8996a4354e','aow_processed_created_by','Users','users','id','AOW_Processed','aow_processed','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('0affdcb1-ddc5-4692-a461-e81fddbd24d3','aop_case_updates_modified_user','Users','users','id','AOP_Case_Updates','aop_case_updates','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('0b80c725-8751-4de8-88ea-d6b15c2090b8','lead_notes','Leads','leads','id','Notes','notes','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Leads',0,0),
('0d09f5bd-6ba5-46c7-8822-5dcd60e6770f','contact_tasks_parent','Contacts','contacts','id','Tasks','tasks','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Contacts',0,0),
('0d3aeb70-4cd6-4faf-80b0-e82e51bd3f73','oauthtokens_assigned_user','Users','users','id','OAuthTokens','oauth_tokens','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('0e6f2990-93d1-4bac-a7b9-3a1896bf6eec','securitygroups_externaloauthprovider','SecurityGroups','securitygroups','id','ExternalOAuthProvider','external_oauth_providers','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','ExternalOAuthProvider',0,0),
('0ea0e8f7-637c-4dda-82f5-48cc58a76217','securitygroups_meetings','SecurityGroups','securitygroups','id','Meetings','meetings','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Meetings',0,0),
('0ee56953-2481-4825-93b8-8184f76b3077','accounts_contacts','Accounts','accounts','id','Contacts','contacts','id','accounts_contacts','account_id','contact_id','many-to-many',NULL,NULL,0,0),
('0f65593c-92e8-4a86-82e7-1c551cc19475','aos_invoices_aos_line_item_groups','AOS_Invoices','aos_invoices','id','AOS_Line_Item_Groups','aos_line_item_groups','parent_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('0f82ceac-d6d3-4708-8b59-e6c69bbc7c86','documents_assigned_user','Users','users','id','Documents','documents','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('0fe4fdaa-5377-4f3e-8695-eafa518b7428','project_tasks_notes','ProjectTask','project_task','id','Notes','notes','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','ProjectTask',0,0),
('103b8a85-5a1a-44be-afa4-afc815f97d65','leads_email_addresses_primary','Leads','leads','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','primary_address','1',0,0),
('122bf5fe-3ee8-4af2-a89e-4c612902950d','favorites_modified_user','Users','users','id','Favorites','favorites','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('1380be7f-8d98-453f-a3ab-a53ba11d7af5','emailman_assigned_user','Users','users','id','Emailman','emailman','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('143c1a90-0492-431a-ab04-d92e10209644','aos_invoices_assigned_user','Users','users','id','AOS_Invoices','aos_invoices','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('1471bd8e-2b9b-4444-aa45-83a39c05f271','emails_created_by','Users','users','id','Emails','emails','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('14ea943e-a7f0-4686-819a-600fb9e3ca40','contact_aos_invoices','Contacts','contacts','id','AOS_Invoices','aos_invoices','billing_contact_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('15686e1f-7a56-41a9-b3a1-e9ed39dadfeb','aow_processed_aow_actions','AOW_Processed','aow_processed','id','AOW_Actions','aow_actions','id','aow_processed_aow_actions','aow_processed_id','aow_action_id','many-to-many',NULL,NULL,0,0),
('1581f5b4-2bd2-4154-ba6d-6b84cfd53e73','securitygroups_inboundemail','SecurityGroups','securitygroups','id','InboundEmail','inbound_email','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','InboundEmail',0,0),
('15b48387-d478-4b2f-a090-71990ea65d2a','aop_case_events_modified_user','Users','users','id','AOP_Case_Events','aop_case_events','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('1674eca3-7014-426d-ab07-f3383a292b64','projects_tasks','Project','project','id','Tasks','tasks','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Project',0,0),
('1686c1aa-17f5-4e25-be64-8636e63f6214','project_users_1','Project','project','id','Users','users','id','project_users_1_c','project_users_1project_ida','project_users_1users_idb','many-to-many',NULL,NULL,0,0),
('16f245ba-d4a5-44ff-95ca-c726f92c2e41','aow_processed_modified_user','Users','users','id','AOW_Processed','aow_processed','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('1716be60-296f-4d2e-a5de-277255cac29b','aow_actions_modified_user','Users','users','id','AOW_Actions','aow_actions','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('178a402d-00c1-4540-9b93-b6849108fe08','email_marketing_outbound_email_accounts','OutboundEmailAccounts','outbound_email','id','EmailMarketing','email_marketing','outbound_email_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('17d444a6-659f-4eea-b2c9-0185e7e93fd9','campaign_accounts','Campaigns','campaigns','id','Accounts','accounts','campaign_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('17f849c8-ec9f-4191-8c23-6a6777032c35','aor_charts_aor_reports','AOR_Reports','aor_reports','id','AOR_Charts','aor_charts','aor_report_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('18d7636c-9ff1-4b01-ac15-d686a70673e6','aobh_businesshours_modified_user','Users','users','id','AOBH_BusinessHours','aobh_businesshours','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('195fd59f-c69b-46b0-b194-92763a46f42c','campaignlog_contact','CampaignLog','campaign_log','related_id','Contacts','contacts','id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('1a6e8572-d902-4634-a1d2-2bdf49527fc7','securitygroups_opportunities','SecurityGroups','securitygroups','id','Opportunities','opportunities','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Opportunities',0,0),
('1b15bd16-f701-48d2-86e3-677e770c2f53','surveyresponses_surveyquestionresponses','SurveyResponses','surveyresponses','id','SurveyQuestionResponses','surveyquestionresponses','surveyresponse_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('1badcbbc-b70a-406e-87cb-c3cc274656c3','securitygroups_notes','SecurityGroups','securitygroups','id','Notes','notes','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Notes',0,0),
('1bf3f486-e184-4eea-9502-8050f43abbd5','aos_contracts_aos_line_item_groups','AOS_Contracts','aos_contracts','id','AOS_Line_Item_Groups','aos_line_item_groups','parent_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('1d9e3237-70ae-44fc-8ed6-a8ea0885b9a8','sub_product_categories','AOS_Product_Categories','aos_product_categories','id','AOS_Product_Categories','aos_product_categories','parent_category_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('1e30dfcc-e0b1-45a5-b777-50374f573ee5','oauth2authcodes_assigned_user','Users','users','id','OAuth2AuthCodes','oauth2authcodes','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('1f0283bc-f0e9-434b-9bfd-9f670ee923b8','aos_line_item_groups_assigned_user','Users','users','id','AOS_Line_Item_Groups','aos_line_item_groups','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('1fcff2af-e97c-4706-982b-11308b461c77','leads_documents','Leads','leads','id','Documents','documents','id','linked_documents','parent_id','document_id','many-to-many','parent_type','Leads',0,0),
('1fdd68a1-be39-419a-bb31-df17eddf1a57','aor_scheduled_reports_modified_user','Users','users','id','AOR_Scheduled_Reports','aor_scheduled_reports','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('2005fed9-3d5f-4207-9a92-cec08588b47b','case_calls','Cases','cases','id','Calls','calls','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Cases',0,0),
('2039c993-6f75-4a1a-bffd-ead0ad995368','jjwg_maps_assigned_user','Users','users','id','jjwg_Maps','jjwg_maps','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('20a502a7-130b-4d90-b01c-7df4b059a498','jjwg_Maps_cases','jjwg_Maps','jjwg_Maps','parent_id','Cases','cases','id',NULL,NULL,NULL,'one-to-many','parent_type','Cases',0,0),
('20ba213d-d660-4b2d-8a6f-b57a9b2d912f','calendaraccount_modified_user','Users','users','id','CalendarAccount','calendar_accounts','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('21d3abfd-3afe-46b2-b2e3-d0e227c9ecaa','surveyresponses_assigned_user','Users','users','id','SurveyResponses','surveyresponses','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('21f23c5a-3dd3-44f6-af4c-d739eb8dd40e','aos_contracts_notes','AOS_Contracts','aos_contracts','id','Notes','notes','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','AOS_Contracts',0,0),
('22aa8558-2e80-4ec7-be1b-a350471c541b','surveys_surveyquestions','Surveys','surveys','id','SurveyQuestions','surveyquestions','survey_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('22d1eaf7-b05d-4577-811e-8e37b87465fc','calls_reschedule','Calls','calls','id','Calls_Reschedule','calls_reschedule','call_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('231e3178-3e16-4536-93d9-ee04eff84bb8','surveyresponses_contacts','Contacts','contacts','id','SurveyResponses','surveyresponses','contact_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('2325b88f-1208-4793-abf4-0f39be9ac41d','securitygroups_prospect_lists','SecurityGroups','securitygroups','id','ProspectLists','prospect_lists','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','ProspectLists',0,0),
('23d7c232-6174-47d3-a2ab-0e0d31866b25','securitygroups_emails','SecurityGroups','securitygroups','id','Emails','emails','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Emails',0,0),
('24be439c-68e0-4297-a6d8-c74fa21936f5','reminders_invitees_created_by','Users','users','id','Reminders_Invitees','reminders_invitees','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('254c73de-e473-43c6-b269-345e883fe87a','email_marketing_prospect_lists','EmailMarketing','email_marketing','id','ProspectLists','prospect_lists','id','email_marketing_prospect_lists','email_marketing_id','prospect_list_id','many-to-many',NULL,NULL,0,0),
('2584f0b6-fbcb-4ca8-a08a-c444171b342e','aos_products_created_by','Users','users','id','AOS_Products','aos_products','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('25a89eeb-bd8b-4416-8142-632152e7736f','product_categories','AOS_Product_Categories','aos_product_categories','id','AOS_Products','aos_products','aos_product_category_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('25c00adb-cc90-4394-8792-38e82a4c3f1a','project_tasks_modified_user','Users','users','id','ProjectTask','project_task','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('2696989d-0a9e-47bf-a4dc-f9f27db7b16d','campaigns_modified_user','Users','users','id','Campaigns','campaigns','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('27b62e81-346e-430e-ab0d-5d41f1788c59','projects_contacts','Project','project','id','Contacts','contacts','id','projects_contacts','project_id','contact_id','many-to-many',NULL,NULL,0,0),
('27c879e0-6fac-4119-88e8-7ae9ad433c07','reminders_assigned_user','Users','users','id','Reminders','reminders','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('27cc2a4f-37cb-4265-bae5-1add0016370a','securitygroups_aor_reports','SecurityGroups','securitygroups','id','AOR_Reports','aor_reports','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOR_Reports',0,0),
('28bcaf10-4e16-49c6-b0a2-6ade0a78a94d','aobh_businesshours_created_by','Users','users','id','AOBH_BusinessHours','aobh_businesshours','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('2a69a9de-30fb-41a6-8c26-1da9140a66ed','jjwg_maps_modified_user','Users','users','id','jjwg_Maps','jjwg_maps','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('2b13464d-cbee-4f44-98fc-4628fd03e7b1','outbound_emails_external_oauth_connections','ExternalOAuthConnection','external_oauth_connections','id','OutboundEmailAccounts','outbound_email','external_oauth_connection_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('2c1b52ee-6bf5-4a91-ae06-979cc4b4647e','inbound_emails_case_email_templates','EmailTemplates','email_templates','id','InboundEmail','inbound_email','create_case_template_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('2c24a56a-bb14-4224-b2d7-5366eacb57c9','bugs_release','Releases','releases','id','Bugs','bugs','found_in_release',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('2e1abdda-89bb-48c5-b540-5b3c14faa8c6','aow_workflow_created_by','Users','users','id','AOW_WorkFlow','aow_workflow','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('2e86eca7-b181-4ea3-a632-24320d4f8262','project_tasks_emails','ProjectTask','project_task','id','Emails','emails','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','ProjectTask',0,0),
('2eef4f80-a811-4e2b-9aef-11af7d4f8d11','securitygroups_assigned_user','Users','users','id','SecurityGroups','securitygroups','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('2f22c4c3-089c-4988-a75a-15f2a371a50e','aos_quotes_project','AOS_Quotes','aos_quotes','id','Project','project','id','aos_quotes_project_c','aos_quotes1112_quotes_ida','aos_quotes7207project_idb','many-to-many',NULL,NULL,0,0),
('2f768b3b-304b-48e0-90ae-d6e9769f506f','prospects_email_addresses_primary','Prospects','prospects','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','primary_address','1',0,0),
('2f78b4bb-441d-4ca1-8d23-ad576a700220','member_accounts','Accounts','accounts','id','Accounts','accounts','parent_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('30a8434d-ac11-4d9f-bbd5-9e2c3ea6ef48','aor_conditions_modified_user','Users','users','id','AOR_Conditions','aor_conditions','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('31101947-015c-40f9-aa48-f660d20ad690','emails_modified_user','Users','users','id','Emails','emails','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('311be338-96be-47bd-b2bc-e7468160084d','aos_contracts_documents','AOS_Contracts','aos_contracts','id','Documents','documents','id','aos_contracts_documents','aos_contracts_id','documents_id','many-to-many',NULL,NULL,0,0),
('3121b7ee-d202-4bd6-8e4e-39f54639e807','documents_accounts','Documents','documents','id','Accounts','accounts','id','documents_accounts','document_id','account_id','many-to-many',NULL,NULL,0,0),
('317b4c90-1c76-4808-a01a-05eb7dfd0328','email_template_email_marketings','EmailTemplates','email_templates','id','EmailMarketing','email_marketing','template_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('31bd41e3-becc-48f0-b0dd-792dab4c98b2','accounts_email_addresses','Accounts','accounts','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','bean_module','Accounts',0,0),
('31e8f38d-7eb0-4268-b352-8ea581bbc776','aor_charts_created_by','Users','users','id','AOR_Charts','aor_charts','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('32a4c8ff-04b4-4b4b-87e1-b90cdc8cf05a','account_emails','Accounts','accounts','id','Emails','emails','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Accounts',0,0),
('33b41915-bfca-4d6a-b446-52a9c186dbb3','opportunity_notes','Opportunities','opportunities','id','Notes','notes','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Opportunities',0,0),
('33e95967-8cab-4235-ac93-707cf9353a37','fp_events_contacts','FP_events','fp_events','id','Contacts','contacts','id','fp_events_contacts_c','fp_events_contactsfp_events_ida','fp_events_contactscontacts_idb','many-to-many',NULL,NULL,0,0),
('3402f23d-1de4-4955-9e20-b21da6363a29','asynctaskitems_modified_user','Users','users','id','AsyncTaskItems','async_task_items','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('341b4334-bcc8-480c-a2cb-21f59c7bdefc','surveyquestionresponses_assigned_user','Users','users','id','SurveyQuestionResponses','surveyquestionresponses','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('3445b624-3a24-4342-b1d7-a11bc8190537','opportunity_emails','Opportunities','opportunities','id','Emails','emails','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Opportunities',0,0),
('352c869d-a17e-41b4-96f4-8da5799d25a6','prospectlists_assigned_user','Users','users','id','ProspectLists','prospect_lists','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('354ab791-164c-4f9f-bcfb-f3240db8e914','aos_contracts_modified_user','Users','users','id','AOS_Contracts','aos_contracts','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('355bf5c0-b939-4830-b743-13b12b85acea','jjwg_maps_jjwg_markers','jjwg_Maps','jjwg_maps','id','jjwg_Markers','jjwg_markers','id','jjwg_maps_jjwg_markers_c','jjwg_maps_b229wg_maps_ida','jjwg_maps_2e31markers_idb','many-to-many',NULL,NULL,0,0),
('35db2df7-1484-41f6-ad5b-758dddf0699b','calendar_account_meetings','CalendarAccount','calendar_accounts','id','Meetings','meetings','id','calendar_account_meetings','calendar_account_id','meeting_id','one-to-many',NULL,NULL,0,0),
('36416a22-d958-4554-ae74-4aa2b45ba540','jjwg_Maps_leads','jjwg_Maps','jjwg_Maps','parent_id','Leads','leads','id',NULL,NULL,NULL,'one-to-many','parent_type','Leads',0,0),
('3641a5cb-7614-4542-98ad-8420e055fe95','aow_workflow_aow_processed','AOW_WorkFlow','aow_workflow','id','AOW_Processed','aow_processed','aow_workflow_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('36d54722-36e6-436b-80d7-3ac520b7f645','calendaraccount_assigned_user','Users','users','id','CalendarAccount','calendar_accounts','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('36f9e687-5f90-4e06-ad36-1c735a93c517','notes_created_by','Users','users','id','Notes','notes','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('3712124f-f18a-4187-a75a-af828eab283f','mediaobjects_assigned_user','Users','users','id','MediaObjects','archived_documents_media_objects','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('37f41a6d-b1dc-41c2-b917-90cebd894e56','bugs_assigned_user','Users','users','id','Bugs','bugs','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('38c9c7b0-db72-4dc4-807e-eee9eb8e7ad5','aow_workflow_aow_conditions','AOW_WorkFlow','aow_workflow','id','AOW_Conditions','aow_conditions','aow_workflow_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('38ed57bb-4de2-465b-9118-6ddd4867ab46','opportunity_currencies','Opportunities','opportunities','currency_id','Currencies','currencies','id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('396f0718-896a-4574-b28c-9546a7e4a2c6','campaign_assigned_user','Users','users','id','Campaigns','campaigns','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('39a81785-0166-4cb3-964d-b58e8a155a3f','meetings_modified_user','Users','users','id','Meetings','meetings','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('39ae8057-141c-4876-96fd-ae33075f0851','tasks_modified_user','Users','users','id','Tasks','tasks','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('39b32840-a77b-4741-a438-b3009a3b9621','project_tasks_calls','ProjectTask','project_task','id','Calls','calls','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','ProjectTask',0,0),
('3a930cc2-fa16-4282-a498-142eecce57d3','account_calls','Accounts','accounts','id','Calls','calls','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Accounts',0,0),
('3aca17ce-947d-4277-9bea-f295e06d0032','prospect_tasks','Prospects','prospects','id','Tasks','tasks','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Prospects',0,0),
('3bc56538-01b8-48b1-b145-f7976bbf7977','case_tasks','Cases','cases','id','Tasks','tasks','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Cases',0,0),
('3bda38f5-1779-489f-a19c-21d30cbff85b','account_aos_contracts','Accounts','accounts','id','AOS_Contracts','aos_contracts','contract_account_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('3bea81c8-041a-41b1-856f-1babe0c9a48b','aok_knowledge_base_categories_modified_user','Users','users','id','AOK_Knowledge_Base_Categories','aok_knowledge_base_categories','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('3eac6bbc-887b-4b98-8d04-6fe663646cb9','surveyresponses_campaigns','Campaigns','campaigns','id','SurveyResponses','surveyresponses','campaign_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('3f8a0ebc-383e-421c-b18f-dd7bdb2f915e','campaign_campaigntrakers','Campaigns','campaigns','id','CampaignTrackers','campaign_trkrs','campaign_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('4032b2cc-73d3-4045-ad77-6a092f8db170','contact_notes_parent','Contacts','contacts','id','Notes','notes','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Contacts',0,0),
('412470cf-e3da-4ded-9584-3ca504780d3d','am_tasktemplates_am_projecttemplates','AM_ProjectTemplates','am_projecttemplates','id','AM_TaskTemplates','am_tasktemplates','id','am_tasktemplates_am_projecttemplates_c','am_tasktemplates_am_projecttemplatesam_projecttemplates_ida','am_tasktemplates_am_projecttemplatesam_tasktemplates_idb','many-to-many',NULL,NULL,0,0),
('41a8d050-60f4-4cd2-b220-19b6bea5c487','fp_events_modified_user','Users','users','id','FP_events','fp_events','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('42275d3a-ba21-410a-af39-a9cb5a25b19c','aos_quotes_aos_invoices','AOS_Quotes','aos_quotes','id','AOS_Invoices','aos_invoices','id','aos_quotes_aos_invoices_c','aos_quotes77d9_quotes_ida','aos_quotes6b83nvoices_idb','many-to-many',NULL,NULL,0,0),
('42d1be1d-816b-4d3f-8c19-7b03b05c0200','campaign_email_marketing','Campaigns','campaigns','id','EmailMarketing','email_marketing','campaign_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('4315d37c-306e-4a0a-8512-1849005f9f34','emails_opportunities_rel','Emails','emails','id','Opportunities','opportunities','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Opportunities',0,0),
('4385a72c-4f11-436d-865c-fe5608eb160b','opportunity_aos_contracts','Opportunities','opportunities','id','AOS_Contracts','aos_contracts','opportunity_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('43920683-fcf3-4624-8040-e3e90bb6f86d','contacts_users','Contacts','contacts','id','Users','users','id','contacts_users','contact_id','user_id','many-to-many',NULL,NULL,0,0),
('439ea20d-a564-48d4-8da9-b41edca02e98','aop_case_events_created_by','Users','users','id','AOP_Case_Events','aop_case_events','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('43cc4cd0-0f6f-4edc-8da9-bda390567893','jjwg_Maps_meetings','jjwg_Maps','jjwg_Maps','parent_id','Meetings','meetings','id',NULL,NULL,NULL,'one-to-many','parent_type','Meetings',0,0),
('44a5a555-999c-47d1-a08e-2049fd932dc0','campaign_notes','Campaigns','campaigns','id','Notes','notes','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Campaigns',0,0),
('44bafdf0-9f83-4d88-a966-177e31207b45','inbound_emails_external_oauth_connections','ExternalOAuthConnection','external_oauth_connections','id','InboundEmail','inbound_email','external_oauth_connection_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('44dc4c0e-10fa-40fe-b70f-fede28d7728a','securitygroups_processes','SecurityGroups','securitygroups','id','Processes','processes','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Processes',0,0),
('45c7690c-71ce-4707-8b4e-9f28d466f03f','aok_knowledge_base_categories_created_by','Users','users','id','AOK_Knowledge_Base_Categories','aok_knowledge_base_categories','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('45e23089-5baf-404c-85cd-465610688290','documents_created_by','Users','users','id','Documents','documents','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('466aeb1d-d133-479a-becf-79f5661942c2','securitygroups_aok_knowledgebase','SecurityGroups','securitygroups','id','AOK_KnowledgeBase','aok_knowledgebase','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOK_KnowledgeBase',0,0),
('4760cae5-0737-4c2f-9b3b-44be2e264a84','am_projecttemplates_contacts_1','AM_ProjectTemplates','am_projecttemplates','id','Contacts','contacts','id','am_projecttemplates_contacts_1_c','am_projecttemplates_ida','contacts_idb','many-to-many',NULL,NULL,0,0),
('478d0e96-ddd4-4524-9e33-41da7d95d4ff','aos_product_quotes_aos_products','AOS_Products','aos_products','id','AOS_Products_Quotes','aos_products_quotes','product_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('47c220fe-d1e7-4d53-8422-d0340da37154','cases_modified_user','Users','users','id','Cases','cases','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('47f70ff0-3526-4f57-b5bb-6bd21a81416d','projects_emails','Project','project','id','Emails','emails','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Project',0,0),
('481a727c-7c6e-4e50-84b8-7dd72dff3bcf','mediaobjects_modified_user','Users','users','id','MediaObjects','archived_documents_media_objects','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('48ff1d7b-fe61-41eb-b89b-334e0422f495','aos_pdf_templates_created_by','Users','users','id','AOS_PDF_Templates','aos_pdf_templates','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('49d95ae4-75fb-44c1-b604-e0e43550f193','manualmigrationtasks_modified_user','Users','users','id','ManualMigrationTasks','manual_migration_tasks','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('4a5d948f-20de-4f70-b138-e89fb5965ffe','prospects_assigned_user','Users','users','id','Prospects','prospects','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('4a6a3f99-241f-47be-9e7a-76c46373f36f','oauth2authcodes_created_by','Users','users','id','OAuth2AuthCodes','oauth2authcodes','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('4a94497e-5444-452c-ba39-f691f161dc54','calendar_accounts_calendar_user','Users','users','id','CalendarAccount','calendar_accounts','calendar_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('4b3d5252-0705-40a2-bd0a-bcea85f35f69','prospects_email_addresses','Prospects','prospects','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','bean_module','Prospects',0,0),
('4bd9ff9c-53c1-4dc7-9892-700d8327bafb','jjwg_markers_created_by','Users','users','id','jjwg_Markers','jjwg_markers','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('4be73cd2-b671-4158-b7ab-fd2e112f6438','calls_notes','Calls','calls','id','Notes','notes','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Calls',0,0),
('4d363076-829a-4bef-9fda-531ce6e1d72c','securitygroups_aos_quotes','SecurityGroups','securitygroups','id','AOS_Quotes','aos_quotes','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_Quotes',0,0),
('4d8f6015-71c0-4656-b19f-c9a60d289a70','jjwg_areas_modified_user','Users','users','id','jjwg_Areas','jjwg_areas','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('4de50549-6574-41f8-ac69-2a5feadf30f2','mediaobjects_created_by','Users','users','id','MediaObjects','archived_documents_media_objects','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('4e82402d-47f7-402d-8b7f-e87fec44280d','lead_meetings','Leads','leads','id','Meetings','meetings','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Leads',0,0),
('4f000e5f-2252-4e7e-a10e-871fc24f0ef8','securitygroups_cases','SecurityGroups','securitygroups','id','Cases','cases','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Cases',0,0),
('4f3b2388-2c50-4112-8c5a-b745a101ccfb','am_projecttemplates_created_by','Users','users','id','AM_ProjectTemplates','am_projecttemplates','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('50710b52-0e28-4295-8fbe-b2b127e5305c','securitygroups_users','SecurityGroups','securitygroups','id','Users','users','id','securitygroups_users','securitygroup_id','user_id','many-to-many',NULL,NULL,0,0),
('508bb85c-ca3a-4f24-8007-29bc4fe4a16b','opportunity_calls','Opportunities','opportunities','id','Calls','calls','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Opportunities',0,0),
('519b7ba0-0a19-430b-a1f5-c238fe2afea3','jjwg_markers_assigned_user','Users','users','id','jjwg_Markers','jjwg_markers','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('51ff409b-bc2c-46cf-9307-ec07dd686ed1','account_leads','Accounts','accounts','id','Leads','leads','account_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('5284df56-f2db-4add-a013-bc102223248e','securitygroups_acl_roles','SecurityGroups','securitygroups','id','ACLRoles','acl_roles','id','securitygroups_acl_roles','securitygroup_id','role_id','many-to-many',NULL,NULL,0,0),
('535a23b2-f31b-4201-b768-11d63e28fd62','aos_product_categories_assigned_user','Users','users','id','AOS_Product_Categories','aos_product_categories','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('53d148da-6fd0-49cf-a283-c70bba7b2f63','accounts_created_by','Users','users','id','Accounts','accounts','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('5450c0ce-bf9c-498e-975e-fd3ea180b190','tasks_notes','Tasks','tasks','id','Notes','notes','parent_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('5514d944-7b5a-4af6-a9fe-e7469a99d09f','aos_invoices_modified_user','Users','users','id','AOS_Invoices','aos_invoices','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('55b01929-99c2-4f96-bdf5-97c6b2d7a0dc','prospect_emails','Prospects','prospects','id','Emails','emails','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Prospects',0,0),
('5662bacb-d5fa-457e-bfe2-fb37bfc3a423','favorites_assigned_user','Users','users','id','Favorites','favorites','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('56cbf86f-7f02-4b6c-887a-e57fc0589504','surveyquestionoptions_surveyquestionresponses','SurveyQuestionOptions','surveyquestionoptions','id','SurveyQuestionResponses','surveyquestionresponses','id','surveyquestionoptions_surveyquestionresponses','surveyq72c7options_ida','surveyq10d4sponses_idb','many-to-many',NULL,NULL,0,0),
('572abab3-cf4f-4be1-b1b5-c56e0ac94c6f','securitygroups_aos_products','SecurityGroups','securitygroups','id','AOS_Products','aos_products','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_Products',0,0),
('57a13e45-ca6f-4b86-80dc-0f27db95a705','emails_projects_rel','Emails','emails','id','Project','project','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Project',0,0),
('57e75e70-84aa-4023-840e-0b179cf1fb83','documents_modified_user','Users','users','id','Documents','documents','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('5aa46ad5-f6a5-4605-aa15-0bbb89babeb2','aos_products_quotes_created_by','Users','users','id','AOS_Products_Quotes','aos_products_quotes','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('5aab0199-8672-408f-a2c0-f0b0cc5aece4','securitygroups_aow_workflow','SecurityGroups','securitygroups','id','AOW_WorkFlow','aow_workflow','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOW_WorkFlow',0,0),
('5ac90f99-b6fc-4b06-bc74-a3eb3eed84b8','oauth2clients_assigned_user','Users','users','id','OAuth2Clients','oauth2clients','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('5b0300a0-3225-4f17-8083-f341f8b48373','reminders_modified_user','Users','users','id','Reminders','reminders','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('5b3430e8-6739-4d02-b358-6d8b23e2ce90','opportunity_meetings','Opportunities','opportunities','id','Meetings','meetings','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Opportunities',0,0),
('5bb179ee-fe6e-4945-af75-bdbbbf5be3fc','jjwg_address_cache_created_by','Users','users','id','jjwg_Address_Cache','jjwg_address_cache','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('5bd497e9-5c8e-4b49-986c-8919a6baf560','aop_case_events_assigned_user','Users','users','id','AOP_Case_Events','aop_case_events','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('5c41a5c4-5773-49a4-90cb-04b56960aa5c','leads_modified_user','Users','users','id','Leads','leads','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('5c4da547-348b-4070-82d9-56939c959fea','schedulersjobs_assigned_user','Users','users','id','SchedulersJobs','job_queue','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('5d96d0f2-80fd-4aba-8ef4-0c467954be16','bug_meetings','Bugs','bugs','id','Meetings','meetings','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Bugs',0,0),
('5e6364b8-5143-4049-9884-9e6e38e78a1d','opportunities_campaign','Campaigns','campaigns','id','Opportunities','opportunities','campaign_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('5e6858f2-7633-4107-a5b7-1fb5cec548e6','emails_accounts_rel','Emails','emails','id','Accounts','accounts','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Accounts',0,0),
('5eb03dbb-23ca-4d26-9b5b-350733291dcb','am_tasktemplates_modified_user','Users','users','id','AM_TaskTemplates','am_tasktemplates','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('5f057836-e68a-4862-9331-5250031f5a8e','emailtemplates_assigned_user','Users','users','id','EmailTemplates','email_templates','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('5fc2e555-3e77-4afa-9f1b-5aedfcae7c35','leads_assigned_user','Users','users','id','Leads','leads','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('6001edc2-f24f-4087-af2c-b8500d372b46','securitygroups_externaloauthconnection','SecurityGroups','securitygroups','id','ExternalOAuthConnection','external_oauth_connections','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','ExternalOAuthConnection',0,0),
('6002b66d-7d5c-484c-964a-335adb96340d','eapm_assigned_user','Users','users','id','EAPM','eapm','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('602a8896-d9a3-4e70-b346-08ba2833086d','fp_event_locations_modified_user','Users','users','id','FP_Event_Locations','fp_event_locations','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('604b356b-cd8f-4a74-92bf-1f8c2e202b0b','aow_workflow_modified_user','Users','users','id','AOW_WorkFlow','aow_workflow','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('605c5af5-180c-4c32-a642-3781f6ddecae','aop_case_updates_notes','AOP_Case_Updates','aop_case_updates','id','Notes','notes','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','AOP_Case_Updates',0,0),
('609723a1-e87b-4f06-85a8-00de8bc2537e','contacts_email_addresses','Contacts','contacts','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','bean_module','Contacts',0,0),
('6101f05a-abf5-42af-a395-823630ff82c0','asynctaskitems_created_by','Users','users','id','AsyncTaskItems','async_task_items','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('61f93847-b9db-46d3-b4c8-c9d1950277e1','oauth2tokens_created_by','Users','users','id','OAuth2Tokens','oauth2tokens','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('6264c080-2caf-43f7-bd75-a6cc99f0f15e','templatesectionline_modified_user','Users','users','id','TemplateSectionLine','templatesectionline','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('626cce68-4c7e-4f11-992f-735bbeeb3e32','aor_reports_aor_fields','AOR_Reports','aor_reports','id','AOR_Fields','aor_fields','aor_report_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('62974aa3-d358-4fe5-8f16-2772e9fc56ef','optimistic_locking',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0),
('634b2a13-a6e9-4ba5-8196-5dea9242d5ea','oauth2authcodes_modified_user','Users','users','id','OAuth2AuthCodes','oauth2authcodes','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('6357db84-4bf2-4a81-bd37-b53f73c8475a','accounts_opportunities','Accounts','accounts','id','Opportunities','opportunities','id','accounts_opportunities','account_id','opportunity_id','many-to-many',NULL,NULL,0,0),
('63c90f2b-699f-4eda-aa45-ea7bcd5fed03','schedulers_created_by_rel','Users','users','id','Schedulers','schedulers','created_by',NULL,NULL,NULL,'one-to-one',NULL,NULL,0,0),
('64717350-8bec-4c73-883d-9dd843d27c7f','leads_created_by','Users','users','id','Leads','leads','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('6472f35a-cf06-4e77-97fc-e83c384e0b68','contacts_bugs','Contacts','contacts','id','Bugs','bugs','id','contacts_bugs','contact_id','bug_id','many-to-many',NULL,NULL,0,0),
('6477a0d5-84b0-47b3-8eb1-ccdfaa766469','prospect_list_contacts','ProspectLists','prospect_lists','id','Contacts','contacts','id','prospect_lists_prospects','prospect_list_id','related_id','many-to-many','related_type','Contacts',0,0),
('64c96553-3b5c-41d4-b873-10a791947d4f','surveys_assigned_user','Users','users','id','Surveys','surveys','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('64e7c2e6-fd2f-4164-b3af-c197f4c7156f','bug_emails','Bugs','bugs','id','Emails','emails','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Bugs',0,0),
('64fc284a-82b4-4421-9c34-430dc13856d3','lead_direct_reports','Leads','leads','id','Leads','leads','reports_to_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('65a715f2-413e-4cf9-843a-7411b60b6a11','surveyquestionresponses_created_by','Users','users','id','SurveyQuestionResponses','surveyquestionresponses','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('65ddf22f-3ba1-4847-b6bf-c37d5e5d1be1','externaloauthprovider_created_by','Users','users','id','ExternalOAuthProvider','external_oauth_providers','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('66811443-44d5-44af-b9a8-2e9da11d6954','securitygroups_project_task','SecurityGroups','securitygroups','id','ProjectTask','project_task','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','ProjectTask',0,0),
('67a98936-0bbd-431b-9c64-1da0e3515720','project_tasks_tasks','ProjectTask','project_task','id','Tasks','tasks','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','ProjectTask',0,0),
('67d97795-8001-47b7-b2d8-64b65b881da5','users_email_addresses_primary','Users','users','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','primary_address','1',0,0),
('67f476ec-0bf0-4cac-996e-8f572da0bc3b','aos_contracts_calls','AOS_Contracts','aos_contracts','id','Calls','calls','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','AOS_Contracts',0,0),
('686a2324-1301-4dec-bfa0-feff20344cd5','contacts_assigned_user','Users','users','id','Contacts','contacts','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('686d007b-b1ab-45fe-a022-6b778fd0bde7','aos_quotes_aos_contracts','AOS_Quotes','aos_quotes','id','AOS_Contracts','aos_contracts','id','aos_quotes_os_contracts_c','aos_quotese81e_quotes_ida','aos_quotes4dc0ntracts_idb','many-to-many',NULL,NULL,0,0),
('68ee28c6-a2f6-4495-b190-896763782c26','securitygroups_jjwg_markers','SecurityGroups','securitygroups','id','jjwg_Markers','jjwg_markers','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','jjwg_Markers',0,0),
('692f1df1-1cdd-4d8c-ab32-b188cbee0d6c','campaign_prospects','Campaigns','campaigns','id','Prospects','prospects','campaign_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('69650e6d-bff5-41b6-9ad8-c47b80825627','alerts_created_by','Users','users','id','Alerts','alerts','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('6970bae7-f516-4622-98d3-fa5e3db5974f','cases_bugs','Cases','cases','id','Bugs','bugs','id','cases_bugs','case_id','bug_id','many-to-many',NULL,NULL,0,0),
('69c35a8b-974b-45fe-80b4-33fab5ca40f1','acl_roles_actions','ACLRoles','acl_roles','id','ACLActions','acl_actions','id','acl_roles_actions','role_id','action_id','many-to-many',NULL,NULL,0,0),
('69cc8030-7f82-410e-a73e-f31e84d10584','surveyresponses_accounts','Accounts','accounts','id','SurveyResponses','surveyresponses','account_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('6a5ed991-2113-402a-b1c3-2c01ae578734','meetings_notes','Meetings','meetings','id','Notes','notes','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Meetings',0,0),
('6bc2f1cc-2e4f-4992-8960-a01d71c99144','account_meetings','Accounts','accounts','id','Meetings','meetings','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Accounts',0,0),
('6bc70716-7457-48d2-9af1-b7d071299732','fp_event_locations_assigned_user','Users','users','id','FP_Event_Locations','fp_event_locations','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('6c5840d3-3289-4fb0-8e4b-31efab66765a','projects_meetings','Project','project','id','Meetings','meetings','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Project',0,0),
('6dc13b8a-ae74-4e60-95f7-358a300af230','acl_roles_users','ACLRoles','acl_roles','id','Users','users','id','acl_roles_users','role_id','user_id','many-to-many',NULL,NULL,0,0),
('6dd76d52-476d-4f19-a38f-3b27f8f5d535','aos_quotes_assigned_user','Users','users','id','AOS_Quotes','aos_quotes','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('6e47ad76-037d-45ee-ac96-df5031f367bd','bug_calls','Bugs','bugs','id','Calls','calls','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Bugs',0,0),
('6e802920-9cc8-4472-9c72-ae2fba8c082c','emails_meetings_rel','Emails','emails','id','Meetings','meetings','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Meetings',0,0),
('6f4a691f-db2e-4caf-84f4-0d24b7d4c20f','jjwg_areas_created_by','Users','users','id','jjwg_Areas','jjwg_areas','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('6f5d6a8b-864f-49fb-808a-6eb7e571ee59','externaloauthconnection_created_by','Users','users','id','ExternalOAuthConnection','external_oauth_connections','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('7059d67a-61c8-40b2-8a23-d84aa56f2b5f','users_email_addresses','Users','users','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','bean_module','Users',0,0),
('70f1ae80-ad9e-4b20-a468-03b6eeb44ec6','reminders_invitees_modified_user','Users','users','id','Reminders_Invitees','reminders_invitees','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('71126ead-f8e7-411b-8b48-be1ab83ded09','surveyquestions_assigned_user','Users','users','id','SurveyQuestions','surveyquestions','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('719ed7d9-0628-4f4c-a119-7debf8a56578','fp_events_prospects_1','FP_events','fp_events','id','Prospects','prospects','id','fp_events_prospects_1_c','fp_events_prospects_1fp_events_ida','fp_events_prospects_1prospects_idb','many-to-many',NULL,NULL,0,0),
('71a50eb5-3e1f-4bd6-9910-4944e6f1b135','alerts_assigned_user','Users','users','id','Alerts','alerts','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('71bad0eb-8564-4b92-b79c-02153c56dba0','case_meetings','Cases','cases','id','Meetings','meetings','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Cases',0,0),
('72193de8-c7f6-4d09-98aa-21ccc01fed36','lead_tasks','Leads','leads','id','Tasks','tasks','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Leads',0,0),
('72293e95-ddcb-4de8-9108-c595b8d930d9','securitygroups_manualmigrationtasks','SecurityGroups','securitygroups','id','ManualMigrationTasks','manual_migration_tasks','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','ManualMigrationTasks',0,0),
('7279842a-f97c-4209-a2a4-30706175477c','documents_contacts','Documents','documents','id','Contacts','contacts','id','documents_contacts','document_id','contact_id','many-to-many',NULL,NULL,0,0),
('72809cf4-278a-4c4e-8fed-59b5c3300841','alerts_modified_user','Users','users','id','Alerts','alerts','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('72cb7f4f-ebb6-4b53-b882-edeb22203c35','project_tasks_meetings','ProjectTask','project_task','id','Meetings','meetings','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','ProjectTask',0,0),
('7301d226-f1ff-46e2-998b-0cca87b486aa','cases_created_by','Users','users','id','Cases','cases','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('731d3bee-3501-43d6-88c8-fb96efc675d5','opportunity_leads','Opportunities','opportunities','id','Leads','leads','opportunity_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('7348d765-a450-412f-9f1b-091522eab994','oauth2clients_modified_user','Users','users','id','OAuth2Clients','oauth2clients','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('73c2be99-08fd-430d-a52e-5d1efeecb471','aop_case_updates_assigned_user','Users','users','id','AOP_Case_Updates','aop_case_updates','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('747293a0-433b-46b1-b118-9c1c1e24b62f','rt_radiocampaigns_created_by','Users','users','id','RT_RadioCampaigns','rt_radiocampaigns','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('749a6828-1b28-44be-a24e-44af71f9cb40','processes_assigned_user','Users','users','id','Processes','processes','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('74a8e1df-c860-4191-9fd9-7173bd44e217','fp_events_created_by','Users','users','id','FP_events','fp_events','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('75137631-0026-47df-9061-3780df7fbf48','oauthkeys_modified_user','Users','users','id','OAuthKeys','oauth_consumer','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('7572f6ce-c84b-441a-89dd-65c59c81a0b8','account_cases','Accounts','accounts','id','Cases','cases','account_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('75ac0e06-4c65-4f7d-89d4-3a525a78d16d','account_aos_quotes','Accounts','accounts','id','AOS_Quotes','aos_quotes','billing_account_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('7674abcf-59f4-4aae-839b-15b08025b9fa','aos_products_quotes_assigned_user','Users','users','id','AOS_Products_Quotes','aos_products_quotes','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('778520b8-0a55-4306-9c0c-31eb830fc597','jjwg_Maps_opportunities','jjwg_Maps','jjwg_Maps','parent_id','Opportunities','opportunities','id',NULL,NULL,NULL,'one-to-many','parent_type','Opportunities',0,0),
('781d5ce9-1d5d-4119-b1da-8b2894963be7','securitygroups_projecttask','SecurityGroups','securitygroups','id','ProjectTask','project_task','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','ProjectTask',0,0),
('7876cb5c-5b20-4d61-92c4-dfe03830d79f','securitygroups_calendaraccount','SecurityGroups','securitygroups','id','CalendarAccount','calendar_accounts','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','CalendarAccount',0,0),
('78a83030-e151-49df-82fc-8d97df849b33','aos_pdf_templates_modified_user','Users','users','id','AOS_PDF_Templates','aos_pdf_templates','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('799ca4e5-0391-4487-ab34-8d09379ebfdb','campaignlog_lead','CampaignLog','campaign_log','related_id','Leads','leads','id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('79b9be79-12cc-4f6e-b38f-90302e0658d9','am_projecttemplates_assigned_user','Users','users','id','AM_ProjectTemplates','am_projecttemplates','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('7ab2c268-ae7f-44d2-9ab2-d602b7e27f3e','calls_reschedule_assigned_user','Users','users','id','Calls_Reschedule','calls_reschedule','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('7ca6e26f-dfc6-496e-ae72-3dcfb180e638','roles_users','Roles','roles','id','Users','users','id','roles_users','role_id','user_id','many-to-many',NULL,NULL,0,0),
('7d6892f5-50bc-493f-a6f8-bd05943bdb15','oauth2tokens_assigned_user','Users','users','id','OAuth2Tokens','oauth2tokens','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('7f426884-59ab-41f8-8e7e-93d80e1c3d28','outbound_email_accounts_email_marketing','OutboundEmailAccounts','outbound_email','id','EmailMarketing','email_marketing','outbound_email_id',NULL,NULL,NULL,'one-to-one',NULL,NULL,0,0),
('807bc959-6d59-4ade-aa2a-f0f8ae1d7736','bugs_created_by','Users','users','id','Bugs','bugs','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('80ad8f3e-da25-4486-9ced-387cd2c3ad1e','emails_contacts_rel','Emails','emails','id','Contacts','contacts','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Contacts',0,0),
('8171a307-11c9-4f7a-afb1-7aa175526f3a','documents_bugs','Documents','documents','id','Bugs','bugs','id','documents_bugs','document_id','bug_id','many-to-many',NULL,NULL,0,0),
('8184de95-0174-487a-9aa0-13b5fefc3908','securitygroups_mediaobjects','SecurityGroups','securitygroups','id','MediaObjects','archived_documents_media_objects','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','MediaObjects',0,0),
('81942790-2758-4f1f-8750-b3c72b2fce3d','jjwg_maps_created_by','Users','users','id','jjwg_Maps','jjwg_maps','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('81a87c32-3f7b-44e8-8bcc-bab5961f7480','securitygroups_aos_product_categories','SecurityGroups','securitygroups','id','AOS_Product_Categories','aos_product_categories','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_Product_Categories',0,0),
('82815d50-ba46-4818-9bfc-d1a8ed021076','campaignlog_created_opportunities','CampaignLog','campaign_log','related_id','Opportunities','opportunities','id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('82817c4d-768a-4ce7-a911-f913ac883d7b','aos_contracts_assigned_user','Users','users','id','AOS_Contracts','aos_contracts','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('82e3c5a1-3c14-4230-86d4-969ac5e64ae3','rt_radiocampaigns_aos_quotes','RT_RadioCampaigns','rt_radiocampaigns','id','AOS_Quotes','aos_quotes','id','rt_radiocampaigns_aos_quotes_c','rt_radiocampaigns_aos_quotesrt_radiocampaigns_ida','rt_radiocampaigns_aos_quotesaos_quotes_idb','many-to-many',NULL,NULL,0,0),
('830c2cfe-e35c-4281-a0d1-0bc02a4d0c98','am_projecttemplates_project_1','AM_ProjectTemplates','am_projecttemplates','id','Project','project','id','am_projecttemplates_project_1_c','am_projecttemplates_project_1am_projecttemplates_ida','am_projecttemplates_project_1project_idb','many-to-many',NULL,NULL,0,0),
('8363b945-645f-4e92-ba42-9935a0137bc5','aor_fields_modified_user','Users','users','id','AOR_Fields','aor_fields','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('851f50fd-1834-499d-baa8-460cd1ef91f1','externaloauthprovider_modified_user','Users','users','id','ExternalOAuthProvider','external_oauth_providers','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('852e9917-873e-4b3f-bae0-937131061288','sugarfeed_created_by','Users','users','id','SugarFeed','sugarfeed','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('85405f07-7545-4d20-ac2a-a5dcd4a57665','inbound_outbound_email_accounts','OutboundEmailAccounts','outbound_email','id','InboundEmail','inbound_email','outbound_email_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('859b106d-d0af-452e-8ac4-53c6dabbb612','schedulers_jobs_rel','Schedulers','schedulers','id','SchedulersJobs','job_queue','scheduler_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('863637ff-ea2c-4824-a5b3-c59477436496','aow_workflow_assigned_user','Users','users','id','AOW_WorkFlow','aow_workflow','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('8701193f-a9d3-4d78-a8c3-ca7d53183254','projects_accounts','Project','project','id','Accounts','accounts','id','projects_accounts','project_id','account_id','many-to-many',NULL,NULL,0,0),
('87264e04-ad6c-48e9-aa3b-0e89eec3beb5','securitygroups_surveyquestions','SecurityGroups','securitygroups','id','SurveyQuestions','surveyquestions','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','SurveyQuestions',0,0),
('87687a64-50bc-4361-84e4-d073aca521e0','aos_quotes_modified_user','Users','users','id','AOS_Quotes','aos_quotes','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('87bfa39b-4656-42b0-bddb-5581058f952b','oauthkeys_assigned_user','Users','users','id','OAuthKeys','oauth_consumer','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('87cee358-d4e1-4ab8-b6b4-1f17e7c8e631','aor_charts_modified_user','Users','users','id','AOR_Charts','aor_charts','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('87e4afdd-27af-43e9-b5d1-3ef69cce6d85','prospect_list_users','ProspectLists','prospect_lists','id','Users','users','id','prospect_lists_prospects','prospect_list_id','related_id','many-to-many','related_type','Users',0,0),
('8864e672-7506-433f-8c7d-e2b83774c4e1','emails_tasks_rel','Emails','emails','id','Tasks','tasks','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Tasks',0,0),
('8927e780-1519-47c4-ad2f-23345431b5e5','project_tasks_assigned_user','Users','users','id','ProjectTask','project_task','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('8937ec96-8cda-4c8a-9031-8082058bbe7f','am_tasktemplates_created_by','Users','users','id','AM_TaskTemplates','am_tasktemplates','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('899cf3e3-8b25-4bfd-92c7-20f9fed5bfd4','sugarfeed_modified_user','Users','users','id','SugarFeed','sugarfeed','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('8aba1d9f-f708-4f07-97de-16b2168a0e30','project_contacts_1','Project','project','id','Contacts','contacts','id','project_contacts_1_c','project_contacts_1project_ida','project_contacts_1contacts_idb','many-to-many',NULL,NULL,0,0),
('8b903023-a397-4e1c-8752-f4eccb54636c','contact_leads','Contacts','contacts','id','Leads','leads','contact_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('8c598861-4c0c-4a2e-b478-604a7ca3067f','contact_aos_quotes','Contacts','contacts','id','AOS_Quotes','aos_quotes','billing_contact_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('8cc714f4-b0bd-4a42-9ae1-85198177b9e7','lead_calls','Leads','leads','id','Calls','calls','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Leads',0,0),
('8d6e2445-3b44-47f1-a938-4f9986072a23','oauth2tokens_modified_user','Users','users','id','OAuth2Tokens','oauth2tokens','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('8f235da6-a0ad-410f-a46e-e700572a8978','templatesectionline_created_by','Users','users','id','TemplateSectionLine','templatesectionline','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('8feb93d2-ad3d-4684-9e55-26e42713dd1b','jjwg_maps_jjwg_areas','jjwg_Maps','jjwg_maps','id','jjwg_Areas','jjwg_areas','id','jjwg_maps_jjwg_areas_c','jjwg_maps_5304wg_maps_ida','jjwg_maps_41f2g_areas_idb','many-to-many',NULL,NULL,0,0),
('8fefd2e2-dedc-4cdc-8c86-a03b9c143d75','bug_notes','Bugs','bugs','id','Notes','notes','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Bugs',0,0),
('9074c081-e6de-46b5-8354-6b67813912a1','aor_reports_aor_conditions','AOR_Reports','aor_reports','id','AOR_Conditions','aor_conditions','aor_report_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('911462a1-5374-4632-906d-956a9baf18df','sugarfeed_assigned_user','Users','users','id','SugarFeed','sugarfeed','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('91c75ed8-75c5-40b6-86a7-57f366d63240','securitygroups_tasks','SecurityGroups','securitygroups','id','Tasks','tasks','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Tasks',0,0),
('91da986d-f1ff-41d8-8618-4e51b4f427ad','opportunities_created_by','Users','users','id','Opportunities','opportunities','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('92582be6-cc0f-4886-8ce0-49bea6e67525','calls_assigned_user','Users','users','id','Calls','calls','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('936f89a8-dcb1-4b02-85e3-11641c2d5428','surveyquestionoptions_created_by','Users','users','id','SurveyQuestionOptions','surveyquestionoptions','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('93997659-9d00-4e0a-8088-3eedad59780e','aos_contracts_meetings','AOS_Contracts','aos_contracts','id','Meetings','meetings','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','AOS_Contracts',0,0),
('954f565e-de8b-45ac-8e9a-f24794ce090b','aor_reports_assigned_user','Users','users','id','AOR_Reports','aor_reports','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('95a65d59-77bf-4e28-a683-4997929a9d65','oauth2clients_oauth2authcodes','OAuth2Clients','oauth2clients','id','Oauth2AuthCodes','oauth2authcodes','client',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('95eb5001-67ae-456c-a3a0-4af5cdf1daf7','securitygroups_contacts','SecurityGroups','securitygroups','id','Contacts','contacts','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Contacts',0,0),
('96d2c6c6-73d4-4e00-a427-cb79b45bd0e6','prospect_list_accounts','ProspectLists','prospect_lists','id','Accounts','accounts','id','prospect_lists_prospects','prospect_list_id','related_id','many-to-many','related_type','Accounts',0,0),
('97b55bce-3e3a-42d6-8414-6a4b57ff1489','calendaraccount_created_by','Users','users','id','CalendarAccount','calendar_accounts','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('9811cff2-19f6-45e6-9648-e46c6e393bb1','lead_campaign_log','Leads','leads','id','CampaignLog','campaign_log','target_id',NULL,NULL,NULL,'one-to-many','target_type','Leads',0,0),
('989f4b22-77e3-4d7d-bbc2-4fae88f5eb4e','aos_quotes_aos_product_quotes','AOS_Quotes','aos_quotes','id','AOS_Products_Quotes','aos_products_quotes','parent_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('9a2eadec-a8ed-466a-86e6-3a552d28c54b','contacts_aop_case_updates','Contacts','contacts','id','AOP_Case_Updates','aop_case_updates','contact_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('9b9f93c4-e6c1-4826-8664-9cc01feac9df','consumer_tokens','OAuthKeys','oauth_consumer','id','OAuthTokens','oauth_tokens','consumer',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('9cb7caea-3271-4b43-91d1-b7df7d4d7250','aos_contracts_aos_products_quotes','AOS_Contracts','aos_contracts','id','AOS_Products_Quotes','aos_products_quotes','parent_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('9cc3e91c-71c9-4b06-a671-0adf723637e1','surveyquestions_surveyquestionoptions','SurveyQuestions','surveyquestions','id','SurveyQuestionOptions','surveyquestionoptions','survey_question_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('9d7fd3dd-b2dd-4ea0-a047-c669af6723dd','campaign_modified_user','Users','users','id','Campaigns','campaigns','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('9d959169-56dc-4c54-a5b9-0834025c5870','securitygroups_emailmarketing','SecurityGroups','securitygroups','id','EmailMarketing','email_marketing','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','EmailMarketing',0,0),
('9df65d3d-8934-4175-82f6-ff12235d0d49','accounts_email_addresses_primary','Accounts','accounts','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','primary_address','1',0,0),
('9e91fd85-baa2-4e20-8017-651f22a05558','processes_created_by','Users','users','id','Processes','processes','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('9f04ce82-0845-4d1e-a0d8-fb7337127934','email_outbound_email_accounts','OutboundEmailAccounts','outbound_email','id','Emails','emails','outbound_email_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('9f4dc481-8e41-43aa-8fb7-8de35c14ec61','aow_actions_created_by','Users','users','id','AOW_Actions','aow_actions','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('9f4e3832-81ca-4223-96e2-e29068f2b486','account_campaign_log','Accounts','accounts','id','CampaignLog','campaign_log','target_id',NULL,NULL,NULL,'one-to-many','target_type','Accounts',0,0),
('9fedbceb-363f-4c9e-ba6d-359c168d6237','campaigns_assigned_user','Users','users','id','Campaigns','campaigns','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('a07550bc-f706-414a-a976-7af23eaf09ed','projects_project_tasks','Project','project','id','ProjectTask','project_task','project_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('a0b5bb29-a345-4970-8d39-e30cba53ed21','fp_events_assigned_user','Users','users','id','FP_events','fp_events','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('a13931f1-c641-42af-ab90-826f1495aba3','reminders_invitees_assigned_user','Users','users','id','Reminders_Invitees','reminders_invitees','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('a142f4ff-0720-4a88-a13d-c7ae186ad9ed','prospect_notes','Prospects','prospects','id','Notes','notes','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Prospects',0,0),
('a1e09c06-41ae-4917-916b-2a004b67cb7c','securitygroups_outboundemailaccounts','SecurityGroups','securitygroups','id','OutboundEmailAccounts','outbound_email','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','OutboundEmailAccounts',0,0),
('a28e9bdc-0889-4c2e-bac3-1f1bc95db5de','securitygroups_fp_event_locations','SecurityGroups','securitygroups','id','FP_Event_Locations','fp_event_locations','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','FP_Event_Locations',0,0),
('a3fbd094-d23a-4de1-8a67-10e0ff6b98be','meetings_created_by','Users','users','id','Meetings','meetings','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('a45bf17a-259a-4d89-9949-9e8c379dcd30','prospects_modified_user','Users','users','id','Prospects','prospects','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('a464e2f1-33fd-4e99-a8b9-0fbe39b30c38','aok_knowledgebase_categories','AOK_KnowledgeBase','aok_knowledgebase','id','AOK_Knowledge_Base_Categories','aok_knowledge_base_categories','id','aok_knowledgebase_categories','aok_knowledgebase_id','aok_knowledge_base_categories_id','many-to-many',NULL,NULL,0,0),
('a51a3b38-cb80-40f4-82dd-7aeee3fcc390','aos_invoices_created_by','Users','users','id','AOS_Invoices','aos_invoices','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('a5903728-b4ed-47a9-a718-6d7832939869','prospect_list_prospects','ProspectLists','prospect_lists','id','Prospects','prospects','id','prospect_lists_prospects','prospect_list_id','related_id','many-to-many','related_type','Prospects',0,0),
('a6a144a8-5007-449c-b01c-d236ab34f71b','aop_case_updates_created_by','Users','users','id','AOP_Case_Updates','aop_case_updates','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('a6b153f6-2534-4d8a-83ab-c09e3b659762','projects_opportunities','Project','project','id','Opportunities','opportunities','id','projects_opportunities','project_id','opportunity_id','many-to-many',NULL,NULL,0,0),
('a70a4c59-f2ef-438e-8ac5-22d1b4b8960b','opportunities_modified_user','Users','users','id','Opportunities','opportunities','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('a7831b6f-ca32-4b66-b53e-bde96cdaa15f','aos_product_categories_created_by','Users','users','id','AOS_Product_Categories','aos_product_categories','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('a7a70a39-3bdb-43ef-8f41-61d833ba9135','tasks_created_by','Users','users','id','Tasks','tasks','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('a7bf1004-b87b-4a4d-bd9d-34bd7e35d987','fp_events_leads_1','FP_events','fp_events','id','Leads','leads','id','fp_events_leads_1_c','fp_events_leads_1fp_events_ida','fp_events_leads_1leads_idb','many-to-many',NULL,NULL,0,0),
('a82ac12f-d0e4-4a74-a8da-68d0ee455a54','calls_leads','Calls','calls','id','Leads','leads','id','calls_leads','call_id','lead_id','many-to-many',NULL,NULL,0,0),
('a8b5e78e-60cd-43e9-adab-db662cf24f64','meetings_contacts','Meetings','meetings','id','Contacts','contacts','id','meetings_contacts','meeting_id','contact_id','many-to-many',NULL,NULL,0,0),
('a8f33eb9-73b6-40bf-a29b-161f09daaedf','securitygroups_campaigns','SecurityGroups','securitygroups','id','Campaigns','campaigns','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Campaigns',0,0),
('aa6c4c85-36e8-4e4d-9d70-edd07d8f11b0','accounts_assigned_user','Users','users','id','Accounts','accounts','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('aac6161d-d39a-4f25-839d-a1d681393470','aok_knowledge_base_categories_assigned_user','Users','users','id','AOK_Knowledge_Base_Categories','aok_knowledge_base_categories','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('ab3a54dd-69ed-4813-b0ab-798df02a408a','email_marketing_survey','Surveys','surveys','id','EmailMarketing','email_marketing','survey_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('abfba9b2-9cbb-44f0-b799-c515d435ffac','securitygroups_modified_user','Users','users','id','SecurityGroups','securitygroups','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('acf04daf-dcbe-4293-8ed7-125ae88c7ce3','emails_assigned_user','Users','users','id','Emails','emails','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('adb02ce0-67db-4333-89dd-91cde2c573a4','contact_campaign_log','Contacts','contacts','id','CampaignLog','campaign_log','target_id',NULL,NULL,NULL,'one-to-many','target_type','Contacts',0,0),
('adb5835e-f9a5-4d2e-bdf4-5b1c035477c1','manualmigrationtasks_created_by','Users','users','id','ManualMigrationTasks','manual_migration_tasks','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('adcc6294-87e8-4b54-a80d-16ea4dc3804e','securitygroups_jjwg_areas','SecurityGroups','securitygroups','id','jjwg_Areas','jjwg_areas','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','jjwg_Areas',0,0),
('af193d12-fe43-4a6d-8339-0fd939ed50c2','emails_leads_rel','Emails','emails','id','Leads','leads','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Leads',0,0),
('b10c79bf-5efd-4b58-8998-058e44dc74bf','account_notes','Accounts','accounts','id','Notes','notes','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Accounts',0,0),
('b15f960c-82c1-4120-8aae-82936f644374','fp_event_locations_created_by','Users','users','id','FP_Event_Locations','fp_event_locations','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('b1b982bc-3e48-4e41-992a-e2ddacf1ab06','jjwg_address_cache_modified_user','Users','users','id','jjwg_Address_Cache','jjwg_address_cache','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('b20ef0e3-fdaf-4fb6-9f65-234d914793e5','emails_cases_rel','Emails','emails','id','Cases','cases','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Cases',0,0),
('b2e91a07-aff8-4fae-9e14-b727166a5c3a','campaign_campaignlog','Campaigns','campaigns','id','CampaignLog','campaign_log','campaign_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('b322fb83-14f1-472b-b19f-769de2c3f266','aos_product_categories_modified_user','Users','users','id','AOS_Product_Categories','aos_product_categories','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('b3502693-d134-4bb2-a0f3-655f90c35c27','aor_conditions_created_by','Users','users','id','AOR_Conditions','aor_conditions','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('b3d3bae4-52c4-4cf3-9559-591c5dffbfad','account_aos_invoices','Accounts','accounts','id','AOS_Invoices','aos_invoices','billing_account_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('b435b9bd-6ffb-43ad-8232-8c4c2caa8844','fp_events_fp_event_locations_1','FP_events','fp_events','id','FP_Event_Locations','fp_event_locations','id','fp_events_fp_event_locations_1_c','fp_events_fp_event_locations_1fp_events_ida','fp_events_fp_event_locations_1fp_event_locations_idb','many-to-many',NULL,NULL,0,0),
('b4886b55-1f3d-4e97-a546-75f840609bcf','securitygroups_emailtemplates','SecurityGroups','securitygroups','id','EmailTemplates','email_templates','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','EmailTemplates',0,0),
('b4c5280d-9376-4e9b-87af-d6a4a101baf6','contacts_created_by','Users','users','id','Contacts','contacts','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('b519e9ac-b03e-4dfb-b2dd-5b257dde745e','surveyquestionresponses_modified_user','Users','users','id','SurveyQuestionResponses','surveyquestionresponses','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('b5255e9d-a22c-4490-96c3-a5aeab15d357','aok_knowledgebase_modified_user','Users','users','id','AOK_KnowledgeBase','aok_knowledgebase','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('b57cbb03-4ae0-4c97-ab4c-ad1a6956faf0','meetings_assigned_user','Users','users','id','Meetings','meetings','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('b6e738ec-a6b2-4509-877c-325658375e57','securitygroups_project','SecurityGroups','securitygroups','id','Project','project','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Project',0,0),
('b6ee9937-b9f8-4477-9684-82728e314033','emails_notes_rel','Emails','emails','id','Notes','notes','parent_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('b710e557-16c0-429c-83d1-be96102ae812','projects_assigned_user','Users','users','id','Project','project','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('b852e9a2-5c33-4ad1-8310-482a743b9f69','bugs_fixed_in_release','Releases','releases','id','Bugs','bugs','fixed_in_release',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('b8eebaa6-abdd-4217-9142-725e7cf0f17f','securitygroups_aos_contracts','SecurityGroups','securitygroups','id','AOS_Contracts','aos_contracts','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_Contracts',0,0),
('b96b9dab-fedb-42a6-a85b-2ce9223ab7a1','document_revisions','Documents','documents','id','DocumentRevisions','document_revisions','document_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('b985a23a-95b4-4777-9840-d69e9322634c','cases_assigned_user','Users','users','id','Cases','cases','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('b9b602fd-7323-499f-a596-708e02aa08b2','aos_products_modified_user','Users','users','id','AOS_Products','aos_products','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('b9eed646-de12-483e-adba-75b2b1f384d7','aos_contracts_tasks','AOS_Contracts','aos_contracts','id','Tasks','tasks','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','AOS_Contracts',0,0),
('ba5122a2-78a1-4307-bb9a-9efeb5efcd8b','securitygroups_fp_events','SecurityGroups','securitygroups','id','FP_events','fp_events','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','FP_events',0,0),
('ba932b3b-dcde-413e-bc16-ac897bc06e20','users_users_password_link','Users','users','id',NULL,'users_signatures','user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('bc0e0333-c8d4-4384-996c-d80f90e7b67f','campaign_contacts','Campaigns','campaigns','id','Contacts','contacts','campaign_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('bc17b7ad-e7c9-4718-bb20-a4ce1d55c1fa','inbound_email_created_by','Users','users','id','InboundEmail','inbound_email','created_by',NULL,NULL,NULL,'one-to-one',NULL,NULL,0,0),
('bd4688f1-1c0b-4161-b3e0-0ddc3d3b7894','jjwg_areas_assigned_user','Users','users','id','jjwg_Areas','jjwg_areas','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('be2b3c22-031a-48ba-b095-e84767e54797','jjwg_Maps_projects','jjwg_Maps','jjwg_Maps','parent_id','Project','project','id',NULL,NULL,NULL,'one-to-many','parent_type','Project',0,0),
('be4614ea-cfd4-429f-b2f2-22e7a96d3ebc','aor_scheduled_reports_aor_reports','AOR_Reports','aor_reports','id','AOR_Scheduled_Reports','aor_scheduled_reports','aor_report_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('bf8f7365-cd32-4da6-b497-9cd94b6c0875','surveys_created_by','Users','users','id','Surveys','surveys','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('bfa770f0-458b-40f6-a6ee-4bc67c4b211d','campaigns_created_by','Users','users','id','Campaigns','campaigns','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('bfbf23d3-1d38-42cc-9a44-7a82fa94065c','surveys_surveyresponses','Surveys','surveys','id','SurveyResponses','surveyresponses','survey_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('c0d11559-8519-4fc9-8fd8-506f37935677','externaloauthconnection_modified_user','Users','users','id','ExternalOAuthConnection','external_oauth_connections','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('c113e6a3-b20d-417b-8455-ec5481f35861','contact_aos_contracts','Contacts','contacts','id','AOS_Contracts','aos_contracts','contact_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('c26e7dfe-9d6f-4d16-9f7d-9d0917c58243','securitygroups_created_by','Users','users','id','SecurityGroups','securitygroups','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('c2add01d-8458-4a39-81af-bf53aa8d7731','case_notes','Cases','cases','id','Notes','notes','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Cases',0,0),
('c2cd0514-adc6-45af-b184-1ecf82788bbd','account_tasks','Accounts','accounts','id','Tasks','tasks','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Accounts',0,0),
('c2ec91c7-6680-4f1e-9a3e-4869403e868e','emails_users_rel','Emails','emails','id','Users','users','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Users',0,0),
('c3330f06-b5db-45f4-9dad-3ae31ce9d298','processes_modified_user','Users','users','id','Processes','processes','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('c3a50035-527d-4b7b-9e03-1c57a044c5a6','campaignlog_targeted_users','CampaignLog','campaign_log','target_id','Users','users','id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('c446e45f-2401-46a4-9dd1-d8ce9c2aa40a','fp_event_locations_fp_events_1','FP_Event_Locations','fp_event_locations','id','FP_events','fp_events','id','fp_event_locations_fp_events_1_c','fp_event_locations_fp_events_1fp_event_locations_ida','fp_event_locations_fp_events_1fp_events_idb','many-to-many',NULL,NULL,0,0),
('c4893633-2805-4c90-8848-cd2ed34a0c65','emails_bugs_rel','Emails','emails','id','Bugs','bugs','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Bugs',0,0),
('c4a9c19d-0cdb-4405-865e-b752354f6342','securitygroups_documents','SecurityGroups','securitygroups','id','Documents','documents','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Documents',0,0),
('c57716f8-7054-46b6-b6db-7092c134b973','campaignlog_sent_emails','CampaignLog','campaign_log','related_id','Emails','emails','id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('c5aeb441-bb22-4e25-9221-012b55da4064','project_tasks_created_by','Users','users','id','ProjectTask','project_task','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('c5d5dde1-afa1-465f-a07d-f955aaa625dc','jjwg_Maps_prospects','jjwg_Maps','jjwg_Maps','parent_id','Prospects','prospects','id',NULL,NULL,NULL,'one-to-many','parent_type','Prospects',0,0),
('c6855f78-e2ad-41e6-9ecf-821cf64d1d45','contacts_email_addresses_primary','Contacts','contacts','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','primary_address','1',0,0),
('c75fe789-974b-44fb-93b9-42b47de8ca3f','inbound_emails_distribution_user','Users','users','id','InboundEmail','inbound_email','distribution_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('c764feeb-01ff-4e23-abd3-f4ec9ffd17dc','contact_direct_reports','Contacts','contacts','id','Contacts','contacts','reports_to_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('c7b8b6be-14fd-401f-96bf-19a4788c2695','aor_reports_created_by','Users','users','id','AOR_Reports','aor_reports','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('c969d3a0-8b08-4941-819f-2e46fb21ad18','aos_products_assigned_user','Users','users','id','AOS_Products','aos_products','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('c9752b3a-ad18-4592-8aea-083f8912cb82','aor_fields_created_by','Users','users','id','AOR_Fields','aor_fields','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('ca75fd8d-cddc-4bb0-9168-b676367a61c7','campaign_emailman','Campaigns','campaigns','id','EmailMan','emailman','campaign_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('ca7c7c0f-cabd-4102-8569-8e22f847bab8','aos_pdf_templates_assigned_user','Users','users','id','AOS_PDF_Templates','aos_pdf_templates','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('cb9ebb71-9852-4a89-9204-281afc1b2820','am_tasktemplates_assigned_user','Users','users','id','AM_TaskTemplates','am_tasktemplates','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('cc041560-a41e-482a-8a63-fb91fb518221','accounts_modified_user','Users','users','id','Accounts','accounts','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('cd2b73db-d241-4017-a770-e9bde2522f75','projects_notes','Project','project','id','Notes','notes','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Project',0,0),
('cd50a10d-f9cb-46f9-85ef-46ed5c7272e7','securitygroups_aor_scheduled_reports','SecurityGroups','securitygroups','id','AOR_Scheduled_Reports','aor_scheduled_reports','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOR_Scheduled_Reports',0,0),
('cd9cffa7-0c74-435a-90dd-d7c706cf2e85','emails_prospects_rel','Emails','emails','id','Prospects','prospects','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Prospects',0,0),
('cf3a4bb0-b820-4871-9ff9-3979cfe17f97','outbound_email_owner_user','Users','users','id','OutboundEmailAccounts','outbound_email','user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('cfd7efe7-9eac-43ba-8964-d00bc6a1a8e9','securitygroups_calls','SecurityGroups','securitygroups','id','Calls','calls','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Calls',0,0),
('d0033f89-512e-4282-97a6-111a012a12b2','emails_aos_contracts_rel','Emails','emails','id','AOS_Contracts','aos_contracts','id','emails_beans','email_id','bean_id','many-to-many','bean_module','AOS_Contracts',0,0),
('d09eb958-8339-45d3-a067-7747021ded92','securitygroups_prospectlists','SecurityGroups','securitygroups','id','ProspectLists','prospect_lists','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','ProspectLists',0,0),
('d13bfbde-aace-482c-92bc-23b32874573f','meetings_leads','Meetings','meetings','id','Leads','leads','id','meetings_leads','meeting_id','lead_id','many-to-many',NULL,NULL,0,0),
('d1778dcd-4ea2-4d13-a055-bca39f4241f6','campaign_opportunities','Campaigns','campaigns','id','Opportunities','opportunities','campaign_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('d17fba31-0bb1-4c11-937e-dfd7c0084d5f','surveyresponses_created_by','Users','users','id','SurveyResponses','surveyresponses','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('d22e6ba4-59d1-4947-986c-000c1f09b0b1','cases_aop_case_events','Cases','cases','id','AOP_Case_Events','aop_case_events','case_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('d266fb95-dc3f-48d4-a20b-9e9beca364a2','securitygroups_leads','SecurityGroups','securitygroups','id','Leads','leads','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Leads',0,0),
('d28f930a-9c8c-4c4e-a41a-291a76cac5e7','aow_workflow_aow_actions','AOW_WorkFlow','aow_workflow','id','AOW_Actions','aow_actions','aow_workflow_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('d29b859d-bffc-46a2-ba24-78538af5f0b5','aor_reports_modified_user','Users','users','id','AOR_Reports','aor_reports','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('d2cb67d8-e4f8-40ac-83fa-efc90fcc65cc','prospect_meetings','Prospects','prospects','id','Meetings','meetings','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Prospects',0,0),
('d34d9caa-0cff-42db-a61a-e80817140244','rt_radiocampaigns_modified_user','Users','users','id','RT_RadioCampaigns','rt_radiocampaigns','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('d5ab25f0-0717-48ba-8c0b-f495cc653359','case_emails','Cases','cases','id','Emails','emails','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Cases',0,0),
('d63d7371-5e53-46ff-b392-a9a269ce398b','outbound_email_assigned_user','Users','users','id','OutboundEmailAccounts','outbound_email','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('d6529107-779d-4036-a584-5de5d447f5a8','securitygroups_prospects','SecurityGroups','securitygroups','id','Prospects','prospects','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Prospects',0,0),
('d77d2c07-08d5-49d0-a45c-c1e5420b78ca','surveys_campaigns','Surveys','surveys','id','Campaigns','campaigns','survey_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('d7b1f788-842a-4670-8b0b-b067ecf30397','surveyquestions_surveyquestionresponses','SurveyQuestions','surveyquestions','id','SurveyQuestionResponses','surveyquestionresponses','surveyquestion_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('d7bf47f9-7769-4c66-a3f0-39dbbabfd6db','securitygroups_aos_pdf_templates','SecurityGroups','securitygroups','id','AOS_PDF_Templates','aos_pdf_templates','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_PDF_Templates',0,0),
('d81ac0e3-8aa4-4006-9710-cab262993608','surveys_modified_user','Users','users','id','Surveys','surveys','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('d839856a-175e-43f5-a5de-5c7fbf3a7f44','external_oauth_connections_external_oauth_providers','ExternalOAuthProvider','external_oauth_providers','id','ExternalOAuthConnection','external_oauth_connections','external_oauth_provider_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('d8c602be-eb5b-4786-bfb9-1f7f827941a7','prospect_list_leads','ProspectLists','prospect_lists','id','Leads','leads','id','prospect_lists_prospects','prospect_list_id','related_id','many-to-many','related_type','Leads',0,0),
('d9f790a9-e35c-4608-bf79-84b039e1d0ce','projects_cases','Project','project','id','Cases','cases','id','projects_cases','project_id','case_id','many-to-many',NULL,NULL,0,0),
('da3cc1b7-c8c3-427b-a19c-bc2e5d2baa6a','favorites_created_by','Users','users','id','Favorites','favorites','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('db85fec0-67bb-4459-80aa-36cedda0842f','outbound_email_created_by','Users','users','id','OutboundEmailAccounts','outbound_email','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('dc59b7b9-fb01-4853-bf0e-763765432091','cases_created_contact','Contacts','contacts','id','Cases','cases','contact_created_by_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('dc838d0d-74fc-4d9f-a0ea-7b71f96d3a5d','aow_conditions_modified_user','Users','users','id','AOW_Conditions','aow_conditions','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('dca70d3e-48d2-43f7-a616-4096a1822b1e','opportunity_aos_quotes','Opportunities','opportunities','id','AOS_Quotes','aos_quotes','opportunity_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('dd2204af-b311-4ea6-b6cf-dec091567fd9','lead_emails','Leads','leads','id','Emails','emails','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Leads',0,0),
('ddcebee9-9ea2-49d1-b37a-1d095685b6ce','rt_radiocampaigns_assigned_user','Users','users','id','RT_RadioCampaigns','rt_radiocampaigns','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('de3277bb-fe85-43fb-96fb-7de74b3384e3','surveyquestionoptions_modified_user','Users','users','id','SurveyQuestionOptions','surveyquestionoptions','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('de6f1db7-2d76-4f7e-b236-4c6b4a38e744','email_marketing_campaignlog','EmailMarketing','email_marketing','id','CampaignLog','campaign_log','marketing_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('e0495580-0ecf-4f17-b642-7818d0ac848b','aok_knowledgebase_assigned_user','Users','users','id','AOK_KnowledgeBase','aok_knowledgebase','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('e06e0d5d-f183-43ae-8023-072f54dddb54','calls_users','Calls','calls','id','Users','users','id','calls_users','call_id','user_id','many-to-many',NULL,NULL,0,0),
('e097f228-4343-4c8d-ba8d-94e4a336dc0d','tasks_assigned_user','Users','users','id','Tasks','tasks','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('e0accc40-710c-4dd2-9e26-383a1c390396','calls_reschedule_modified_user','Users','users','id','Calls_Reschedule','calls_reschedule','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('e16bc388-b997-4f08-8449-415f60566eca','unified_search',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0),
('e1ca004b-260b-4db2-ad31-44c813f645ba','jjwg_Maps_contacts','jjwg_Maps','jjwg_Maps','parent_id','Contacts','contacts','id',NULL,NULL,NULL,'one-to-many','parent_type','Contacts',0,0),
('e1db9305-f525-4240-ad1a-4491648251ab','calls_contacts','Calls','calls','id','Contacts','contacts','id','calls_contacts','call_id','contact_id','many-to-many',NULL,NULL,0,0),
('e2250c80-17f6-49a8-bc89-02b0bf8b43fa','manualmigrationtasks_assigned_user','Users','users','id','ManualMigrationTasks','manual_migration_tasks','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('e27d1934-f4f9-401f-9db6-baf4f9d77b5f','projects_bugs','Project','project','id','Bugs','bugs','id','projects_bugs','project_id','bug_id','many-to-many',NULL,NULL,0,0),
('e2987e7a-1ae6-4813-9418-91c752251047','documents_cases','Documents','documents','id','Cases','cases','id','documents_cases','document_id','case_id','many-to-many',NULL,NULL,0,0),
('e2ba70b1-3093-4da8-adfa-140fee11247b','emails_project_task_rel','Emails','emails','id','ProjectTask','project_task','id','emails_beans','email_id','bean_id','many-to-many','bean_module','ProjectTask',0,0),
('e3a8f62d-83a2-4fe9-abff-05fe5c1b9191','aos_invoices_aos_product_quotes','AOS_Invoices','aos_invoices','id','AOS_Products_Quotes','aos_products_quotes','parent_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('e4689711-af14-40d9-9b8b-00739f609642','oauth2clients_oauth2tokens','OAuth2Clients','oauth2clients','id','OAuth2Tokens','oauth2tokens','client',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('e46df0aa-2b07-4f1c-a127-295effef732b','opportunities_assigned_user','Users','users','id','Opportunities','opportunities','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('e572a351-3fe5-4737-afd1-b8909c4d120e','revisions_created_by','Users','users','id','DocumentRevisions','document_revisions','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('e58bbf55-247a-4cfc-bdb2-c63fdff1ab72','documents_opportunities','Documents','documents','id','Opportunities','opportunities','id','documents_opportunities','document_id','opportunity_id','many-to-many',NULL,NULL,0,0),
('e5d44fbd-f4e0-4fef-8fb8-5abd4dc9a7a8','surveyquestions_created_by','Users','users','id','SurveyQuestions','surveyquestions','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('e64c795e-d193-4562-af64-5743f14d73c4','aos_products_quotes_modified_user','Users','users','id','AOS_Products_Quotes','aos_products_quotes','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('e66ad654-8f29-4300-a3ab-10e689656c86','projects_created_by','Users','users','id','Project','project','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('e7622a1a-da34-4844-9eeb-0e41df396c15','projects_modified_user','Users','users','id','Project','project','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('e765a335-a19a-45b8-85ef-34e72e9e3d2c','securitygroups_surveyquestionresponses','SecurityGroups','securitygroups','id','SurveyQuestionResponses','surveyquestionresponses','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','SurveyQuestionResponses',0,0),
('e7690fc1-7f4b-4696-90c4-c441feb36991','inbound_emails_autoreply_email_templates','EmailTemplates','email_templates','id','InboundEmail','inbound_email','template_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('e7eae043-9e6a-4903-bebd-6598319e7e57','projects_calls','Project','project','id','Calls','calls','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Project',0,0),
('e8a161a1-bf22-46f7-a76d-4ba37a305f1b','accounts_bugs','Accounts','accounts','id','Bugs','bugs','id','accounts_bugs','account_id','bug_id','many-to-many',NULL,NULL,0,0),
('e8cc7945-794a-4880-a766-d5573cb69772','calls_created_by','Users','users','id','Calls','calls','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('e8de37f6-d06a-42e5-b4d3-a44e2076a2e7','saved_search_assigned_user','Users','users','id','SavedSearch','saved_search','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('e9eb17c3-75e3-4862-aa5c-69621989e540','securitygroups_surveyresponses','SecurityGroups','securitygroups','id','SurveyResponses','surveyresponses','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','SurveyResponses',0,0),
('ea6839ff-b2ee-46ac-9e57-814bb22adacd','aos_contracts_created_by','Users','users','id','AOS_Contracts','aos_contracts','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('ead5a10d-4320-4f35-ad10-f05d5c3dfb7a','prospect_calls','Prospects','prospects','id','Calls','calls','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Prospects',0,0),
('eb18a76e-5b07-47e1-b58e-7d819f45f7b0','prospect_campaign_log','Prospects','prospects','id','CampaignLog','campaign_log','target_id',NULL,NULL,NULL,'one-to-many','target_type','Prospects',0,0),
('eb51bded-d1c9-48c4-927f-05595ceac76c','groups_aos_product_quotes','AOS_Line_Item_Groups','aos_line_item_groups','id','AOS_Products_Quotes','aos_products_quotes','group_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('ece5eeda-7990-4aee-8c5b-3f5e2f2ea47d','securitygroups_surveys','SecurityGroups','securitygroups','id','Surveys','surveys','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Surveys',0,0),
('ed71de8a-9968-4a4d-84e0-cfa1308a5b75','surveyquestionoptions_assigned_user','Users','users','id','SurveyQuestionOptions','surveyquestionoptions','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('edd53b1f-2962-426f-8022-f305300b047f','notes_assigned_user','Users','users','id','Notes','notes','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('ee8b06c5-8337-439f-92e2-7588c8652024','eapm_modified_user','Users','users','id','EAPM','eapm','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('eea13de8-51e2-482a-988a-b3aa77fd9359','eapm_created_by','Users','users','id','EAPM','eapm','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('eede84d8-55cd-4ac2-9dc9-fa193feb284a','securitygroups_aos_invoices','SecurityGroups','securitygroups','id','AOS_Invoices','aos_invoices','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_Invoices',0,0),
('eefb73e2-3d06-4864-ab6b-3b29b0be4f67','securitygroups_accounts','SecurityGroups','securitygroups','id','Accounts','accounts','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Accounts',0,0),
('efba2726-4b0e-44a0-89b5-7878f06db548','calls_reschedule_created_by','Users','users','id','Calls_Reschedule','calls_reschedule','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('f065c884-b83f-48c5-9743-0031032f7025','jjwg_markers_modified_user','Users','users','id','jjwg_Markers','jjwg_markers','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('f0a57ff4-ee14-4817-87e7-a8c2be4e9dc7','jjwg_address_cache_assigned_user','Users','users','id','jjwg_Address_Cache','jjwg_address_cache','assigned_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('f0d1fea4-6b6c-489b-90a8-8f53f1aca317','jjwg_Maps_accounts','jjwg_Maps','jjwg_Maps','parent_id','Accounts','accounts','id',NULL,NULL,NULL,'one-to-many','parent_type','Accounts',0,0),
('f1a6ddab-b0da-4c74-a633-bf52a89176be','aok_knowledgebase_created_by','Users','users','id','AOK_KnowledgeBase','aok_knowledgebase','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('f22a5c93-32a8-4c66-9138-a2cf32c86063','user_direct_reports','Users','users','id','Users','users','reports_to_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('f34d2eac-b5eb-4ed7-9b4e-3ac9657599ff','contacts_cases','Contacts','contacts','id','Cases','cases','id','contacts_cases','contact_id','case_id','many-to-many',NULL,NULL,0,0),
('f3731d98-007c-48a3-9eb5-2b1f7d380b28','oauth2clients_created_by','Users','users','id','OAuth2Clients','oauth2clients','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('f39e67db-9f45-466a-b907-6af17f8aa013','outbound_email_modified_user','Users','users','id','OutboundEmailAccounts','outbound_email','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('f4ba1ced-4745-4a0b-80eb-2a0ab9478ff3','am_projecttemplates_users_1','AM_ProjectTemplates','am_projecttemplates','id','Users','users','id','am_projecttemplates_users_1_c','am_projecttemplates_ida','users_idb','many-to-many',NULL,NULL,0,0),
('f5befab8-9b62-4d78-b563-193e56da456e','meetings_users','Meetings','meetings','id','Users','users','id','meetings_users','meeting_id','user_id','many-to-many',NULL,NULL,0,0),
('f61d3da0-b3ca-4fc5-8bca-094faac06a89','securitygroups_jjwg_maps','SecurityGroups','securitygroups','id','jjwg_Maps','jjwg_maps','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','jjwg_Maps',0,0),
('f88f827f-2a33-4216-8b2c-bebf7fa42848','opportunity_tasks','Opportunities','opportunities','id','Tasks','tasks','parent_id',NULL,NULL,NULL,'one-to-many','parent_type','Opportunities',0,0),
('f89030b5-8930-467a-9720-8b1d48f531a4','email_marketing_emailman','EmailMarketing','email_marketing','id','EmailMan','emailman','marketing_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('f937a6b2-b46e-45d5-a4dd-0a22a3d0bdcf','contacts_modified_user','Users','users','id','Contacts','contacts','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('f9568a2d-727e-41bb-90d9-e454ed7d797d','leads_email_addresses','Leads','leads','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','bean_module','Leads',0,0),
('f96190c1-587f-42b9-955a-8c4191a831a1','notes_modified_user','Users','users','id','Notes','notes','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('fa88bbbc-3ac6-43e8-af91-ceeacfb7eaeb','securitygroups_surveyquestionoptions','SecurityGroups','securitygroups','id','SurveyQuestionOptions','surveyquestionoptions','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','SurveyQuestionOptions',0,0),
('fd5b79a1-7f40-4b3a-a5ff-e7f5c942c4e4','aor_scheduled_reports_created_by','Users','users','id','AOR_Scheduled_Reports','aor_scheduled_reports','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('fd6bdba8-ec3a-4f81-927b-8ec12cbb8011','surveyquestions_modified_user','Users','users','id','SurveyQuestions','surveyquestions','modified_user_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('fd7c3148-ecb4-459d-81bb-6f191af96f30','inbound_email_modified_user_id','Users','users','id','InboundEmail','inbound_email','modified_user_id',NULL,NULL,NULL,'one-to-one',NULL,NULL,0,0),
('fe22a08f-1335-4aab-9293-345ef87c7700','oauthkeys_created_by','Users','users','id','OAuthKeys','oauth_consumer','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('fe32905c-f2b3-497b-bec4-d106c8d60b02','prospect_list_campaigns','ProspectLists','prospect_lists','id','Campaigns','campaigns','id','prospect_list_campaigns','prospect_list_id','campaign_id','many-to-many',NULL,NULL,0,0),
('ff1432a1-731a-4f22-97b2-1ddee7ded097','prospects_created_by','Users','users','id','Prospects','prospects','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('ff364ae3-2246-4b5c-ad5a-1a3deda633fc','campaign_leads','Campaigns','campaigns','id','Leads','leads','campaign_id',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0),
('ffe9db7a-4aa8-4e89-9eeb-b4b9016785b2','aow_conditions_created_by','Users','users','id','AOW_Conditions','aow_conditions','created_by',NULL,NULL,NULL,'one-to-many',NULL,NULL,0,0);
/*!40000 ALTER TABLE `relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `releases`
--

DROP TABLE IF EXISTS `releases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `releases` (
  `id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `list_order` int(4) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_releases` (`name`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `releases`
--

LOCK TABLES `releases` WRITE;
/*!40000 ALTER TABLE `releases` DISABLE KEYS */;
/*!40000 ALTER TABLE `releases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reminders`
--

DROP TABLE IF EXISTS `reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reminders` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `popup` tinyint(1) DEFAULT NULL,
  `email` tinyint(1) DEFAULT NULL,
  `email_sent` tinyint(1) DEFAULT NULL,
  `timer_popup` varchar(32) DEFAULT NULL,
  `timer_email` varchar(32) DEFAULT NULL,
  `related_event_module` varchar(32) DEFAULT NULL,
  `related_event_module_id` char(36) NOT NULL,
  `date_willexecute` int(60) DEFAULT -1,
  `popup_viewed` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_reminder_name` (`name`),
  KEY `idx_reminder_deleted` (`deleted`),
  KEY `idx_reminder_related_event_module` (`related_event_module`),
  KEY `idx_reminder_related_event_module_id` (`related_event_module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reminders`
--

LOCK TABLES `reminders` WRITE;
/*!40000 ALTER TABLE `reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reminders_invitees`
--

DROP TABLE IF EXISTS `reminders_invitees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reminders_invitees` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `reminder_id` char(36) NOT NULL,
  `related_invitee_module` varchar(32) DEFAULT NULL,
  `related_invitee_module_id` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reminder_invitee_name` (`name`),
  KEY `idx_reminder_invitee_assigned_user_id` (`assigned_user_id`),
  KEY `idx_reminder_invitee_reminder_id` (`reminder_id`),
  KEY `idx_reminder_invitee_related_invitee_module` (`related_invitee_module`),
  KEY `idx_reminder_invitee_related_invitee_module_id` (`related_invitee_module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reminders_invitees`
--

LOCK TABLES `reminders_invitees` WRITE;
/*!40000 ALTER TABLE `reminders_invitees` DISABLE KEYS */;
/*!40000 ALTER TABLE `reminders_invitees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `modules` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_role_id_del` (`id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_modules`
--

DROP TABLE IF EXISTS `roles_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles_modules` (
  `id` varchar(36) NOT NULL,
  `role_id` varchar(36) DEFAULT NULL,
  `module_id` varchar(36) DEFAULT NULL,
  `allow` tinyint(1) DEFAULT 0,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_role_id` (`role_id`),
  KEY `idx_module_id` (`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_modules`
--

LOCK TABLES `roles_modules` WRITE;
/*!40000 ALTER TABLE `roles_modules` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_users`
--

DROP TABLE IF EXISTS `roles_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles_users` (
  `id` varchar(36) NOT NULL,
  `role_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_ru_role_id` (`role_id`),
  KEY `idx_ru_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_users`
--

LOCK TABLES `roles_users` WRITE;
/*!40000 ALTER TABLE `roles_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rt_radiocampaign_plays`
--

DROP TABLE IF EXISTS `rt_radiocampaign_plays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rt_radiocampaign_plays` (
  `id` char(36) NOT NULL,
  `campaign_id` char(36) NOT NULL,
  `scheduled_time` datetime DEFAULT NULL,
  `actual_time` datetime DEFAULT NULL,
  `cart_number` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Aired',
  `spot_length` varchar(50) DEFAULT '30 sec',
  `log_source` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_play_camp` (`campaign_id`,`deleted`),
  KEY `idx_play_actual` (`actual_time`,`deleted`),
  KEY `idx_play_cart` (`cart_number`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rt_radiocampaign_plays`
--

LOCK TABLES `rt_radiocampaign_plays` WRITE;
/*!40000 ALTER TABLE `rt_radiocampaign_plays` DISABLE KEYS */;
/*!40000 ALTER TABLE `rt_radiocampaign_plays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rt_radiocampaigns`
--

DROP TABLE IF EXISTS `rt_radiocampaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rt_radiocampaigns` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `number_of_spots` int(11) DEFAULT 0,
  `spot_length` varchar(100) DEFAULT '30 sec',
  `status` varchar(100) DEFAULT 'Draft',
  `myriad_cart_number` varchar(255) DEFAULT NULL,
  `quote_reference` varchar(255) DEFAULT NULL,
  `linked_quote_id` varchar(36) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `file_mime_type` varchar(100) DEFAULT NULL,
  `industry_category` varchar(100) DEFAULT 'other',
  `reconciled_spots` int(11) DEFAULT 0,
  `missed_spots` int(11) DEFAULT 0,
  `reconciliation_status` varchar(50) DEFAULT 'Pending',
  `script_text` text DEFAULT NULL,
  `voice_talent` varchar(255) DEFAULT NULL,
  `production_status` varchar(50) DEFAULT 'Draft',
  `client_approval_token` varchar(64) DEFAULT NULL,
  `client_approved_at` datetime DEFAULT NULL,
  `client_feedback` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rt_rc_del_name` (`deleted`,`name`),
  KEY `idx_rt_rc_linked_quote` (`linked_quote_id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rt_radiocampaigns`
--

LOCK TABLES `rt_radiocampaigns` WRITE;
/*!40000 ALTER TABLE `rt_radiocampaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `rt_radiocampaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rt_radiocampaigns_aos_quotes_c`
--

DROP TABLE IF EXISTS `rt_radiocampaigns_aos_quotes_c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rt_radiocampaigns_aos_quotes_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `rt_radiocampaigns_aos_quotesrt_radiocampaigns_ida` varchar(36) DEFAULT NULL,
  `rt_radiocampaigns_aos_quotesaos_quotes_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rt_radiocampaigns_aos_quotes_alt` (`rt_radiocampaigns_aos_quotesrt_radiocampaigns_ida`,`rt_radiocampaigns_aos_quotesaos_quotes_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rt_radiocampaigns_aos_quotes_c`
--

LOCK TABLES `rt_radiocampaigns_aos_quotes_c` WRITE;
/*!40000 ALTER TABLE `rt_radiocampaigns_aos_quotes_c` DISABLE KEYS */;
/*!40000 ALTER TABLE `rt_radiocampaigns_aos_quotes_c` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rt_radiocampaigns_audit`
--

DROP TABLE IF EXISTS `rt_radiocampaigns_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rt_radiocampaigns_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rt_radiocampaigns_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rt_radiocampaigns_audit`
--

LOCK TABLES `rt_radiocampaigns_audit` WRITE;
/*!40000 ALTER TABLE `rt_radiocampaigns_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `rt_radiocampaigns_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rt_radiocampaigns_cstm`
--

DROP TABLE IF EXISTS `rt_radiocampaigns_cstm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rt_radiocampaigns_cstm` (
  `id_c` char(36) NOT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rt_radiocampaigns_cstm`
--

LOCK TABLES `rt_radiocampaigns_cstm` WRITE;
/*!40000 ALTER TABLE `rt_radiocampaigns_cstm` DISABLE KEYS */;
/*!40000 ALTER TABLE `rt_radiocampaigns_cstm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saved_search`
--

DROP TABLE IF EXISTS `saved_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `saved_search` (
  `id` char(36) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `search_module` varchar(150) DEFAULT NULL,
  `quick_filter` tinyint(1) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `contents` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_desc` (`name`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saved_search`
--

LOCK TABLES `saved_search` WRITE;
/*!40000 ALTER TABLE `saved_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `saved_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedulers`
--

DROP TABLE IF EXISTS `schedulers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedulers` (
  `id` varchar(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `job` varchar(255) DEFAULT NULL,
  `date_time_start` datetime DEFAULT NULL,
  `date_time_end` datetime DEFAULT NULL,
  `job_interval` varchar(100) DEFAULT NULL,
  `time_from` time DEFAULT NULL,
  `time_to` time DEFAULT NULL,
  `last_run` datetime DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `catch_up` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_schedule` (`date_time_start`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedulers`
--

LOCK TABLES `schedulers` WRITE;
/*!40000 ALTER TABLE `schedulers` DISABLE KEYS */;
INSERT INTO `schedulers` VALUES
('08a687d9-b91e-4564-a2af-c0e68f0d5643',0,'2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','Send Campaign Emails','scheduler::send-from-queue','2015-01-01 07:30:01',NULL,'*::*::*::*::*',NULL,NULL,NULL,'Active',0),
('1c18abc2-800f-4733-b8d3-fc9d6dcdce10',0,'2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','Clean Jobs Queue','function::cleanJobQueue','2015-01-01 17:30:01',NULL,'0::5::*::*::*',NULL,NULL,NULL,'Active',0),
('4df18b75-04c0-41d4-87b2-f9999d963bee',0,'2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','Calendar Accounts Sync','function::calendarSyncJob','2015-01-01 06:30:01',NULL,'*/15::*::*::*::*',NULL,NULL,NULL,'Active',0),
('66c22364-7fe0-4c93-ba3a-920b54b7d1ec',0,'2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','Removal of documents from filesystem','function::removeDocumentsFromFS','2015-01-01 15:30:01',NULL,'0::3::1::*::*',NULL,NULL,NULL,'Active',0),
('6a0efe68-22dd-4542-8d18-b6a3768ce50b',0,'2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','Check Inbound Mailboxes','function::pollMonitoredInboxesAOP','2015-01-01 14:45:01',NULL,'*::*::*::*::*',NULL,NULL,NULL,'Active',0),
('700f9ce3-6ead-4ffe-bbbf-29b0661c93b3',0,'2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','Prune Database on 1st of Month','scheduler::prune-database','2015-01-01 09:30:01',NULL,'0::4::1::*::*',NULL,NULL,NULL,'Inactive',0),
('772ea780-cbef-4f4c-8875-7c1aedda6403',0,'2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','Prune Tracker Tables','function::trimTracker','2015-01-01 13:30:01',NULL,'0::2::1::*::*',NULL,NULL,NULL,'Active',1),
('8f9839db-6025-4c54-969e-2d4048bfb4cf',0,'2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','Prune SuiteCRM Feed Tables','function::trimSugarFeeds','2015-01-01 14:30:01',NULL,'0::2::1::*::*',NULL,NULL,NULL,'Active',1),
('a15aef21-84b0-4b1b-86e4-6117ad7a31a0',0,'2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','Process Workflow Tasks','function::processAOW_Workflow','2015-01-01 08:30:01',NULL,'*::*::*::*::*',NULL,NULL,NULL,'Active',1),
('a64a187a-e6be-4377-8dbe-ea8e9ac46031',0,'2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','Queue Campaign Emails','scheduler::email-to-queue','2015-01-01 08:45:01',NULL,'*::*::*::*::*',NULL,NULL,NULL,'Active',0),
('b37be349-c5ed-4022-9aef-a9e5107163d7',0,'2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','Clean Up Temporary Files','scheduler::clean-up-temporary-files','2015-01-01 16:30:01',NULL,'*::*::*::*::*',NULL,NULL,NULL,'Active',0),
('b3a3dada-4be8-4927-a7cc-503322fc64c8',0,'2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','Run Email Reminder Notifications','function::sendEmailReminders','2015-01-01 10:45:01',NULL,'*::*::*::*::*',NULL,NULL,NULL,'Active',0),
('cbab4358-5587-4f23-a16a-9e5ad80de5e0',0,'2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','Perform Elasticsearch Index','function::runElasticSearchIndexerScheduler','2015-01-01 15:45:01',NULL,'30::4::*::*::*',NULL,NULL,NULL,'Active',0),
('f1829a94-cd21-4afc-bcf0-9bf90a2c26e0',0,'2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','Run Nightly Mass Email Campaigns','function::runMassEmailCampaign','2015-01-01 06:15:01',NULL,'0::2-6::*::*::*',NULL,NULL,NULL,'Inactive',1),
('f9b55947-0682-4606-9b21-ce5b44fb7d90',0,'2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','Run Report Generation Scheduled Tasks','function::aorRunScheduledReports','2015-01-01 18:45:01',NULL,'*::*::*::*::*',NULL,NULL,NULL,'Active',1),
('fd571775-220d-47a2-bed0-975cfa264635',0,'2026-10-16 10:57:58','2026-10-16 10:57:58','1','1','Run Nightly Process Bounced Campaign Emails','function::pollMonitoredInboxesForBouncedCampaignEmails','2015-01-01 08:15:01',NULL,'0::2-6::*::*::*',NULL,NULL,NULL,'Active',1);
/*!40000 ALTER TABLE `schedulers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `securitygroups`
--

DROP TABLE IF EXISTS `securitygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `securitygroups` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `noninheritable` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `securitygroups`
--

LOCK TABLES `securitygroups` WRITE;
/*!40000 ALTER TABLE `securitygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `securitygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `securitygroups_acl_roles`
--

DROP TABLE IF EXISTS `securitygroups_acl_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `securitygroups_acl_roles` (
  `id` char(36) NOT NULL,
  `securitygroup_id` char(36) DEFAULT NULL,
  `role_id` char(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `securitygroups_acl_roles`
--

LOCK TABLES `securitygroups_acl_roles` WRITE;
/*!40000 ALTER TABLE `securitygroups_acl_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `securitygroups_acl_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `securitygroups_audit`
--

DROP TABLE IF EXISTS `securitygroups_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `securitygroups_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_securitygroups_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `securitygroups_audit`
--

LOCK TABLES `securitygroups_audit` WRITE;
/*!40000 ALTER TABLE `securitygroups_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `securitygroups_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `securitygroups_default`
--

DROP TABLE IF EXISTS `securitygroups_default`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `securitygroups_default` (
  `id` char(36) NOT NULL,
  `securitygroup_id` char(36) DEFAULT NULL,
  `module` varchar(50) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `securitygroups_default`
--

LOCK TABLES `securitygroups_default` WRITE;
/*!40000 ALTER TABLE `securitygroups_default` DISABLE KEYS */;
/*!40000 ALTER TABLE `securitygroups_default` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `securitygroups_records`
--

DROP TABLE IF EXISTS `securitygroups_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `securitygroups_records` (
  `id` char(36) NOT NULL,
  `securitygroup_id` char(36) DEFAULT NULL,
  `record_id` char(36) DEFAULT NULL,
  `module` varchar(100) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_securitygroups_records_mod` (`module`,`deleted`,`record_id`,`securitygroup_id`),
  KEY `idx_securitygroups_records_del` (`deleted`,`record_id`,`module`,`securitygroup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `securitygroups_records`
--

LOCK TABLES `securitygroups_records` WRITE;
/*!40000 ALTER TABLE `securitygroups_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `securitygroups_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `securitygroups_users`
--

DROP TABLE IF EXISTS `securitygroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `securitygroups_users` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `securitygroup_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `primary_group` tinyint(1) DEFAULT NULL,
  `noninheritable` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `securitygroups_users_idxa` (`securitygroup_id`),
  KEY `securitygroups_users_idxb` (`user_id`),
  KEY `securitygroups_users_idxc` (`user_id`,`deleted`,`securitygroup_id`,`id`),
  KEY `securitygroups_users_idxd` (`user_id`,`deleted`,`securitygroup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `securitygroups_users`
--

LOCK TABLES `securitygroups_users` WRITE;
/*!40000 ALTER TABLE `securitygroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `securitygroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sugarfeed`
--

DROP TABLE IF EXISTS `sugarfeed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sugarfeed` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `related_module` varchar(100) DEFAULT NULL,
  `related_id` char(36) DEFAULT NULL,
  `link_url` varchar(255) DEFAULT NULL,
  `link_type` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sgrfeed_date` (`date_entered`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sugarfeed`
--

LOCK TABLES `sugarfeed` WRITE;
/*!40000 ALTER TABLE `sugarfeed` DISABLE KEYS */;
/*!40000 ALTER TABLE `sugarfeed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveyquestionoptions`
--

DROP TABLE IF EXISTS `surveyquestionoptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveyquestionoptions` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `sort_order` int(255) DEFAULT NULL,
  `survey_question_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveyquestionoptions`
--

LOCK TABLES `surveyquestionoptions` WRITE;
/*!40000 ALTER TABLE `surveyquestionoptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveyquestionoptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveyquestionoptions_audit`
--

DROP TABLE IF EXISTS `surveyquestionoptions_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveyquestionoptions_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_surveyquestionoptions_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveyquestionoptions_audit`
--

LOCK TABLES `surveyquestionoptions_audit` WRITE;
/*!40000 ALTER TABLE `surveyquestionoptions_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveyquestionoptions_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveyquestionoptions_surveyquestionresponses`
--

DROP TABLE IF EXISTS `surveyquestionoptions_surveyquestionresponses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveyquestionoptions_surveyquestionresponses` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `surveyq72c7options_ida` varchar(36) DEFAULT NULL,
  `surveyq10d4sponses_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `surveyquestionoptions_surveyquestionresponses_alt` (`surveyq72c7options_ida`,`surveyq10d4sponses_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveyquestionoptions_surveyquestionresponses`
--

LOCK TABLES `surveyquestionoptions_surveyquestionresponses` WRITE;
/*!40000 ALTER TABLE `surveyquestionoptions_surveyquestionresponses` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveyquestionoptions_surveyquestionresponses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveyquestionresponses`
--

DROP TABLE IF EXISTS `surveyquestionresponses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveyquestionresponses` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `answer` text DEFAULT NULL,
  `answer_bool` tinyint(1) DEFAULT NULL,
  `answer_datetime` datetime DEFAULT NULL,
  `surveyquestion_id` char(36) DEFAULT NULL,
  `surveyresponse_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveyquestionresponses`
--

LOCK TABLES `surveyquestionresponses` WRITE;
/*!40000 ALTER TABLE `surveyquestionresponses` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveyquestionresponses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveyquestionresponses_audit`
--

DROP TABLE IF EXISTS `surveyquestionresponses_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveyquestionresponses_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_surveyquestionresponses_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveyquestionresponses_audit`
--

LOCK TABLES `surveyquestionresponses_audit` WRITE;
/*!40000 ALTER TABLE `surveyquestionresponses_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveyquestionresponses_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveyquestions`
--

DROP TABLE IF EXISTS `surveyquestions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveyquestions` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `sort_order` int(255) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `happiness_question` tinyint(1) DEFAULT NULL,
  `survey_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveyquestions`
--

LOCK TABLES `surveyquestions` WRITE;
/*!40000 ALTER TABLE `surveyquestions` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveyquestions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveyquestions_audit`
--

DROP TABLE IF EXISTS `surveyquestions_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveyquestions_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_surveyquestions_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveyquestions_audit`
--

LOCK TABLES `surveyquestions_audit` WRITE;
/*!40000 ALTER TABLE `surveyquestions_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveyquestions_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveyresponses`
--

DROP TABLE IF EXISTS `surveyresponses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveyresponses` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `happiness` int(11) DEFAULT NULL,
  `email_response_sent` tinyint(1) DEFAULT NULL,
  `account_id` char(36) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `survey_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveyresponses`
--

LOCK TABLES `surveyresponses` WRITE;
/*!40000 ALTER TABLE `surveyresponses` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveyresponses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveyresponses_audit`
--

DROP TABLE IF EXISTS `surveyresponses_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveyresponses_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_surveyresponses_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveyresponses_audit`
--

LOCK TABLES `surveyresponses_audit` WRITE;
/*!40000 ALTER TABLE `surveyresponses_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveyresponses_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveys`
--

DROP TABLE IF EXISTS `surveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveys` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'LBL_DRAFT',
  `submit_text` varchar(255) DEFAULT 'Submit',
  `satisfied_text` varchar(255) DEFAULT 'Satisfied',
  `neither_text` varchar(255) DEFAULT 'Neither Satisfied nor Dissatisfied',
  `dissatisfied_text` varchar(255) DEFAULT 'Dissatisfied',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveys`
--

LOCK TABLES `surveys` WRITE;
/*!40000 ALTER TABLE `surveys` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveys_audit`
--

DROP TABLE IF EXISTS `surveys_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveys_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text DEFAULT NULL,
  `after_value_text` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_surveys_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveys_audit`
--

LOCK TABLES `surveys_audit` WRITE;
/*!40000 ALTER TABLE `surveys_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveys_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` char(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assigned_user_id` char(36) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Not Started',
  `date_due_flag` tinyint(1) DEFAULT 0,
  `date_due` datetime DEFAULT NULL,
  `date_start_flag` tinyint(1) DEFAULT 0,
  `date_start` datetime DEFAULT NULL,
  `parent_type` varchar(255) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `priority` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tsk_name` (`name`),
  KEY `idx_task_con_del` (`contact_id`,`deleted`),
  KEY `idx_task_par_del` (`parent_id`,`parent_type`,`deleted`),
  KEY `idx_task_assigned` (`assigned_user_id`),
  KEY `idx_task_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `templatesectionline`
--

DROP TABLE IF EXISTS `templatesectionline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `templatesectionline` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `thumbnail` varchar(255) DEFAULT NULL,
  `grp` varchar(255) DEFAULT NULL,
  `ord` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templatesectionline`
--

LOCK TABLES `templatesectionline` WRITE;
/*!40000 ALTER TABLE `templatesectionline` DISABLE KEYS */;
/*!40000 ALTER TABLE `templatesectionline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tracker`
--

DROP TABLE IF EXISTS `tracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tracker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `monitor_id` char(36) NOT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `module_name` varchar(255) DEFAULT NULL,
  `item_id` varchar(36) DEFAULT NULL,
  `item_summary` varchar(255) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `session_id` varchar(36) DEFAULT NULL,
  `visible` tinyint(1) DEFAULT 0,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_tracker_iid` (`item_id`),
  KEY `idx_tracker_userid_vis_id` (`user_id`,`visible`,`id`),
  KEY `idx_tracker_userid_itemid_vis` (`user_id`,`item_id`,`visible`),
  KEY `idx_tracker_monitor_id` (`monitor_id`),
  KEY `idx_tracker_date_modified` (`date_modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tracker`
--

LOCK TABLES `tracker` WRITE;
/*!40000 ALTER TABLE `tracker` DISABLE KEYS */;
/*!40000 ALTER TABLE `tracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `upgrade_history`
--

DROP TABLE IF EXISTS `upgrade_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `upgrade_history` (
  `id` char(36) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `md5sum` varchar(32) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `version` varchar(64) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `id_name` varchar(255) DEFAULT NULL,
  `manifest` longtext DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `upgrade_history_md5_uk` (`md5sum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `upgrade_history`
--

LOCK TABLES `upgrade_history` WRITE;
/*!40000 ALTER TABLE `upgrade_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `upgrade_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_preferences`
--

DROP TABLE IF EXISTS `user_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_preferences` (
  `id` char(36) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `contents` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_userprefnamecat` (`assigned_user_id`,`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_preferences`
--

LOCK TABLES `user_preferences` WRITE;
/*!40000 ALTER TABLE `user_preferences` DISABLE KEYS */;
INSERT INTO `user_preferences` VALUES
('21b1e01f-77e3-4d33-abdd-17d1898ae656','OAuthKeys2_OAUTHKEY',0,'2026-10-18 19:04:08','2026-10-18 19:04:08','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('45d4e2ab-8205-4102-b901-bbcf783893c3','Home2_ACCOUNT',0,'2026-10-16 17:41:52','2026-10-19 20:02:12','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('4a543ef9-e0c9-4b9e-b1a8-bce810c32bbc','Home2_LEAD',0,'2026-10-16 17:41:52','2026-10-19 20:02:12','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('4d259ce1-99d7-4051-8954-d9eaac3ddd52','Home2_MEETING',0,'2026-10-16 17:41:52','2026-10-16 17:41:52','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('526444ce-61f0-49c2-9291-6cd962378224','AOS_Quotes:Other',0,'2026-10-19 13:37:22','2026-10-19 13:37:22','1','YTowOnt9'),
('59cefd4d-6030-4df5-aceb-533c058a3d09','Home2_CALL',0,'2026-10-16 17:41:52','2026-10-16 17:41:52','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('5dacd0fa-cc94-4a8a-b738-17773d73b999','Home2_LEAD_60c1009d-3b54-47e3-9594-3195ed3329b2',0,'2026-10-16 17:41:54','2026-10-19 20:02:12','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('6a946bc9-d3e7-4940-bcf0-22739b42bc45','OAuth2Clients2_OAUTH2CLIENTS',0,'2026-10-18 19:03:56','2026-10-18 19:03:56','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('6ace228a-6326-475f-b0c9-13a8d8eb3e6f','Dashboard',0,'2026-10-18 19:27:38','2026-10-19 20:02:12','1','YTowOnt9'),
('6b11a822-fb7f-4172-937b-fd0ac81606c2','RT_RadioCampaigns2_RT_RADIOCAMPAIGNS',0,'2026-10-19 20:02:34','2026-10-19 20:02:34','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('8f44678a-6dbd-4bde-8140-535d49b9a4d0','Home2_OPPORTUNITY',0,'2026-10-16 17:41:52','2026-10-16 17:41:52','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('a558d400-967b-4d58-bea1-a930416e19bb','Opportunities2_OPPORTUNITY',0,'2026-10-18 18:53:18','2026-10-18 20:04:44','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('ab88df2a-1c90-4492-9d19-4c96da332dc4','AOS_Quotes:Collaboration',0,'2026-10-19 13:37:22','2026-10-19 13:37:22','1','YTowOnt9'),
('b719ea4f-df13-4124-b2e1-bf9427fc3d7a','Emails',0,'2026-10-18 19:27:38','2026-10-20 16:02:18','1','YTowOnt9'),
('d1b09651-6b8b-4f00-9f4b-5debf0376e04','AOS_Quotes',0,'2026-10-19 13:37:22','2026-10-19 13:37:22','1','YTowOnt9'),
('d735a98d-96c9-40bf-be01-86b4c0d5437f','AOS_Quotes2_AOS_QUOTES',0,'2026-10-18 19:27:18','2026-10-18 19:27:38','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('d765429e-dae2-458d-be52-5b79978c86db','Home',0,'2026-10-16 17:41:52','2026-10-19 20:02:12','1','YToyOntzOjg6ImRhc2hsZXRzIjthOjQ6e3M6MzY6Ijc2OTBjNDljLWZlMmYtNDEzNi05MTRhLTU1N2YwYjIwMGEwMyI7YTo1OntzOjk6ImNsYXNzTmFtZSI7czoxNzoiTXlBY2NvdW50c0Rhc2hsZXQiO3M6NjoibW9kdWxlIjtzOjg6IkFjY291bnRzIjtzOjExOiJmb3JjZUNvbHVtbiI7aTowO3M6MTI6ImZpbGVMb2NhdGlvbiI7czo2NToibW9kdWxlcy9BY2NvdW50cy9EYXNobGV0cy9NeUFjY291bnRzRGFzaGxldC9NeUFjY291bnRzRGFzaGxldC5waHAiO3M6Nzoib3B0aW9ucyI7YTowOnt9fXM6MzY6IjYwYzEwMDlkLTNiNTQtNDdlMy05NTk0LTMxOTVlZDMzMjliMiI7YTo1OntzOjk6ImNsYXNzTmFtZSI7czoxNDoiTXlMZWFkc0Rhc2hsZXQiO3M6NjoibW9kdWxlIjtzOjU6IkxlYWRzIjtzOjExOiJmb3JjZUNvbHVtbiI7aTowO3M6MTI6ImZpbGVMb2NhdGlvbiI7czo1NjoibW9kdWxlcy9MZWFkcy9EYXNobGV0cy9NeUxlYWRzRGFzaGxldC9NeUxlYWRzRGFzaGxldC5waHAiO3M6Nzoib3B0aW9ucyI7YTowOnt9fXM6MzY6IjNmNGJkNjQzLTZmMzctNDQ1MS1iYzQ0LWNkODRkOWViNTU2NyI7YTo0OntzOjk6ImNsYXNzTmFtZSI7czoyMToiT3V0Y29tZUJ5TW9udGhEYXNobGV0IjtzOjY6Im1vZHVsZSI7czoxMzoiT3Bwb3J0dW5pdGllcyI7czo3OiJvcHRpb25zIjthOjA6e31zOjEyOiJmaWxlTG9jYXRpb24iO3M6NzE6Im1vZHVsZXMvQ2hhcnRzL0Rhc2hsZXRzL091dGNvbWVCeU1vbnRoRGFzaGxldC9PdXRjb21lQnlNb250aERhc2hsZXQucGhwIjt9czozNjoiOWQzYzJiMTAtOTIxOC00MGE5LTg1MjktMzA5NDhmZDAxYWNmIjthOjQ6e3M6OToiY2xhc3NOYW1lIjtzOjIxOiJPdXRjb21lQnlNb250aERhc2hsZXQiO3M6NjoibW9kdWxlIjtzOjEzOiJPcHBvcnR1bml0aWVzIjtzOjc6Im9wdGlvbnMiO2E6MDp7fXM6MTI6ImZpbGVMb2NhdGlvbiI7czo3MToibW9kdWxlcy9DaGFydHMvRGFzaGxldHMvT3V0Y29tZUJ5TW9udGhEYXNobGV0L091dGNvbWVCeU1vbnRoRGFzaGxldC5waHAiO319czo1OiJwYWdlcyI7YToxOntpOjA7YTozOntzOjc6ImNvbHVtbnMiO2E6Mjp7aTowO2E6Mjp7czo1OiJ3aWR0aCI7czozOiI2MCUiO3M6ODoiZGFzaGxldHMiO2E6Mzp7aToxO3M6MzY6IjNmNGJkNjQzLTZmMzctNDQ1MS1iYzQ0LWNkODRkOWViNTU2NyI7aToyO3M6MzY6Ijc2OTBjNDljLWZlMmYtNDEzNi05MTRhLTU1N2YwYjIwMGEwMyI7aTozO3M6MzY6IjYwYzEwMDlkLTNiNTQtNDdlMy05NTk0LTMxOTVlZDMzMjliMiI7fX1pOjE7YToyOntzOjU6IndpZHRoIjtzOjM6IjQwJSI7czo4OiJkYXNobGV0cyI7YToxOntpOjA7czowOiIiO319fXM6MTA6Im51bUNvbHVtbnMiO3M6MToiMyI7czoxNDoicGFnZVRpdGxlTGFiZWwiO3M6MjA6IkxCTF9IT01FX1BBR0VfMV9OQU1FIjt9fX0='),
('e9c7df7e-f195-4e9d-aabc-dbd335db0835','Home2_SUGARFEED',0,'2026-10-16 17:41:52','2026-10-16 17:41:52','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('f3c1f571-11b7-41db-a0fe-bc25aa80c985','global',0,'2026-10-16 10:57:58','2026-10-20 19:43:39','1','YTo1NDp7czoyMDoiY2FsZW5kYXJfcHVibGlzaF9rZXkiO3M6MzY6ImE4NTQ0MDk5LWFmODUtNGNmMy05ZTNiLTI5ZDc0ZDY3ZDcwNSI7czoxMjoibWFpbG1lcmdlX29uIjtzOjI6Im9uIjtzOjI0OiJzdWJwYW5lbF9wYWdpbmF0aW9uX3R5cGUiO3M6MTA6InBhZ2luYXRpb24iO3M6MjQ6Imxpc3R2aWV3X3BhZ2luYXRpb25fdHlwZSI7czoxMDoicGFnaW5hdGlvbiI7czoyODoicmVjb3JkX21vZGFsX3BhZ2luYXRpb25fdHlwZSI7czoxMDoicGFnaW5hdGlvbiI7czoxODoic25vb3plX2FsZXJ0X3RpbWVyIjtpOjYwMDtzOjE2OiJzd2FwX2xhc3Rfdmlld2VkIjtiOjA7czoxNDoic3dhcF9zaG9ydGN1dHMiO2I6MDtzOjE5OiJuYXZpZ2F0aW9uX3BhcmFkaWdtIjtzOjE6Im0iO3M6MjA6InNvcnRfbW9kdWxlc19ieV9uYW1lIjtzOjA6IiI7czoxMzoic3VicGFuZWxfdGFicyI7YjoxO3M6MjU6ImNvdW50X2NvbGxhcHNlZF9zdWJwYW5lbHMiO3M6MDoiIjtzOjEwOiJ1c2VyX3RoZW1lIjtzOjY6InN1aXRlOCI7czoxNDoibW9kdWxlX2Zhdmljb24iO2I6MDtzOjk6ImhpZGVfdGFicyI7YTowOnt9czoxMToicmVtb3ZlX3RhYnMiO2E6MDp7fXM6Nzoibm9fb3BwcyI7czozOiJvZmYiO3M6MTM6InJlbWluZGVyX3RpbWUiO2k6MTgwMDtzOjE5OiJlbWFpbF9yZW1pbmRlcl90aW1lIjtpOjM2MDA7czoxNjoicmVtaW5kZXJfY2hlY2tlZCI7czoxOiIxIjtzOjIyOiJlbWFpbF9yZW1pbmRlcl9jaGVja2VkIjtzOjE6IjEiO3M6ODoidGltZXpvbmUiO3M6MTk6IkFmcmljYS9Kb2hhbm5lc2J1cmciO3M6MjoidXQiO3M6MToiMSI7czo4OiJjdXJyZW5jeSI7czozOiItOTkiO3M6MzU6ImRlZmF1bHRfY3VycmVuY3lfc2lnbmlmaWNhbnRfZGlnaXRzIjtzOjE6IjIiO3M6MTE6Im51bV9ncnBfc2VwIjtzOjE6IiwiO3M6NzoiZGVjX3NlcCI7czoxOiIuIjtzOjQ6ImZkb3ciO047czo1OiJkYXRlZiI7czo1OiJZLW0tZCI7czo1OiJ0aW1lZiI7czozOiJIOmkiO3M6MjY6ImRlZmF1bHRfbG9jYWxlX25hbWVfZm9ybWF0IjtzOjU6InMgZiBsIjtzOjE2OiJleHBvcnRfZGVsaW1pdGVyIjtzOjE6IiwiO3M6MjI6ImRlZmF1bHRfZXhwb3J0X2NoYXJzZXQiO3M6NToiVVRGLTgiO3M6MTQ6InVzZV9yZWFsX25hbWVzIjtzOjI6Im9uIjtzOjE3OiJtYWlsX3NtdHBhdXRoX3JlcSI7czowOiIiO3M6MTI6Im1haWxfc210cHNzbCI7aTowO3M6MTc6InNpZ25hdHVyZV9kZWZhdWx0IjtzOjA6IiI7czoxNzoic2lnbmF0dXJlX3ByZXBlbmQiO3M6MDoiIjtzOjE1OiJlbWFpbF9saW5rX3R5cGUiO3M6NToic3VnYXIiO3M6MTE6ImVkaXRvcl90eXBlIjtzOjc6InRpbnltY2UiO3M6MTc6ImVtYWlsX3Nob3dfY291bnRzIjtpOjA7czoxOToiZW1haWxfZWRpdG9yX29wdGlvbiI7czo3OiJ0aW55bWNlIjtzOjIxOiJkZWZhdWx0X2VtYWlsX2NoYXJzZXQiO3M6NToiVVRGLTgiO3M6ODoic3VidGhlbWUiO3M6MDoiIjtzOjExOiJsb2dpbmZhaWxlZCI7czoxOiIwIjtzOjg6Imxhbmd1YWdlIjtzOjU6ImVuX3VzIjtzOjEwOiJkYXRlZm9ybWF0IjtzOjU6IlktbS1kIjtzOjEwOiJ0aW1lZm9ybWF0IjtzOjM6Ikg6aSI7czoyOiJ1aSI7czo3MDk4OiJ7Im5vb3AiOiJub29wIiwiYWNjb3VudHMtbGlzdHZpZXctc2hvdy1zaWRlYmFyLXdpZGdldHMiOmZhbHNlLCJhY2NvdW50cy1saXN0dmlldy1jdXJyZW50LXBhZ2luYXRpb24tdHlwZSI6InBhZ2luYXRpb24iLCJhY2NvdW50cy1saXN0dmlldy1jdXJyZW50LWZpbHRlcnMiOnsiZGVmYXVsdCI6eyJrZXkiOiJkZWZhdWx0IiwibW9kdWxlIjoic2F2ZWQtc2VhcmNoIiwiYXR0cmlidXRlcyI6eyJjb250ZW50cyI6IiJ9LCJjcml0ZXJpYSI6eyJuYW1lIjoiZGVmYXVsdCIsImZpbHRlcnMiOltdfX19LCJhY2NvdW50cy1saXN0dmlldy1jdXJyZW50LXNvcnQiOnsib3JkZXJCeSI6IiIsInNvcnRPcmRlciI6IkRFU0MifSwicXVvdGVzLXJlY29yZHZpZXctY3VycmVudC1yZWNvcmQtcGFnaW5hdGlvbiI6eyJwYWdpbmF0aW9uIjp7InBhZ2VTaXplIjoyMCwiY3VycmVudCI6MCwicHJldmlvdXMiOi0xLCJuZXh0IjotMSwibGFzdCI6MCwidG90YWwiOjEsInBhZ2VGaXJzdCI6MSwicGFnZUxhc3QiOjF9LCJyZWNvcmRJZHMiOlt7ImlkIjoiMjJmYjYyNTctODI2OC00ZDIwLWIzNTctZGNiMjc1ZGRhOWM0In1dfSwicXVvdGVzLWxpc3R2aWV3LXNob3ctc2lkZWJhci13aWRnZXRzIjpmYWxzZSwicXVvdGVzLWxpc3R2aWV3LWN1cnJlbnQtcGFnaW5hdGlvbi10eXBlIjoicGFnaW5hdGlvbiIsInF1b3Rlcy1saXN0dmlldy1jdXJyZW50LWZpbHRlcnMiOnsiZGVmYXVsdCI6eyJrZXkiOiJkZWZhdWx0IiwibW9kdWxlIjoic2F2ZWQtc2VhcmNoIiwiYXR0cmlidXRlcyI6eyJjb250ZW50cyI6IiJ9LCJjcml0ZXJpYSI6eyJuYW1lIjoiZGVmYXVsdCIsImZpbHRlcnMiOltdfX19LCJxdW90ZXMtbGlzdHZpZXctY3VycmVudC1zb3J0Ijp7Im9yZGVyQnkiOiIiLCJzb3J0T3JkZXIiOiJERVNDIn0sIm9wcG9ydHVuaXRpZXMtcmVjb3Jkdmlldy1zaG93LXNpZGViYXItd2lkZ2V0cyI6dHJ1ZSwib3Bwb3J0dW5pdGllcy1saXN0dmlldy1zaG93LXNpZGViYXItd2lkZ2V0cyI6dHJ1ZSwib3Bwb3J0dW5pdGllcy1saXN0dmlldy1jdXJyZW50LXBhZ2luYXRpb24tdHlwZSI6InBhZ2luYXRpb24iLCJvcHBvcnR1bml0aWVzLWxpc3R2aWV3LWN1cnJlbnQtZmlsdGVycyI6eyJkZWZhdWx0Ijp7ImtleSI6ImRlZmF1bHQiLCJtb2R1bGUiOiJzYXZlZC1zZWFyY2giLCJhdHRyaWJ1dGVzIjp7ImNvbnRlbnRzIjoiIn0sImNyaXRlcmlhIjp7Im5hbWUiOiJkZWZhdWx0IiwiZmlsdGVycyI6W119fX0sIm9wcG9ydHVuaXRpZXMtbGlzdHZpZXctY3VycmVudC1zb3J0Ijp7Im9yZGVyQnkiOiIiLCJzb3J0T3JkZXIiOiJERVNDIn0sIm9wcG9ydHVuaXRpZXMtcmVjb3Jkdmlldy1jdXJyZW50LXJlY29yZC1wYWdpbmF0aW9uIjp7InBhZ2luYXRpb24iOnsicGFnZVNpemUiOjIwLCJjdXJyZW50IjowLCJwcmV2aW91cyI6MCwibmV4dCI6NSwibGFzdCI6MCwidG90YWwiOjAsInBhZ2VGaXJzdCI6MCwicGFnZUxhc3QiOjB9LCJyZWNvcmRJZHMiOltdfSwiUlRfUmFkaW9DYW1wYWlnbnMtcmVjb3Jkdmlldy1jdXJyZW50LXJlY29yZC1wYWdpbmF0aW9uIjp7InBhZ2luYXRpb24iOnsicGFnZVNpemUiOjIwLCJjdXJyZW50IjowLCJwcmV2aW91cyI6LTEsIm5leHQiOi0xLCJsYXN0IjowLCJ0b3RhbCI6MiwicGFnZUZpcnN0IjoxLCJwYWdlTGFzdCI6Mn0sInJlY29yZElkcyI6W3siaWQiOiI3N2Q0OThlMS1mYmY2LTQ0ODQtOWU0Yi1mMTA3NDZlMzgyZTYifSx7ImlkIjoiYzk2ODczMDQtZGE5Zi00NDg2LWIyYzgtNGZjNjgyYTk0OTc4In1dfSwiUlRfUmFkaW9DYW1wYWlnbnMtbGlzdHZpZXctc2hvdy1zaWRlYmFyLXdpZGdldHMiOmZhbHNlLCJSVF9SYWRpb0NhbXBhaWducy1saXN0dmlldy1jdXJyZW50LXBhZ2luYXRpb24tdHlwZSI6InBhZ2luYXRpb24iLCJSVF9SYWRpb0NhbXBhaWducy1saXN0dmlldy1jdXJyZW50LWZpbHRlcnMiOnsiZGVmYXVsdCI6eyJrZXkiOiJkZWZhdWx0IiwibW9kdWxlIjoic2F2ZWQtc2VhcmNoIiwiYXR0cmlidXRlcyI6eyJjb250ZW50cyI6IiJ9LCJjcml0ZXJpYSI6eyJuYW1lIjoiZGVmYXVsdCIsImZpbHRlcnMiOltdfX19LCJSVF9SYWRpb0NhbXBhaWducy1saXN0dmlldy1jdXJyZW50LXNvcnQiOnsib3JkZXJCeSI6IiIsInNvcnRPcmRlciI6IkRFU0MifSwiUlRfUmFkaW9DYW1wYWlnbnMtcmVjb3Jkdmlldy1zaG93LXNpZGViYXItd2lkZ2V0cyI6ZmFsc2UsImNvbnRhY3RzLXJlY29yZHZpZXctY3VycmVudC1yZWNvcmQtcGFnaW5hdGlvbiI6eyJwYWdpbmF0aW9uIjp7InBhZ2VTaXplIjoyMCwiY3VycmVudCI6MCwicHJldmlvdXMiOi0xLCJuZXh0IjotMSwibGFzdCI6MCwidG90YWwiOjEsInBhZ2VGaXJzdCI6MSwicGFnZUxhc3QiOjF9LCJyZWNvcmRJZHMiOlt7ImlkIjoiYTU2MGFkYzAtNzViOC00ZGM2LWIzMWYtMTZkZjA5MWYyZTFhIn1dfSwiY29udGFjdHMtbGlzdHZpZXctc2hvdy1zaWRlYmFyLXdpZGdldHMiOmZhbHNlLCJjb250YWN0cy1saXN0dmlldy1jdXJyZW50LXBhZ2luYXRpb24tdHlwZSI6InBhZ2luYXRpb24iLCJjb250YWN0cy1saXN0dmlldy1jdXJyZW50LWZpbHRlcnMiOnsiZGVmYXVsdCI6eyJrZXkiOiJkZWZhdWx0IiwibW9kdWxlIjoic2F2ZWQtc2VhcmNoIiwiYXR0cmlidXRlcyI6eyJjb250ZW50cyI6IiJ9LCJjcml0ZXJpYSI6eyJuYW1lIjoiZGVmYXVsdCIsImZpbHRlcnMiOltdfX19LCJjb250YWN0cy1saXN0dmlldy1jdXJyZW50LXNvcnQiOnsib3JkZXJCeSI6IiIsInNvcnRPcmRlciI6IkRFU0MifSwiYWNjb3VudHMtcmVjb3Jkdmlldy1jdXJyZW50LXJlY29yZC1wYWdpbmF0aW9uIjp7InBhZ2luYXRpb24iOnsicGFnZVNpemUiOjIwLCJjdXJyZW50IjowLCJwcmV2aW91cyI6LTEsIm5leHQiOi0xLCJsYXN0IjowLCJ0b3RhbCI6MiwicGFnZUZpcnN0IjoxLCJwYWdlTGFzdCI6Mn0sInJlY29yZElkcyI6W3siaWQiOiIyMmZiNjI1Ny04MjY4LTRkMjAtYjM1Ny1kY2IyNzVkZGE5YzQifSx7ImlkIjoiZWJmYTQ1ZmUtMjIwMi00Zjg0LTkxNjMtNWI1YmMyMWI0NjRhIn1dfSwiZG9jdW1lbnRzLXJlY29yZHZpZXctY3VycmVudC1yZWNvcmQtcGFnaW5hdGlvbiI6eyJwYWdpbmF0aW9uIjp7InBhZ2VTaXplIjoyMCwiY3VycmVudCI6MCwicHJldmlvdXMiOi0xLCJuZXh0IjotMSwibGFzdCI6LTIwLCJ0b3RhbCI6MCwicGFnZUZpcnN0IjowLCJwYWdlTGFzdCI6MH0sInJlY29yZElkcyI6W119LCJkb2N1bWVudHMtbGlzdHZpZXctc2hvdy1zaWRlYmFyLXdpZGdldHMiOmZhbHNlLCJkb2N1bWVudHMtbGlzdHZpZXctY3VycmVudC1wYWdpbmF0aW9uLXR5cGUiOiJwYWdpbmF0aW9uIiwiZG9jdW1lbnRzLWxpc3R2aWV3LWN1cnJlbnQtZmlsdGVycyI6eyJkZWZhdWx0Ijp7ImtleSI6ImRlZmF1bHQiLCJtb2R1bGUiOiJzYXZlZC1zZWFyY2giLCJhdHRyaWJ1dGVzIjp7ImNvbnRlbnRzIjoiIn0sImNyaXRlcmlhIjp7Im5hbWUiOiJkZWZhdWx0IiwiZmlsdGVycyI6W119fX0sImRvY3VtZW50cy1saXN0dmlldy1jdXJyZW50LXNvcnQiOnsib3JkZXJCeSI6IiIsInNvcnRPcmRlciI6Ik5PTkUifSwiY2FtcGFpZ25zLXJlY29yZHZpZXctY3VycmVudC1yZWNvcmQtcGFnaW5hdGlvbiI6eyJwYWdpbmF0aW9uIjp7InBhZ2VTaXplIjoyMCwiY3VycmVudCI6MCwicHJldmlvdXMiOi0xLCJuZXh0IjotMSwibGFzdCI6MCwidG90YWwiOjIsInBhZ2VGaXJzdCI6MSwicGFnZUxhc3QiOjJ9LCJyZWNvcmRJZHMiOlt7ImlkIjoiOGY1MmRiYWQtOGZhZi00ODVlLTg2OTMtMmMxZWJiMjc4YjhhIn0seyJpZCI6IjQ5M2ZiNGEyLTdjOGItNDAwZS04ZjEyLWM5YzQ0ODE1Y2FkYSJ9XX0sImNhbXBhaWducy1saXN0dmlldy1zaG93LXNpZGViYXItd2lkZ2V0cyI6ZmFsc2UsImNhbXBhaWducy1saXN0dmlldy1jdXJyZW50LXBhZ2luYXRpb24tdHlwZSI6InBhZ2luYXRpb24iLCJjYW1wYWlnbnMtbGlzdHZpZXctY3VycmVudC1maWx0ZXJzIjp7ImRlZmF1bHQiOnsia2V5IjoiZGVmYXVsdCIsIm1vZHVsZSI6InNhdmVkLXNlYXJjaCIsImF0dHJpYnV0ZXMiOnsiY29udGVudHMiOiIifSwiY3JpdGVyaWEiOnsibmFtZSI6ImRlZmF1bHQiLCJmaWx0ZXJzIjpbXX19fSwiY2FtcGFpZ25zLWxpc3R2aWV3LWN1cnJlbnQtc29ydCI6eyJvcmRlckJ5IjoiIiwic29ydE9yZGVyIjoiREVTQyJ9LCJpbnZvaWNlcy1yZWNvcmR2aWV3LWN1cnJlbnQtcmVjb3JkLXBhZ2luYXRpb24iOnsicGFnaW5hdGlvbiI6eyJwYWdlU2l6ZSI6MjAsImN1cnJlbnQiOjAsInByZXZpb3VzIjotMSwibmV4dCI6LTEsImxhc3QiOi0yMCwidG90YWwiOjAsInBhZ2VGaXJzdCI6MCwicGFnZUxhc3QiOjB9LCJyZWNvcmRJZHMiOltdfSwiaW52b2ljZXMtbGlzdHZpZXctc2hvdy1zaWRlYmFyLXdpZGdldHMiOmZhbHNlLCJpbnZvaWNlcy1saXN0dmlldy1jdXJyZW50LXBhZ2luYXRpb24tdHlwZSI6InBhZ2luYXRpb24iLCJpbnZvaWNlcy1saXN0dmlldy1jdXJyZW50LWZpbHRlcnMiOnsiZGVmYXVsdCI6eyJrZXkiOiJkZWZhdWx0IiwibW9kdWxlIjoic2F2ZWQtc2VhcmNoIiwiYXR0cmlidXRlcyI6eyJjb250ZW50cyI6IiJ9LCJjcml0ZXJpYSI6eyJuYW1lIjoiZGVmYXVsdCIsImZpbHRlcnMiOltdfX19LCJpbnZvaWNlcy1saXN0dmlldy1jdXJyZW50LXNvcnQiOnsib3JkZXJCeSI6IiIsInNvcnRPcmRlciI6IkRFU0MifSwiY29udHJhY3RzLXJlY29yZHZpZXctY3VycmVudC1yZWNvcmQtcGFnaW5hdGlvbiI6eyJwYWdpbmF0aW9uIjp7InBhZ2VTaXplIjoyMCwiY3VycmVudCI6MCwicHJldmlvdXMiOi0xLCJuZXh0IjotMSwibGFzdCI6MCwidG90YWwiOjEsInBhZ2VGaXJzdCI6MSwicGFnZUxhc3QiOjF9LCJyZWNvcmRJZHMiOlt7ImlkIjoiYmU3MjlhMTQtMzBmZC00ODRmLWEzZTYtNmU0NDU1MGFlYmMyIn1dfSwiY29udHJhY3RzLWxpc3R2aWV3LXNob3ctc2lkZWJhci13aWRnZXRzIjpmYWxzZSwiY29udHJhY3RzLWxpc3R2aWV3LWN1cnJlbnQtcGFnaW5hdGlvbi10eXBlIjoicGFnaW5hdGlvbiIsImNvbnRyYWN0cy1saXN0dmlldy1jdXJyZW50LWZpbHRlcnMiOnsiZGVmYXVsdCI6eyJrZXkiOiJkZWZhdWx0IiwibW9kdWxlIjoic2F2ZWQtc2VhcmNoIiwiYXR0cmlidXRlcyI6eyJjb250ZW50cyI6IiJ9LCJjcml0ZXJpYSI6eyJuYW1lIjoiZGVmYXVsdCIsImZpbHRlcnMiOltdfX19LCJjb250cmFjdHMtbGlzdHZpZXctY3VycmVudC1zb3J0Ijp7Im9yZGVyQnkiOiIiLCJzb3J0T3JkZXIiOiJOT05FIn0sImhvbWUtcmVjb3Jkdmlldy1jdXJyZW50LXJlY29yZC1wYWdpbmF0aW9uIjp7InBhZ2luYXRpb24iOnsicGFnZVNpemUiOjIwLCJjdXJyZW50IjowLCJwcmV2aW91cyI6LTEsIm5leHQiOi0xLCJsYXN0IjotMjAsInRvdGFsIjowLCJwYWdlRmlyc3QiOjAsInBhZ2VMYXN0IjowfSwicmVjb3JkSWRzIjpbXX0sInVzZXJzLWxpc3R2aWV3LXNob3ctc2lkZWJhci13aWRnZXRzIjpmYWxzZSwidXNlcnMtbGlzdHZpZXctY3VycmVudC1wYWdpbmF0aW9uLXR5cGUiOiJwYWdpbmF0aW9uIiwidXNlcnMtbGlzdHZpZXctY3VycmVudC1maWx0ZXJzIjp7ImRlZmF1bHQiOnsia2V5IjoiZGVmYXVsdCIsIm1vZHVsZSI6InNhdmVkLXNlYXJjaCIsImF0dHJpYnV0ZXMiOnsiY29udGVudHMiOiIifSwiY3JpdGVyaWEiOnsibmFtZSI6ImRlZmF1bHQiLCJmaWx0ZXJzIjpbXX19fSwidXNlcnMtbGlzdHZpZXctY3VycmVudC1zb3J0Ijp7Im9yZGVyQnkiOiIiLCJzb3J0T3JkZXIiOiJOT05FIn0sInVzZXJzLXJlY29yZHZpZXctY3VycmVudC1yZWNvcmQtcGFnaW5hdGlvbiI6eyJwYWdpbmF0aW9uIjp7InBhZ2VTaXplIjoyMCwiY3VycmVudCI6MCwicHJldmlvdXMiOi0xLCJuZXh0IjotMSwibGFzdCI6MCwidG90YWwiOjIsInBhZ2VGaXJzdCI6MSwicGFnZUxhc3QiOjJ9LCJyZWNvcmRJZHMiOlt7ImlkIjoiY2E3NzEwMTctZDU4Yi00OTg3LThhYTEtZDFmN2UwMmMxOGQ5In0seyJpZCI6IjEifV19LCJlbXBsb3llZXMtbGlzdHZpZXctc2hvdy1zaWRlYmFyLXdpZGdldHMiOmZhbHNlLCJlbXBsb3llZXMtbGlzdHZpZXctY3VycmVudC1wYWdpbmF0aW9uLXR5cGUiOiJwYWdpbmF0aW9uIiwiZW1wbG95ZWVzLWxpc3R2aWV3LWN1cnJlbnQtZmlsdGVycyI6eyJkZWZhdWx0Ijp7ImtleSI6ImRlZmF1bHQiLCJtb2R1bGUiOiJzYXZlZC1zZWFyY2giLCJhdHRyaWJ1dGVzIjp7ImNvbnRlbnRzIjoiIn0sImNyaXRlcmlhIjp7Im5hbWUiOiJkZWZhdWx0IiwiZmlsdGVycyI6W119fX0sImVtcGxveWVlcy1saXN0dmlldy1jdXJyZW50LXNvcnQiOnsib3JkZXJCeSI6IiIsInNvcnRPcmRlciI6Ik5PTkUifSwiZW1wbG95ZWVzLXJlY29yZHZpZXctY3VycmVudC1yZWNvcmQtcGFnaW5hdGlvbiI6eyJwYWdpbmF0aW9uIjp7InBhZ2VTaXplIjoyMCwiY3VycmVudCI6MCwicHJldmlvdXMiOi0xLCJuZXh0IjotMSwibGFzdCI6MCwidG90YWwiOjIsInBhZ2VGaXJzdCI6MSwicGFnZUxhc3QiOjJ9LCJyZWNvcmRJZHMiOlt7ImlkIjoiY2E3NzEwMTctZDU4Yi00OTg3LThhYTEtZDFmN2UwMmMxOGQ5In0seyJpZCI6IjEifV19LCJwcm9kdWN0cy1saXN0dmlldy1zaG93LXNpZGViYXItd2lkZ2V0cyI6ZmFsc2UsInByb2R1Y3RzLWxpc3R2aWV3LWN1cnJlbnQtcGFnaW5hdGlvbi10eXBlIjoicGFnaW5hdGlvbiIsInByb2R1Y3RzLWxpc3R2aWV3LWN1cnJlbnQtZmlsdGVycyI6eyJkZWZhdWx0Ijp7ImtleSI6ImRlZmF1bHQiLCJtb2R1bGUiOiJzYXZlZC1zZWFyY2giLCJhdHRyaWJ1dGVzIjp7ImNvbnRlbnRzIjoiIn0sImNyaXRlcmlhIjp7Im5hbWUiOiJkZWZhdWx0IiwiZmlsdGVycyI6W119fX0sInByb2R1Y3RzLWxpc3R2aWV3LWN1cnJlbnQtc29ydCI6eyJvcmRlckJ5IjoiIiwic29ydE9yZGVyIjoiREVTQyJ9LCJhZG1pbmlzdHJhdGlvbi1yZWNvcmR2aWV3LWN1cnJlbnQtcmVjb3JkLXBhZ2luYXRpb24iOnsicGFnaW5hdGlvbiI6eyJwYWdlU2l6ZSI6MjAsImN1cnJlbnQiOjAsInByZXZpb3VzIjotMSwibmV4dCI6LTEsImxhc3QiOi0yMCwidG90YWwiOjAsInBhZ2VGaXJzdCI6MCwicGFnZUxhc3QiOjB9LCJyZWNvcmRJZHMiOltdfSwiYWNjb3VudHMtcmVjb3Jkdmlldy1zaG93LXNpZGViYXItd2lkZ2V0cyI6dHJ1ZSwiY29udGFjdHMtcmVjb3Jkdmlldy1zaG93LXNpZGViYXItd2lkZ2V0cyI6dHJ1ZX0iO3M6MTQ6Ik9wcG9ydHVuaXRpZXNRIjthOjY6e3M6NjoibW9kdWxlIjtzOjEzOiJPcHBvcnR1bml0aWVzIjtzOjY6ImFjdGlvbiI7czo1OiJpbmRleCI7czo1OiJxdWVyeSI7czo0OiJ0cnVlIjtzOjEzOiJzZWFyY2hGb3JtVGFiIjtzOjE1OiJhZHZhbmNlZF9zZWFyY2giO3M6MjA6ImRhdGVfY2xvc2VkX2FkdmFuY2VkIjtzOjA6IiI7czoxMToic2FsZXNfc3RhZ2UiO3M6MTQ6Ik5lZWRzIEFuYWx5c2lzIjt9czoxNDoiT0F1dGgyQ2xpZW50c1EiO2E6MTp7czoxMzoic2VhcmNoRm9ybVRhYiI7czoxMjoiYmFzaWNfc2VhcmNoIjt9czoxMDoiT0F1dGhLZXlzUSI7YToxOntzOjEzOiJzZWFyY2hGb3JtVGFiIjtzOjEyOiJiYXNpY19zZWFyY2giO31zOjExOiJBT1NfUXVvdGVzUSI7YToxOntzOjEzOiJzZWFyY2hGb3JtVGFiIjtzOjEyOiJiYXNpY19zZWFyY2giO31zOjE4OiJSVF9SYWRpb0NhbXBhaWduc1EiO2E6MTp7czoxMzoic2VhcmNoRm9ybVRhYiI7czoxMjoiYmFzaWNfc2VhcmNoIjt9fQ==');
/*!40000 ALTER TABLE `user_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` char(36) NOT NULL,
  `user_name` varchar(60) DEFAULT NULL,
  `user_hash` varchar(255) DEFAULT NULL,
  `system_generated_password` tinyint(1) DEFAULT NULL,
  `pwd_last_changed` datetime DEFAULT NULL,
  `authenticate_id` varchar(100) DEFAULT NULL,
  `sugar_login` tinyint(1) DEFAULT 1,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT 0,
  `external_auth_only` tinyint(1) DEFAULT 0,
  `receive_notifications` tinyint(1) DEFAULT 1,
  `description` text DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `phone_home` varchar(50) DEFAULT NULL,
  `phone_mobile` varchar(50) DEFAULT NULL,
  `phone_work` varchar(50) DEFAULT NULL,
  `phone_other` varchar(50) DEFAULT NULL,
  `phone_fax` varchar(50) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `address_street` varchar(150) DEFAULT NULL,
  `address_city` varchar(100) DEFAULT NULL,
  `address_state` varchar(100) DEFAULT NULL,
  `address_country` varchar(100) DEFAULT NULL,
  `address_postalcode` varchar(20) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `portal_only` tinyint(1) DEFAULT 0,
  `show_on_employees` tinyint(1) DEFAULT 1,
  `employee_status` varchar(100) DEFAULT NULL,
  `messenger_id` varchar(100) DEFAULT NULL,
  `messenger_type` varchar(100) DEFAULT NULL,
  `reports_to_id` char(36) DEFAULT NULL,
  `is_group` tinyint(1) DEFAULT NULL,
  `factor_auth` tinyint(1) DEFAULT NULL,
  `factor_auth_interface` varchar(255) DEFAULT NULL,
  `totp_secret` varchar(255) DEFAULT NULL,
  `is_totp_enabled` tinyint(1) DEFAULT NULL,
  `backup_codes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_name` (`user_name`,`is_group`,`status`,`last_name`(30),`first_name`(30),`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
('1','admin','$2y$10$8ZeE6hkrx4B9at6HGuReAedVrgKIMqDyR1MjVtdpEn.xN92A1Ju7C',0,NULL,NULL,1,'System','Administrator',1,0,1,NULL,'2026-10-16 10:57:58','2026-10-19 15:20:47','1','1','System Administrator',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Active',NULL,NULL,NULL,NULL,NULL,0,0,1,'Active',NULL,NULL,'',0,0,NULL,NULL,0,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_feeds`
--

DROP TABLE IF EXISTS `users_feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_feeds` (
  `user_id` varchar(36) DEFAULT NULL,
  `feed_id` varchar(36) DEFAULT NULL,
  `rank` int(11) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  KEY `idx_ud_user_id` (`user_id`,`feed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_feeds`
--

LOCK TABLES `users_feeds` WRITE;
/*!40000 ALTER TABLE `users_feeds` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_feeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_last_import`
--

DROP TABLE IF EXISTS `users_last_import`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_last_import` (
  `id` char(36) NOT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `import_module` varchar(36) DEFAULT NULL,
  `bean_type` varchar(36) DEFAULT NULL,
  `bean_id` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_last_import`
--

LOCK TABLES `users_last_import` WRITE;
/*!40000 ALTER TABLE `users_last_import` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_last_import` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_password_link`
--

DROP TABLE IF EXISTS `users_password_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_password_link` (
  `id` char(36) NOT NULL,
  `keyhash` varchar(255) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `username` varchar(36) DEFAULT NULL,
  `date_generated` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_password_link`
--

LOCK TABLES `users_password_link` WRITE;
/*!40000 ALTER TABLE `users_password_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_password_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_signatures`
--

DROP TABLE IF EXISTS `users_signatures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_signatures` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `signature` text DEFAULT NULL,
  `signature_html` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_usersig_uid` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_signatures`
--

LOCK TABLES `users_signatures` WRITE;
/*!40000 ALTER TABLE `users_signatures` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_signatures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vcals`
--

DROP TABLE IF EXISTS `vcals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vcals` (
  `id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `user_id` char(36) NOT NULL,
  `type` varchar(100) DEFAULT NULL,
  `source` varchar(100) DEFAULT NULL,
  `content` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vcal` (`type`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vcals`
--

LOCK TABLES `vcals` WRITE;
/*!40000 ALTER TABLE `vcals` DISABLE KEYS */;
/*!40000 ALTER TABLE `vcals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'suitecrm_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-20 23:02:14
